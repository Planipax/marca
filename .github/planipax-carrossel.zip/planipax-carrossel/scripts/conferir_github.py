#!/usr/bin/env python3
"""Confere o que o GitHub gerou para um carrossel e devolve os enderecos.

Uso: python3 scripts/conferir_github.py saida/ [--esperar 600]

Le saida/payload.json (pasta e html), e no repositorio publico Planipax/marca:
  1. confirma que publicacoes/<pasta>/carrossel.html tem o mesmo sha256;
  2. espera pelo estado.json da tarefa automatica (ate --esperar segundos);
  3. descarrega cada slideNN.png e compara-o com o PNG aprovado em saida/;
  4. imprime os enderecos publicos, pela ordem, para o Metricool.
Codigo 0 = tudo certo. Qualquer outro = NAO agendar.
"""
import argparse, hashlib, io, json, sys, time, urllib.request
from pathlib import Path

BASE = "https://raw.githubusercontent.com/Planipax/marca/main/publicacoes/"


def obter(url):
    req = urllib.request.Request(url + f"?t={int(time.time())}",
                                 headers={"Cache-Control": "no-cache"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.read()
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None
        raise


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("saida")
    ap.add_argument("--esperar", type=int, default=600)
    a = ap.parse_args()
    saida = Path(a.saida)
    p = json.loads((saida / "payload.json").read_text(encoding="utf-8"))
    pasta, html, n = p["pasta"], p["html"], p["slides"]
    url = BASE + pasta + "/"
    sha = hashlib.sha256(html.encode("utf-8")).hexdigest()

    limite = time.time() + a.esperar
    gh = None
    while time.time() < limite:
        gh = obter(url + "carrossel.html")
        if gh is not None:
            break
        time.sleep(15)
    if gh is None:
        sys.exit(f"ERRO: {pasta}/carrossel.html nao esta no GitHub. O Make gravou?")
    if hashlib.sha256(gh).hexdigest() != sha:
        sys.exit("ERRO: o carrossel.html no GitHub NAO e igual ao aprovado "
                 "(sha256 diferente). Algo mudou pelo caminho -- nao agendar.")
    print("carrossel.html: igual ao aprovado")

    estado = None
    while time.time() < limite:
        bruto = obter(url + "estado.json")
        if bruto:
            estado = json.loads(bruto)
            if estado.get("sha256") == sha:
                break
        time.sleep(20)
    if not estado or estado.get("sha256") != sha:
        sys.exit("ERRO: o GitHub ainda nao gerou as imagens (estado.json). Ver "
                 "github.com/Planipax/marca/actions.")
    if estado.get("falhas"):
        sys.exit(f"ERRO: a geracao no GitHub reportou falhas: {estado['falhas']}")
    if estado.get("slides") != n:
        sys.exit(f"ERRO: o GitHub gerou {estado.get('slides')} slides, esperados {n}.")

    from importlib.metadata import version
    local = version("playwright")
    if estado.get("playwright") != local:
        print(f"AVISO: o GitHub gerou com playwright {estado.get('playwright')} e "
              f"este ambiente tem {local}. Versoes diferentes partem as linhas "
              "noutros sitios: atualizar a versao em .github/workflows/"
              "gerar-imagens.yml para a deste ambiente.")
    from PIL import Image, ImageFilter
    import numpy as np

    def reduzida(img):
        # 108x135 e um pouco desfocada: os pormenores de desenho das letras e o
        # desfoque das fotografias (que mudam de maquina para maquina) somem;
        # uma linha que parte noutro sitio ou um bloco que se desloca nao.
        return np.asarray(img.convert("L").resize((108, 135), Image.LANCZOS)
                          .filter(ImageFilter.GaussianBlur(1)), dtype=float)

    urls = []
    for nome in estado["ficheiros"]:
        dados = obter(url + nome)
        if not dados:
            sys.exit(f"ERRO: {nome} nao esta no GitHub.")
        a_img = Image.open(io.BytesIO(dados))
        b_img = Image.open(saida / nome)
        if a_img.size != b_img.size:
            sys.exit(f"ERRO: {nome} tem {a_img.size}, o aprovado {b_img.size}.")
        d = np.abs(reduzida(a_img) - reduzida(b_img))
        print(f"{nome}: diferenca media {d.mean():.2f}, maxima {d.max():.0f}")
        # Afinado a 22/10/2026: imagens iguais dao media < 0,5 e maxima < 25;
        # uma linha partida noutro sitio deu maxima 48.
        if d.mean() > 1.5 or d.max() > 35:
            sys.exit(f"ERRO: {nome} difere do aprovado (texto noutro sitio?). "
                     "Ver as duas imagens lado a lado antes de agendar.")
        urls.append(url + nome)
    print("\nENDERECOS (pela ordem, para o Metricool):")
    for u in urls:
        print(u)


if __name__ == "__main__":
    main()
