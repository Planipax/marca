#!/usr/bin/env python3
"""Confere o que o GitHub gerou para um carrossel e devolve os enderecos.

Uso: python3 scripts/conferir_github.py saida/ [--esperar 600]

Le saida/payload.json (pasta e html), e no repositorio publico Planipax/marca:
  1. confirma que publicacoes/<pasta>/carrossel.html tem o mesmo sha256;
  2. espera pelo estado.json da tarefa automatica (ate --esperar segundos);
  3. descarrega cada slideNN.png e compara-o com o PNG aprovado em saida/;
  4. imprime os enderecos publicos, pela ordem, para o Metricool.
Codigo 0 = tudo certo. Qualquer outro = NAO agendar.
"""
import argparse, hashlib, io, json, sys, time, urllib.request
from pathlib import Path

BASE = "https://raw.githubusercontent.com/Planipax/marca/main/publicacoes/"


def obter(url):
    req = urllib.request.Request(url + f"?t={int(time.time())}",
                                 headers={"Cache-Control": "no-cache"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.read()
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None
        raise


def conferir_reel(estado, saida, url):
    """O video do GitHub tem de ser o aprovado: sem falhas, mesma duracao
    (0,3 s de margem) e a mesma folha de revisao (fim de cada cena)."""
    import subprocess
    from PIL import Image, ImageFilter
    import numpy as np
    if estado.get("falhas"):
        sys.exit(f"ERRO: a geracao do Reel no GitHub reportou falhas: {estado['falhas']}")
    for nome in ("reel.mp4", "capa.png", "folha.png"):
        if nome not in estado.get("ficheiros", []):
            sys.exit(f"ERRO: o GitHub nao gerou {nome}.")
    q = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                        "-of", "csv=p=0", str(saida / "reel.mp4")], capture_output=True, text=True)
    local = float(q.stdout.strip())
    gh = float(estado.get("duracao") or 0)
    print(f"duracao: aprovado {local:.2f} s, GitHub {gh:.2f} s")
    if abs(local - gh) > 0.3:
        sys.exit("ERRO: o video do GitHub nao tem a duracao do aprovado. A voz ou o "
                 "roteiro mudaram pelo caminho -- ver as duas versoes antes de agendar.")
    bruto = obter(url + "folha.png")
    a_img = Image.open(io.BytesIO(bruto)); b_img = Image.open(saida / "folha.png")
    if a_img.size != b_img.size:
        sys.exit(f"ERRO: folha.png do GitHub tem {a_img.size}, a aprovada {b_img.size}.")
    red = lambda i: np.asarray(i.convert("L").resize((a_img.width // 10, a_img.height // 10),
                               Image.LANCZOS).filter(ImageFilter.GaussianBlur(1)), dtype=float)
    d = np.abs(red(a_img) - red(b_img))
    print(f"folha de revisao: diferenca media {d.mean():.2f}, maxima {d.max():.0f}")
    if d.mean() > 1.5 or d.max() > 35:
        sys.exit("ERRO: as cenas do GitHub diferem das aprovadas. Ver as duas folhas "
                 "lado a lado antes de agendar.")
    from importlib.metadata import version
    for pac in ("playwright", "piper"):
        loc = version("piper-tts" if pac == "piper" else pac)
        if estado.get(pac) and estado[pac] != loc:
            print(f"AVISO: {pac} no GitHub {estado[pac]}, aqui {loc}.")
    print("\nENDERECOS (para o Metricool):")
    print("video:", url + "reel.mp4")
    print("capa: ", url + "capa.png")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("saida")
    ap.add_argument("--esperar", type=int, default=600)
    a = ap.parse_args()
    saida = Path(a.saida)
    p = json.loads((saida / "payload.json").read_text(encoding="utf-8"))
    pasta, html, n = p["pasta"], p["html"], p["slides"]
    ficheiro = p.get("ficheiro", "carrossel.html")
    url = BASE + pasta + "/"
    sha = hashlib.sha256(html.encode("utf-8")).hexdigest()

    limite = time.time() + a.esperar
    gh = None
    while time.time() < limite:
        gh = obter(url + ficheiro)
        if gh is not None:
            break
        time.sleep(15)
    if gh is None:
        sys.exit(f"ERRO: {pasta}/{ficheiro} nao esta no GitHub. O Make gravou?")
    if hashlib.sha256(gh).hexdigest() != sha:
        sys.exit(f"ERRO: o {ficheiro} no GitHub NAO e igual ao aprovado "
                 "(sha256 diferente). Algo mudou pelo caminho -- nao agendar.")
    print(f"{ficheiro}: igual ao aprovado")

    estado = None
    while time.time() < limite:
        bruto = obter(url + "estado.json")
        if bruto:
            estado = json.loads(bruto)
            if estado.get("sha256") == sha:
                break
        time.sleep(20)
    if not estado or estado.get("sha256") != sha:
        sys.exit("ERRO: o GitHub ainda nao gerou as imagens (estado.json). Ver "
                 "github.com/Planipax/marca/actions.")
    if estado.get("tipo") == "reel":
        return conferir_reel(estado, saida, url)
    if estado.get("falhas"):
        sys.exit(f"ERRO: a geracao no GitHub reportou falhas: {estado['falhas']}")
    if estado.get("slides") != n:
        sys.exit(f"ERRO: o GitHub gerou {estado.get('slides')} slides, esperados {n}.")

    from importlib.metadata import version
    local = version("playwright")
    if estado.get("playwright") != local:
        print(f"AVISO: o GitHub gerou com playwright {estado.get('playwright')} e "
              f"este ambiente tem {local}. Versoes diferentes partem as linhas "
              "noutros sitios: atualizar a versao em .github/workflows/"
              "gerar-imagens.yml para a deste ambiente.")
    from PIL import Image, ImageFilter
    import numpy as np

    def reduzida(img):
        # 108x135 e um pouco desfocada: os pormenores de desenho das letras e o
        # desfoque das fotografias (que mudam de maquina para maquina) somem;
        # uma linha que parte noutro sitio ou um bloco que se desloca nao.
        return np.asarray(img.convert("L").resize((108, 135), Image.LANCZOS)
                          .filter(ImageFilter.GaussianBlur(1)), dtype=float)

    urls = []
    for nome in estado["ficheiros"]:
        dados = obter(url + nome)
        if not dados:
            sys.exit(f"ERRO: {nome} nao esta no GitHub.")
        a_img = Image.open(io.BytesIO(dados))
        b_img = Image.open(saida / nome)
        if a_img.size != b_img.size:
            sys.exit(f"ERRO: {nome} tem {a_img.size}, o aprovado {b_img.size}.")
        d = np.abs(reduzida(a_img) - reduzida(b_img))
        print(f"{nome}: diferenca media {d.mean():.2f}, maxima {d.max():.0f}")
        # Afinado a 22/10/2026: imagens iguais dao media < 0,5 e maxima < 25;
        # uma linha partida noutro sitio deu maxima 48.
        if d.mean() > 1.5 or d.max() > 35:
            sys.exit(f"ERRO: {nome} difere do aprovado (texto noutro sitio?). "
                     "Ver as duas imagens lado a lado antes de agendar.")
        urls.append(url + nome)
    print("\nENDERECOS (pela ordem, para o Metricool):")
    for u in urls:
        print(u)


if __name__ == "__main__":
    main()
