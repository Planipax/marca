#!/usr/bin/env python3
"""
Sorteia a familia visual da proxima publicacao.

Uso:  python3 escolher.py                       sorteio livre
      python3 escolher.py creme cinza           evita estas (as ultimas usadas)

A FAMILIA e aleatoria, para dar variedade ao feed.
A FOTOGRAFIA nao e: se sair uma familia com fotografia, o script devolve o
catalogo e a escolha e tua, por relacao com o tema. Uma imagem que nada tem a
ver com o assunto e pior do que nao ter imagem nenhuma.
"""
import json, random, sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
CATALOGO = RAIZ / "assets" / "fotos" / "catalogo.json"

# A lista vem do render.py, que e onde as familias existem de facto. Ate
# 17/9/2026 estava aqui escrita a mao e tinha ficado para tras: sorteava
# 'risco' e 'numero', ja cortadas, e nunca sorteava as quatro de 16/9/2026.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from render import FAMILIAS as _FAM, PRECISA_FOTO as COM_FOTO   # noqa: E402

FAMILIAS = list(_FAM)
SEM_FOTO = [f for f in FAMILIAS if f not in COM_FOTO]


def escolher(evitar=()):
    opcoes = [f for f in FAMILIAS if f not in evitar] or FAMILIAS
    fam = random.choice(opcoes)
    saida = {"familia": fam}
    if fam in COM_FOTO:
        fotos = json.loads(CATALOGO.read_text(encoding="utf-8"))
        saida["instrucao"] = (
            "Escolhe a fotografia pela relacao com o tema desta publicacao. "
            "Na 'foto' e na 'meia' a fotografia so aparece na capa (e, na 'foto', tambem no slide final); na 'filme' aparece em todos os slides. "
            "Se nenhuma se relacionar com o assunto, NAO forces: usa antes uma "
            "das familias sem fotografia indicadas abaixo. "
            "As fotografias de categoria 'escritorio' sao so para conteudo "
            "institucional sobre a Planipax.")
        saida["alternativas_sem_foto"] = [f for f in SEM_FOTO if f not in evitar]
        saida["catalogo"] = [
            {k: f[k] for k in ("ficheiro", "categoria", "descricao")} for f in fotos]
    return saida


if __name__ == "__main__":
    evitar = tuple(sys.argv[1:])
    # Um nome errado ('cremes', 'Foto') era ignorado em silencio e a familia que
    # se queria evitar podia sair no sorteio. Passa a ser erro.
    invalidas = [f for f in evitar if f not in FAMILIAS]
    if invalidas:
        print(f"ERRO: familia(s) inexistente(s): {', '.join(invalidas)}. "
              f"Aceites: {', '.join(FAMILIAS)}", file=sys.stderr)
        sys.exit(2)
    print(json.dumps(escolher(evitar), ensure_ascii=False, indent=1))
