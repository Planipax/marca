#!/usr/bin/env python3
"""
Gera um Reel da Planipax (1080x1920, 30 fps, H.264 + AAC) a partir de um roteiro.

Uso:
  python3 reel.py roteiro.json saida/                     # voz de trabalho
  python3 reel.py roteiro.json saida/ --voz-externa vozes/ # cena01.mp3, cena02.mp3...
  python3 reel.py roteiro.json saida/ --so-capa            # só a capa (rápido)

Deixa em saida/:
  reel.mp4        o vídeo
  capa.png        a capa (1080x1920), para carregar à parte no Metricool
  folha.png       folha de revisão: a capa + o fim de cada cena, lado a lado
  roteiro.json    cópia exata do roteiro usado
  NAO_ENVIAR.txt  só se a verificação automática encontrou problemas

Valida o roteiro antes de gerar (código 3, nada gerado) e verifica a
composição depois (sobreposições, objetos fora da zona segura do Instagram).
O formato do roteiro e as regras estão em referencias/reel.md.
"""
import asyncio, json, shutil, subprocess, sys, tempfile, wave
from pathlib import Path

AQUI = Path(__file__).resolve().parent
ASSETS = AQUI.parent.parent / "assets"
sys.path.insert(0, str(AQUI))
import voz, som  # noqa: E402

FPS = 30
GAP = 0.32              # pausa entre cenas
LEAD = 0.12             # o vídeo abre já com imagem: sem segundo em branco
CARTAO_FINAL = 3.0
ESCALA = 1.24           # as cenas são desenhadas a 540x960 e ampliadas à volta de (270, 600)
ZONA = dict(x0=8, x1=532, y1=800)   # abaixo de 800 (de 960) estão o nome e os botões do Instagram
MARCADOR = "NAO_ENVIAR.txt"

TIPOS = {"dr", "tel", "fatura", "carimbo", "badge", "sinal", "cal", "moeda", "edificio",
         "carrinha", "extrato", "fracao", "grafico", "tesouraria", "ok", "mao", "realce",
         "documento", "nota", "lista", "foto", "pasta", "mapa", "mensagem", "portugal"}
ANIMS = {"sobe", "pop", "carimbo", "cai", "esq", "dir", "desenha", "mao"}
CAMPOS_FIG = {"tipo", "x", "y", "t", "anim", "dur", "rot", "z", "id", "esc", "sai", "voo", "txt",
              "w", "h", "saldo", "flutua", "move", "cor",
              "cab", "titulo", "empresa", "ano", "linhas", "resultado", "num", "total", "ilus", "rotulo",
              "itens", "seq", "n", "cheias", "nota", "img", "pinos", "msgs", "passo", "foco", "alinha"}
CAMPOS_CENA = {"texto", "voz", "tam", "figs"}
CAMPOS_TOPO = {"titulo", "capa", "cenas", "cta", "ritmo"}
CAMPOS_CAPA = {"etiqueta", "titulo", "figs", "chamada"}


def erro(msg):
    print(f"\nROTEIRO RECUSADO: {msg}\nNada foi gerado.", file=sys.stderr)
    sys.exit(3)


def validar(r):
    avisos = []
    for k in r:
        if k not in CAMPOS_TOPO:
            erro(f"campo desconhecido no topo: «{k}»")
    if "capa" not in r or not r["capa"].get("titulo"):
        erro("falta a capa (com «titulo», lista de linhas)")
    for k in r["capa"]:
        if k not in CAMPOS_CAPA:
            erro(f"campo desconhecido na capa: «{k}»")
    cenas = r.get("cenas", [])
    if not 6 <= len(cenas) <= 12:
        erro(f"{len(cenas)} cenas; um Reel tem entre 6 e 12")
    ids = {}
    for i, c in enumerate(cenas, 1):
        for k in c:
            if k not in CAMPOS_CENA:
                erro(f"cena {i}: campo desconhecido «{k}»")
        if not c.get("texto"):
            erro(f"cena {i}: falta o «texto»")
        if c["texto"].count("*") % 2:
            erro(f"cena {i}: asteriscos desemparelhados no texto")
        if not c.get("figs"):
            erro(f"cena {i}: sem objetos. Num Reel cada cena mostra alguma coisa")
        if "voz" in c:
            a = [w.strip(".,:;?!*").lower() for w in c["texto"].split()]
            b = [w.strip(".,:;?!*").lower() for w in c["voz"].split()]
            if len(a) != len(b):
                avisos.append(f"cena {i}: «voz» e «texto» têm números de palavras diferentes "
                              "-- o texto no ecrã tem de ser o que o narrador diz")
        if len(c["texto"].replace("*", "").split()) > 22:
            avisos.append(f"cena {i}: mais de 22 palavras; parte a cena em duas")
        for f in c["figs"]:
            for k in f:
                if k not in CAMPOS_FIG:
                    erro(f"cena {i}: campo desconhecido num objeto: «{k}»")
            if f.get("tipo") not in TIPOS:
                erro(f"cena {i}: tipo de objeto desconhecido «{f.get('tipo')}». Existem: {', '.join(sorted(TIPOS))}")
            if f.get("anim", "sobe") not in ANIMS:
                erro(f"cena {i}: animação desconhecida «{f.get('anim')}»")
            if "x" not in f or "y" not in f:
                erro(f"cena {i}: objeto «{f['tipo']}» sem x/y")
            if f["tipo"] in ("carimbo", "badge") and not f.get("txt"):
                erro(f"cena {i}: «{f['tipo']}» sem «txt»")
            if f["tipo"] == "foto" and not f.get("img"):
                erro(f"cena {i}: «foto» sem «img» (ficheiro do catálogo)")
            if f["tipo"] == "realce" and not (f.get("w") and f.get("h")):
                erro(f"cena {i}: «realce» sem «w» e «h»")
            if f.get("id"):
                ant = ids.get(f["id"])
                if ant and ant[1] != f["tipo"]:
                    erro(f"cena {i}: o id «{f['id']}» já é um «{ant[1]}»")
                if ant and ant[0] != i - 1:
                    erro(f"cena {i}: o objeto persistente «{f['id']}» só pode continuar na cena seguinte "
                         f"(apareceu na {ant[0]})")
                ids[f["id"]] = (i, f["tipo"])
    return avisos


def blocos(c, ini, dur):
    """Tempo de cada palavra do título, proporcional ao número de letras."""
    palavras = c["texto"].split()
    tot = sum(len(p) + 2 for p in palavras)
    acc, ws = ini, []
    for p in palavras:
        d = dur * (len(p) + 2) / tot
        ws.append([p, acc, acc + d]); acc += d
    return [ws]


def silencio(p, s):
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "anullsrc=r=44100:cl=mono",
                    "-t", f"{s:.3f}", str(p)], check=True)


FOTOS_URL = "https://raw.githubusercontent.com/Planipax/marca/main/"


def obter_fotos(r, pasta):
    """Fotografias do catálogo (objeto «foto»), do GitHub, como no carrossel."""
    import urllib.request
    pasta.mkdir(parents=True, exist_ok=True)
    catalogo = {f["ficheiro"] for f in json.loads((ASSETS / "fotos" / "catalogo.json").read_text(encoding="utf-8"))}
    figs = list(r["capa"].get("figs", [])) + [f for c in r["cenas"] for f in c["figs"]]
    for nome in sorted({f["img"] for f in figs if f["tipo"] == "foto"}):
        if nome not in catalogo:
            erro(f"a fotografia «{nome}» não está em assets/fotos/catalogo.json")
        destino = pasta / nome
        if destino.exists():
            continue
        local = ASSETS / "fotos" / nome
        if local.exists():
            shutil.copy(local, destino); continue
        try:
            urllib.request.urlretrieve(FOTOS_URL + nome, destino)
        except Exception as e:
            erro(f"não consegui obter a fotografia «{nome}» do GitHub: {e}")


def pagina(r, dados, modo, tmp):
    html = (AQUI / "modelo.html").read_text(encoding="utf-8")
    d = dict(dados, modo=modo, rot=r)
    html = html.replace("/*DADOS*/", "const D=" + json.dumps(d, ensure_ascii=False) + ";")
    html = html.replace("{SK}", ASSETS.as_uri()).replace("{FOTOS}", (tmp / "fotos").as_uri())
    p = tmp / f"{modo}.html"
    p.write_text(html, encoding="utf-8")
    return p


def problemas_de(m, onde):
    out = []
    tit = m["titulo"]
    for f in m["figs"]:
        if f["x0"] < ZONA["x0"] or f["x1"] > ZONA["x1"]:
            out.append(f"{onde}: «{f['id']}» sai pelos lados ({f['x0']:.0f}–{f['x1']:.0f} de 540)")
        if f["y1"] > ZONA["y1"]:
            out.append(f"{onde}: «{f['id']}» desce até {f['y1']:.0f} (de 960); abaixo de {ZONA['y1']} "
                       "fica tapado pelo nome e pelos botões do Instagram")
        if tit and f["y0"] < tit["y1"] + 6 and f["x1"] > tit["x0"] and f["x0"] < tit["x1"]:
            out.append(f"{onde}: «{f['id']}» toca no título (título acaba em {tit['y1']:.0f}, objeto começa em {f['y0']:.0f})")
    return out


async def gerar(r, saida, tmp, total, fim_voz, so_capa):
    from playwright.async_api import async_playwright
    dados = dict(total=total, fim_voz=fim_voz, segundos=int(round(total / 5.0) * 5))
    problemas, quadros = [], []
    async with async_playwright() as p:
        b = await p.chromium.launch(args=["--font-render-hinting=none"])
        pg = await b.new_page(viewport={"width": 540, "height": 960}, device_scale_factor=2)
        # capa
        await pg.goto(pagina(r, dados, "capa", tmp).as_uri())
        await pg.evaluate("document.fonts.ready.then(()=>true)"); await pg.wait_for_timeout(300)
        await pg.screenshot(path=str(saida / "capa.png"))
        problemas += problemas_de(await pg.evaluate("medir(0)"), "capa")
        if so_capa:
            await b.close(); return problemas, []
        # vídeo
        await pg.goto(pagina(r, dados, "video", tmp).as_uri())
        await pg.evaluate("document.fonts.ready.then(()=>true)"); await pg.wait_for_timeout(500)
        falhas = await pg.evaluate("""()=>[...document.fonts].filter(f=>f.status==='error').map(f=>f.family)
                                     .concat([...document.images].filter(i=>!i.complete||!i.naturalWidth).map(i=>i.src))""")
        problemas += [f"recurso não carregou: {x}" for x in falhas]
        fins = []
        for i, c in enumerate(r["cenas"]):
            fim = (r["cenas"][i + 1]["ini"] - 0.25) if i + 1 < len(r["cenas"]) else fim_voz - 0.5
            fins.append(fim)
        n = int(total * FPS)
        ff = subprocess.Popen(["ffmpeg", "-loglevel", "error", "-y", "-f", "image2pipe", "-framerate", str(FPS),
                               "-c:v", "mjpeg", "-i", "-", "-i", str(tmp / "audio.wav"),
                               "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p",
                               "-r", str(FPS), "-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-shortest",
                               "-movflags", "+faststart", str(saida / "reel.mp4")], stdin=subprocess.PIPE)
        prox = 0
        for k in range(n):
            t = k / FPS
            await pg.evaluate(f"render({t})")
            jpg = await pg.screenshot(type="jpeg", quality=92)
            ff.stdin.write(jpg)
            if prox < len(fins) and t >= fins[prox]:
                problemas += problemas_de(await pg.evaluate(f"medir({prox})"), f"cena {prox + 1}")
                q = tmp / f"q{prox:02d}.jpg"; q.write_bytes(jpg); quadros.append(q)
                prox += 1
        ff.stdin.close(); ff.wait()
        await b.close()
        if ff.returncode:
            problemas.append("o ffmpeg falhou a codificar o vídeo")
    return problemas, quadros


def folha(saida, quadros):
    from PIL import Image
    ims = [Image.open(saida / "capa.png")] + [Image.open(q) for q in quadros]
    w, h = 270, 480
    cols = 7
    linhas = (len(ims) + cols - 1) // cols
    o = Image.new("RGB", (cols * w, linhas * h), "white")
    for k, im in enumerate(ims):
        o.paste(im.convert("RGB").resize((w, h)), ((k % cols) * w, (k // cols) * h))
    o.save(saida / "folha.png")


def main(argv):
    args, externa, so_capa = [], None, False
    it = iter(argv)
    for a in it:
        if a == "--voz-externa":
            externa = Path(next(it))
        elif a == "--so-capa":
            so_capa = True
        else:
            args.append(a)
    if len(args) != 2:
        print(__doc__); sys.exit(2)
    roteiro, saida = Path(args[0]), Path(args[1])
    r = json.loads(roteiro.read_text(encoding="utf-8"))
    avisos = validar(r)
    saida.mkdir(parents=True, exist_ok=True)
    for f in ("reel.mp4", "capa.png", "folha.png", MARCADOR):
        (saida / f).unlink(missing_ok=True)
    shutil.copy(roteiro, saida / "roteiro.json")
    tmp = Path(tempfile.mkdtemp(prefix="reel_"))
    obter_fotos(r, tmp / "fotos")

    # 1. voz, cena a cena
    t, partes = LEAD, []
    silencio(tmp / "lead.wav", LEAD); silencio(tmp / "gap.wav", GAP)
    partes.append(tmp / "lead.wav")
    for i, c in enumerate(r["cenas"], 1):
        w = tmp / f"v{i:02d}.wav"
        if so_capa:
            silencio(w, max(1.5, len(c["texto"].split()) * 0.36))
        elif externa:
            cand = sorted(externa.glob(f"cena{i:02d}.*"))
            if not cand:
                erro(f"falta a voz externa da cena {i}: {externa}/cena{i:02d}.mp3 (ou .wav/.m4a)")
            voz.voz_externa(cand[0], str(w))
        elif voz.usa_elevenlabs():
            fala = lambda k: (r["cenas"][k].get("voz") or r["cenas"][k]["texto"].replace("*", "")) \
                if 0 <= k < len(r["cenas"]) else ""
            voz.voz_elevenlabs(fala(i - 1), str(w), fala(i - 2), fala(i))
        else:
            voz.voz_de_trabalho(c.get("voz") or c["texto"].replace("*", ""), str(w), r.get("ritmo", 1.06))
        d = voz.duracao(str(w))
        c["ini"], c["dur"] = t, d
        c["blocos"] = blocos(c, t, d)
        partes += [w, tmp / "gap.wav"]
        t += d + GAP
    fim_voz = t
    total = fim_voz + CARTAO_FINAL
    if total > 90:
        erro(f"o vídeo daria {total:.0f} s; o Facebook só aceita Reels até 90 s pela API. Corta cenas.")
    if total > 60:
        avisos.append(f"o vídeo tem {total:.0f} s; acima de 60 s a retenção cai muito")
    (tmp / "lista.txt").write_text("".join(f"file '{p}'\n" for p in partes))
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-f", "concat", "-safe", "0", "-i", str(tmp / "lista.txt"),
                    "-ar", "44100", "-ac", "1", str(tmp / "voz.wav")], check=True)

    # 2. música original e efeitos sincronizados
    if not so_capa:
        som.montar(r, total, str(tmp / "voz.wav"), str(tmp / "audio.wav"))

    # 3. imagem, verificação e folha de revisão
    problemas, quadros = asyncio.run(gerar(r, saida, tmp, total, fim_voz, so_capa))
    if quadros:
        folha(saida, quadros)
    shutil.rmtree(tmp, ignore_errors=True)

    print()
    if problemas:
        print("NÃO ENVIAR: há problemas")
        for p in problemas:
            print("  -", p)
        (saida / MARCADOR).write_text("\n".join(problemas) + "\n", encoding="utf-8")
    else:
        print("Verificação automática sem problemas.")
    for a in avisos:
        print("  aviso:", a)
    if not so_capa:
        print(f"\nreel.mp4: {total:.1f} s · {len(r['cenas'])} cenas · voz {'externa' if externa else ('ElevenLabs' if voz.usa_elevenlabs() else 'de trabalho')}")
    print(f"Pasta: {saida}")
    sys.exit(1 if problemas else 0)


if __name__ == "__main__":
    main(sys.argv[1:])
