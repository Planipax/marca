"""Voz do narrador dos Reels.

Duas fontes, pela ordem de preferência:
  1. Voz externa (ElevenLabs, Azure ou gravação de uma pessoa da equipa):
     um ficheiro por cena, cena01.mp3, cena02.mp3... numa pasta. É a voz de
     publicação.
  2. Voz de trabalho: o modelo «tugão» (Piper, português de Portugal), gerado
     aqui sem rede para além do GitHub. Serve para aprovar o vídeo. A licença do
     modelo não é inequívoca para uso comercial (o conjunto de gravações é CC0,
     mas o modelo foi afinado a partir de outro) -- ver referencias/reel.md.

As vozes «dii» e «miro» (pt-PT, melhor qualidade) existem mas são CC BY-NC-SA:
proibido uso comercial. Não as uses.
"""
import re, subprocess, sys, tarfile, tempfile, os, wave, urllib.request
from pathlib import Path
import numpy as np

URL_MODELO = ("https://github.com/k2-fsa/sherpa-onnx/releases/download/"
              "tts-models/vits-piper-pt_PT-tugao-medium.tar.bz2")
CACHE = Path(os.environ.get("PLANIPAX_CACHE", Path.home() / ".cache" / "planipax-voz"))
ONNX = CACHE / "vits-piper-pt_PT-tugao-medium" / "pt_PT-tugao-medium.onnx"

# Tratamento de som da voz: calor, presença, compressão, sala muito curta,
# volume normalizado para redes sociais (-16 LUFS).
FX_VOZ = ("highpass=f=75,equalizer=f=170:t=q:w=1:g=2.5,equalizer=f=3200:t=q:w=1.2:g=2,"
          "equalizer=f=7500:t=q:w=1:g=-2,acompressor=threshold=-20dB:ratio=3:attack=8:release=120:makeup=2,"
          "aecho=0.85:0.5:28|46:0.06|0.04,aresample=44100,loudnorm=I=-16:TP=-1.5:LRA=7")
FX_EXTERNA = "highpass=f=60,aresample=44100,loudnorm=I=-16:TP=-1.5:LRA=7"

_voz = None


def _garantir_piper():
    try:
        import piper  # noqa: F401
    except ImportError:
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--break-system-packages", "piper-tts"],
                       check=True)


def obter_modelo():
    if ONNX.exists():
        return ONNX
    CACHE.mkdir(parents=True, exist_ok=True)
    tmp = CACHE / "modelo.tar.bz2"
    print("A descarregar a voz de trabalho (60 MB, uma vez por sessão)...", flush=True)
    try:
        urllib.request.urlretrieve(URL_MODELO, tmp)
    except Exception as e:
        raise SystemExit(f"\nNão consegui descarregar a voz de trabalho.\n  {URL_MODELO}\n  {e}\n"
                         "Sem ela, só é possível gerar com --voz-externa.\n")
    with tarfile.open(tmp) as t:
        t.extractall(CACHE)
    tmp.unlink()
    return ONNX


def _carregar():
    global _voz
    if _voz is None:
        _garantir_piper()
        from piper import PiperVoice
        _voz = PiperVoice.load(str(obter_modelo()))
    return _voz


def _sint(v, txt, ls):
    from piper import SynthesisConfig
    cfg = SynthesisConfig(length_scale=ls, noise_scale=0.72, noise_w_scale=0.92)
    return np.concatenate([np.frombuffer(c.audio_int16_bytes, dtype=np.int16)
                           for c in v.synthesize(txt, syn_config=cfg)])


def voz_de_trabalho(texto, saida, ritmo=1.06):
    """Frase partida em grupos de sentido, pausas naturais, abranda no fim."""
    v = _carregar()
    sr = v.config.sample_rate
    partes = [p.strip() for p in re.split(r'(?<=[,:;])\s+', texto) if p.strip()]
    audio = []
    for i, p in enumerate(partes):
        ls = ritmo * (1.04 if i == len(partes) - 1 else 0.98 + 0.03 * (i % 2))
        a = _sint(v, p, ls)
        nz = np.where(np.abs(a) > 300)[0]
        if len(nz):
            a = a[max(0, nz[0] - int(.02 * sr)): nz[-1] + int(.06 * sr)]
        audio.append(a)
        if i < len(partes) - 1:
            audio.append(np.zeros(int((0.22 if p.endswith(':') else 0.16) * sr), dtype=np.int16))
    tmp = tempfile.mktemp(suffix=".wav")
    with wave.open(tmp, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes(np.concatenate(audio).tobytes())
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", tmp, "-af", FX_VOZ, "-ac", "1", "-ar", "44100", saida],
                   check=True)
    os.remove(tmp)


def voz_externa(ficheiro, saida):
    """Normaliza e apara o silêncio das pontas de um ficheiro gravado ou gerado fora."""
    af = ("silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.03,"
          "areverse,silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.08,areverse," + FX_EXTERNA)
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", str(ficheiro), "-af", af, "-ac", "1", "-ar", "44100", saida],
                   check=True)


def duracao(wav):
    with wave.open(wav) as f:
        return f.getnframes() / f.getframerate()
