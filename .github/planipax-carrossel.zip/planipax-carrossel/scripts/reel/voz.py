"""Voz do narrador dos Reels.

Três fontes, pela ordem de preferência:
  0. ElevenLabs pela API, quando existem as variáveis ELEVENLABS_API_KEY e
     ELEVENLABS_VOICE_ID (só no GitHub: a chave é um segredo do repositório e o
     container do agente não chega à API). É a voz de publicação desde 30/10/2026.
  1. Voz externa (ElevenLabs, Azure ou gravação de uma pessoa da equipa):
     um ficheiro por cena, cena01.mp3, cena02.mp3... numa pasta. É a voz de
     publicação.
  2. Voz de trabalho: o modelo «tugão» (Piper, português de Portugal), gerado
     aqui sem rede para além do GitHub. Serve para aprovar o vídeo. A licença do
     modelo não é inequívoca para uso comercial (o conjunto de gravações é CC0,
     mas o modelo foi afinado a partir de outro) -- ver referencias/reel.md.

As vozes «dii» e «miro» (pt-PT, melhor qualidade) existem mas são CC BY-NC-SA:
proibido uso comercial. Não as uses.
"""
import re, subprocess, sys, tarfile, tempfile, os, wave, urllib.request
from pathlib import Path
import numpy as np

URL_MODELO = ("https://github.com/k2-fsa/sherpa-onnx/releases/download/"
              "tts-models/vits-piper-pt_PT-tugao-medium.tar.bz2")
CACHE = Path(os.environ.get("PLANIPAX_CACHE", Path.home() / ".cache" / "planipax-voz"))
ONNX = CACHE / "vits-piper-pt_PT-tugao-medium" / "pt_PT-tugao-medium.onnx"

# Tratamento de som da voz: calor, presença, compressão, sala muito curta,
# volume normalizado para redes sociais (-16 LUFS).
FX_VOZ = ("highpass=f=75,equalizer=f=170:t=q:w=1:g=2.5,equalizer=f=3200:t=q:w=1.2:g=2,"
          "equalizer=f=7500:t=q:w=1:g=-2,acompressor=threshold=-20dB:ratio=3:attack=8:release=120:makeup=2,"
          "aecho=0.85:0.5:28|46:0.06|0.04,aresample=44100,loudnorm=I=-16:TP=-1.5:LRA=7")
FX_EXTERNA = "highpass=f=60,aresample=44100,loudnorm=I=-16:TP=-1.5:LRA=7"

_voz = None


def _garantir_piper():
    try:
        import piper  # noqa: F401
    except ImportError:
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--break-system-packages", "piper-tts"],
                       check=True)


def obter_modelo():
    if ONNX.exists():
        return ONNX
    CACHE.mkdir(parents=True, exist_ok=True)
    tmp = CACHE / "modelo.tar.bz2"
    print("A descarregar a voz de trabalho (60 MB, uma vez por sessão)...", flush=True)
    try:
        urllib.request.urlretrieve(URL_MODELO, tmp)
    except Exception as e:
        raise SystemExit(f"\nNão consegui descarregar a voz de trabalho.\n  {URL_MODELO}\n  {e}\n"
                         "Sem ela, só é possível gerar com --voz-externa.\n")
    with tarfile.open(tmp) as t:
        t.extractall(CACHE)
    tmp.unlink()
    return ONNX


def _modelo_fixo():
    """Cópia do modelo com a parte aleatória fixa (semente nos dois nós
    RandomNormalLike). Sem isto a mesma frase sai cada vez com outro ritmo, e o
    vídeo que o GitHub gera deixa de ser igual ao que o Ricardo aprovou (visto
    a 29/10/2026: 36,8 s numa geração, 37,1 s na seguinte)."""
    orig = obter_modelo()
    fixo = orig.with_name(orig.stem + "-fixo.onnx")
    if not fixo.exists():
        try:
            import onnx
        except ImportError:
            subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--break-system-packages", "onnx"],
                           check=True)
            import onnx
        g = onnx.load(str(orig))
        for k, n in enumerate([n for n in g.graph.node if n.op_type == "RandomNormalLike"]):
            if not any(a.name == "seed" for a in n.attribute):
                n.attribute.append(onnx.helper.make_attribute("seed", float(7 + k)))
        onnx.save(g, str(fixo))
    return fixo, orig.with_suffix(".onnx.json")


def _carregar():
    global _voz
    if _voz is None:
        _garantir_piper()
        from piper import PiperVoice
        fixo, cfg = _modelo_fixo()
        _voz = PiperVoice.load(str(fixo), config_path=str(cfg))
    return _voz


def _sint(v, txt, ls):
    from piper import SynthesisConfig
    cfg = SynthesisConfig(length_scale=ls, noise_scale=0.72, noise_w_scale=0.92)
    return np.concatenate([np.frombuffer(c.audio_int16_bytes, dtype=np.int16)
                           for c in v.synthesize(txt, syn_config=cfg)])


def voz_de_trabalho(texto, saida, ritmo=1.06):
    """Frase partida em grupos de sentido, pausas naturais, abranda no fim."""
    v = _carregar()
    sr = v.config.sample_rate
    partes = [p.strip() for p in re.split(r'(?<=[,:;])\s+', texto) if p.strip()]
    audio = []
    for i, p in enumerate(partes):
        ls = ritmo * (1.04 if i == len(partes) - 1 else 0.98 + 0.03 * (i % 2))
        a = _sint(v, p, ls)
        nz = np.where(np.abs(a) > 300)[0]
        if len(nz):
            a = a[max(0, nz[0] - int(.02 * sr)): nz[-1] + int(.06 * sr)]
        audio.append(a)
        if i < len(partes) - 1:
            audio.append(np.zeros(int((0.22 if p.endswith(':') else 0.16) * sr), dtype=np.int16))
    tmp = tempfile.mktemp(suffix=".wav")
    with wave.open(tmp, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes(np.concatenate(audio).tobytes())
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", tmp, "-af", FX_VOZ, "-ac", "1", "-ar", "44100", saida],
                   check=True)
    os.remove(tmp)


def voz_externa(ficheiro, saida):
    """Normaliza e apara o silêncio das pontas de um ficheiro gravado ou gerado fora."""
    af = ("silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.03,"
          "areverse,silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.08,areverse," + FX_EXTERNA)
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", str(ficheiro), "-af", af, "-ac", "1", "-ar", "44100", saida],
                   check=True)


API_11 = "https://api.elevenlabs.io/v1/text-to-speech/{voz}?output_format=mp3_44100_128"


def usa_elevenlabs():
    return bool(os.environ.get("ELEVENLABS_API_KEY") and os.environ.get("ELEVENLABS_VOICE_ID"))


def voz_elevenlabs(texto, saida, anterior="", seguinte=""):
    """Uma cena pela API da ElevenLabs. O texto das cenas vizinhas vai como
    contexto (previous_text/next_text) para a entoação seguir a frase anterior
    e preparar a seguinte, como numa leitura corrida."""
    import json, time, urllib.error
    corpo = {"text": texto,
             "model_id": os.environ.get("ELEVENLABS_MODEL", "eleven_multilingual_v2"),
             "seed": 7,
             "voice_settings": {"stability": 0.5, "similarity_boost": 0.75,
                                "style": 0.15, "use_speaker_boost": True}}
    if anterior:
        corpo["previous_text"] = anterior
    if seguinte:
        corpo["next_text"] = seguinte
    pedido = urllib.request.Request(
        API_11.format(voz=os.environ["ELEVENLABS_VOICE_ID"]),
        data=json.dumps(corpo).encode("utf-8"), method="POST",
        headers={"xi-api-key": os.environ["ELEVENLABS_API_KEY"],
                 "Content-Type": "application/json", "Accept": "audio/mpeg"})
    for tentativa in range(4):
        try:
            with urllib.request.urlopen(pedido, timeout=120) as r:
                audio = r.read()
            break
        except urllib.error.HTTPError as e:
            detalhe = e.read()[:300].decode("utf-8", "replace")
            if e.code in (429, 500, 502, 503) and tentativa < 3:
                time.sleep(5 * (tentativa + 1)); continue
            sys.exit(f"ERRO ElevenLabs {e.code}: {detalhe}")
        except urllib.error.URLError as e:
            if tentativa < 3:
                time.sleep(5 * (tentativa + 1)); continue
            sys.exit(f"ERRO ElevenLabs: sem ligacao ({e.reason})")
    tmp = tempfile.mktemp(suffix=".mp3")
    Path(tmp).write_bytes(audio)
    voz_externa(tmp, saida)
    os.remove(tmp)


def duracao(wav):
    with wave.open(wav) as f:
        return f.getnframes() / f.getframerate()
