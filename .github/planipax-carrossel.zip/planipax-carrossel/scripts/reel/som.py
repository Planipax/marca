"""Música original e efeitos sonoros sintetizados (sem direitos de terceiros).
Os efeitos são disparados pelos mesmos tempos das animações do roteiro."""
import numpy as np, subprocess, wave

SR = 44100
rng = np.random.default_rng(7)

def env(n, a=0.005, d=0.3):
    t = np.arange(n) / SR
    return np.minimum(1, t / a) * np.exp(-t / d)

def nota(f, dur, vol=1.0, brilho=0.25, d=0.9):
    n = int(dur * SR); t = np.arange(n) / SR
    s = np.sin(2*np.pi*f*t) + brilho*np.sin(2*np.pi*2*f*t)*np.exp(-t*3) + 0.08*np.sin(2*np.pi*3*f*t)*np.exp(-t*5)
    return vol * s * env(n, 0.008, d)

def hz(m): return 440 * 2 ** ((m - 69) / 12)

def musica(total, bpm=92):
    n = int((total + 1) * SR); out = np.zeros(n)
    batida = 60 / bpm; compasso = 4 * batida
    # Fmaj7 - Am7 - Dm7 - Bbmaj7 (tom quente, sem dramatismo)
    acordes = [[53, 57, 60, 64], [57, 60, 64, 67], [50, 57, 60, 65], [46, 53, 57, 62]]
    baixos = [41, 45, 38, 34]
    k = 0; t0 = 0.0
    while t0 < total + 1:
        ac = acordes[k % 4]
        for b in range(4):                      # piano em semínimas, arpejo suave
            tt = t0 + b * batida
            for j, m in enumerate(ac if b == 0 else ac[1:] if b == 2 else [ac[(b + 1) % 4] + 12]):
                s = nota(hz(m), 1.6, 0.11 if b == 0 else 0.07, d=0.8)
                i = int((tt + j * 0.012) * SR); out[i:i + len(s)] += s[:max(0, n - i)]
        s = nota(hz(baixos[k % 4]), compasso, 0.20, brilho=0.05, d=1.6)   # baixo
        i = int(t0 * SR); out[i:i + len(s)] += s[:max(0, n - i)]
        for b in range(8):                      # batida leve: bombo nos tempos 1 e 3, shaker nos contratempos
            tt = t0 + b * batida / 2; i = int(tt * SR)
            if b in (0, 4):
                m = int(0.25 * SR); t = np.arange(m) / SR
                kick = np.sin(2*np.pi*(55 + 70*np.exp(-t*40))*t) * env(m, 0.002, 0.09) * 0.28
                out[i:i + m] += kick[:max(0, n - i)]
            if b % 2 == 1:
                m = int(0.06 * SR); sh = rng.normal(0, 1, m) * env(m, 0.004, 0.018) * 0.035
                sh = np.diff(np.concatenate([[0], sh]))  # agudos
                out[i:i + m] += sh[:max(0, n - i)]
        t0 += compasso; k += 1
    return out[:int(total * SR)]

# ---- efeitos ----
def sfx_whoosh():
    n = int(0.45 * SR); x = rng.normal(0, 1, n); t = np.arange(n) / SR
    y = np.zeros(n); a = 0.0
    for i in range(n):                          # filtro passa-baixo com corte a subir e descer
        c = 0.02 + 0.25 * np.sin(np.pi * t[i] / 0.45)
        a += c * (x[i] - a); y[i] = a
    return y * np.sin(np.pi * t / 0.45) ** 2 * 0.35
def sfx_pop():
    n = int(0.12 * SR); t = np.arange(n) / SR
    return np.sin(2*np.pi*(820 - 2600*t)*t) * env(n, 0.002, 0.035) * 0.35
def sfx_carimbo():
    n = int(0.35 * SR); t = np.arange(n) / SR
    thump = np.sin(2*np.pi*(95 + 60*np.exp(-t*30))*t) * env(n, 0.001, 0.07)
    clack = rng.normal(0, 1, n) * env(n, 0.0005, 0.012)
    return (thump * 0.75 + clack * 0.35) * 0.8
def sfx_moeda():
    n = int(0.6 * SR); t = np.arange(n) / SR
    s = sum(a * np.sin(2*np.pi*f*t) * np.exp(-t*d) for f, a, d in [(2093, .5, 9), (3349, .35, 12), (4978, .2, 16), (6300, .1, 22)])
    return s * np.minimum(1, t / 0.001) * 0.3
def sfx_folha():
    n = int(0.12 * SR); x = rng.normal(0, 1, n)
    return np.diff(np.concatenate([[0], x])) * env(n, 0.002, 0.03) * 0.12
def sfx_ok():
    return np.concatenate([nota(hz(84), 0.12, 0.18, d=0.1)[:int(.1*SR)], nota(hz(88), 0.5, 0.18, d=0.25)])

EFEITO = {"sobe": sfx_whoosh, "esq": sfx_whoosh, "dir": sfx_whoosh, "cai": sfx_whoosh,
          "pop": sfx_pop, "carimbo": sfx_carimbo, "ok": sfx_ok, "mao": sfx_folha}

def eventos(rot):
    ev = []
    for c in rot["cenas"]:
        for f in c.get("figs", []):
            if f.get("dur", 0.55) < 0.05: continue           # objeto que já estava em cena
            t = c["ini"] + f.get("t", 0)
            if f.get("voo"): ev.append((t + f.get("dur", 1.0) * 0.95, sfx_moeda, 0.9)); continue
            if f["tipo"] == "ok": ev.append((t + 0.05, sfx_ok, 0.8)); continue
            if f["tipo"] == "cal":
                for k in range(1, 4): ev.append((t + 0.6 + (c["dur"] - 0.8) * k / 4, sfx_folha, 1.6))
            a = f.get("anim", "sobe")
            if a == "carimbo": ev.append((t + 0.22, sfx_carimbo, 1.0))
            elif a == "mao": ev.append((t + f.get("dur", 0.55) + 0.18, sfx_folha, 1.0))
            elif a in EFEITO: ev.append((max(0, t), EFEITO[a], 0.7))
    return ev

def ler(p):
    r = subprocess.run(["ffmpeg", "-loglevel", "error", "-i", p, "-f", "s16le", "-ac", "1", "-ar", str(SR), "-"], capture_output=True, check=True)
    return np.frombuffer(r.stdout, dtype=np.int16).astype(np.float64) / 32768

def montar(rot, total, voz_wav, saida):
    n = int(total * SR)
    voz = ler(voz_wav)[:n]; voz = np.pad(voz, (0, n - len(voz)))
    mus = musica(total)
    # ducking: a música baixa enquanto o narrador fala
    janela = int(0.05 * SR); e = np.sqrt(np.convolve(voz**2, np.ones(janela) / janela, "same"))
    alvo = np.where(e > 0.01, 0.38, 1.0)
    g = np.zeros(n); a = 1.0
    for i in range(0, n, 256):
        a += (alvo[i] - a) * (0.08 if alvo[i] < a else 0.02); g[i:i + 256] = a
    t = np.arange(n) / SR
    fade = np.minimum(1, t / 0.6) * np.minimum(1, (total - t) / 1.8)
    mix = voz * 1.0 + mus * g * fade * 0.55
    fx = np.zeros(n)
    for tt, f, vol in eventos(rot):
        s = f() * vol; i = int(tt * SR)
        if i < n: fx[i:i + len(s)] += s[:n - i]
    mix += fx * 0.55
    mix = np.tanh(mix * 1.1) / np.tanh(1.1)               # limitador suave
    st = np.stack([mix, mix], 1)
    with wave.open(saida, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((np.clip(st, -1, 1) * 32000).astype(np.int16).tobytes())
