#!/usr/bin/env python3
"""
Gera os slides de um carrossel Planipax em PNG 1080x1350.

Uso:   python3 render.py especificacao.json [pasta_de_saida] [--exemplo]

Valida a especificacao antes de desenhar (familia, 5-8 slides, capa primeiro e
final no fim, campos aceites por tipo, numeracao 01, 02, 03...). Com erros,
para sem gerar nada (codigo 3). Com problemas de composicao, gera na mesma mas
avisa no topo "NAO ENVIAR" e deixa NAO_ENVIAR.txt na pasta (codigo 2).
--exemplo relaxa o numero de slides e a numeracao (so para exemplos/).

A especificação é um JSON com a família escolhida e a lista de slides.
Ver exemplos/ para modelos prontos. O sistema de design está no SKILL.md.
"""
import base64, json, sys, asyncio
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
MARCA = RAIZ / "assets" / "marca"
FOTOS = RAIZ / "assets" / "fotos"
FONTES = RAIZ / "assets" / "fontes"

# ─────────────────────────────── tokens da marca ────────────────────────────
GOLD, GREY, CREAM, STONE, SAND = "#C79A59", "#515151", "#FAF8F4", "#EEECE7", "#F3EDE3"
# GREY e a cor do texto nas familias claras. GREY_FUNDO e o fundo das familias
# escuras: mais claro e mais quente, porque uma cor pensada para texto e escura
# demais para preencher um slide inteiro. GOLD_ESC e o dourado sobre fundo escuro
# -- o dourado normal so daria 2.4:1 sobre o fundo novo, abaixo do minimo.
GREY_FUNDO, GOLD_ESC = "#63605A", "#E0BE85"
_GOLD_BASE = GOLD
# GOLD_TXT e o dourado quando ele e TEXTO pequeno e nao um elemento grafico.
# Sobre fotografia o dourado nao se le a este tamanho -- nem o GOLD_ESC: nas
# familias com imagem por baixo do texto, as etiquetas e o "Fale connosco"
# ficavam entre 2,4:1 e 4,5:1, abaixo do minimo, em 11 das 29 fotografias do
# catalogo (medido a 17/9/2026, carrossel completo). Nessas familias este
# token e branco. O dourado continua no filete, na barra, no destaque e nos
# numeros grandes, que sao grandes o suficiente para aguentar.
GOLD_TXT = GOLD
W, H = 540, 675                     # tela de trabalho (x2 = 1080x1350)
M, CT, CB, FB, BB = 46, 100, 124, 74, 30   # margem, zona, rodapé, barra

CONTACTOS = {
    "beja":  ("Beja",  "Av. Miguel Fernandes 28A", "284 320 278"),
    "moura": ("Moura", "Avenida do Carmo 26",      "285 254 034"),
    "email": "geral.beja@planipax.pt · geral.moura@planipax.pt",
    "site":  "planipax.pt",
    "social": "@planipax",
    "assinatura": "Tratamos da contabilidade para<br>tratar do seu negócio.",
}

def b64(p, mime="image/png"):
    return f"data:{mime};base64,{base64.b64encode(Path(p).read_bytes()).decode()}"

ICONE   = b64(MARCA / "icone.png")
ICONE_B = b64(MARCA / "icone_branco.png")
WORD    = b64(MARCA / "wordmark.png")
WORD_B  = b64(MARCA / "wordmark_branco.png")
REDES = {c: {r: b64(MARCA / f"{r}_{c}.png") for r in ("facebook", "instagram", "linkedin")}
         for c in ("branco", "cinza")}

# ─────────────────────────────── famílias ───────────────────────────────────
# escuro=True -> texto branco e logotipo branco no rodape.
# 'deco' escolhe a decoracao: nenhuma/filete/marca/dividido/lateral/foto/filme/meia.
FAMILIAS = {
    "papel":     dict(fundo="#fff",  escuro=False, cartao_cor=STONE, deco="nenhuma"),
    "creme":     dict(fundo=CREAM,   escuro=False, cartao_cor="#fff", deco="filete"),
    # A 'cinza' passou a clara a 16/9/2026 e voltou a escura a 17/9. O motivo da
    # ida foi querer o logotipo original (cinzento e dourado), que sobre fundo
    # escuro desaparece. O motivo da volta foi medir: o feed real da Planipax
    # anda entre 0,04 e 0,37 de luminancia e o conjunto todo claro andava nos
    # 0,85. E o logotipo branco nao e outro logotipo -- e o mesmo em negativo, e
    # e o que a Planipax ja publica. Ver a tabela de familias no SKILL.md.
    "cinza":     dict(fundo=GREY_FUNDO, escuro=True, cartao_cor="rgba(255,255,255,.10)",
                      deco="marca"),
    # 'risco' e 'numero' sairam a 17/9/2026. Medidos slide a slide contra as
    # familias que ficam: 'risco' dava uma imagem IDENTICA a 'papel' no slide de
    # conteudo (diferenca media 0.00 -- o mesmo ficheiro) e so se distinguia por
    # um filete na capa; 'numero' dava 2.9 contra 'cinza', que e a distancia
    # entre STONE (#EEECE7) e SAND (#F3EDE3) -- cinco unidades, invisivel no
    # feed. Uma familia so se justifica se a diferenca durar o carrossel todo.
    # A faixa escura no topo empurra o texto 50px para baixo (a .zone comeca aos
    # 150 em vez dos 100). Com o corpo normal, um texto que assenta em todas as
    # outras familias transbordava aqui -- e como a familia e sorteada DEPOIS de
    # o texto estar escrito -- era assim o fluxo antigo -- isso era uma
    # armadilha. Hoje a familia sorteia-se ANTES de escrever (Passo 2 do
    # SKILL.md), mas a escala compacta fica, pela mesma razao que a 'meia':
    # quem gasta altura no topo escreve mais pequeno.
    "dividido":  dict(fundo=CREAM,   escuro=False, cartao_cor="#fff", deco="dividido",
                      escala="compacta"),
    "foto":      dict(fundo=GREY_FUNDO, escuro=True, cartao_cor="rgba(0,0,0,.32)", deco="foto"),

    # ── de 16/9/2026 ────────────────────────────────────────────────────────
    # As primeiras oito tinham todas a mesma arquitetura: etiqueta em cima a
    # esquerda, titulo, corpo. Mudar a cor do fundo nao disfarcava isso, e no
    # feed liam-se como versoes da mesma coisa. Estas mudam a silhueta.
    # Nasceram quatro: a 'centrada' e a 'desfocada' sairam a 17/9 (ver abaixo).
    # O 'envolve' mete uma caixa branca dentro da .zone. Essa caixa tem de ser
    # ela propria uma coluna flex: sem isso os filhos deixam de ser itens de
    # flex, a etiqueta e o numero-fantasma voltam a ser inline e imprimiam-se um
    # por cima do outro ("02PONTO Nº 2" no slide de conteudo, 17/9/2026).
    # Com a familia escura, o cartao NAO pode continuar branco: o texto passa a
    # branco com o resto da familia e desaparecia dentro da caixa (17/9/2026).
    # O cartao passa a ser um painel um tom mais claro do que o fundo -- le-se
    # como um plano levantado, e o texto branco assenta nele como no resto.
    "cartao":    dict(fundo="#4E4B46", escuro=True, cartao_cor="rgba(255,255,255,.12)",
                      deco="nenhuma",
                      envolve=(f'<div style="background:{GREY_FUNDO};padding:26px 26px;'
                               'box-shadow:0 12px 38px rgba(0,0,0,.28);display:flex;'
                               'flex-direction:column;align-items:flex-start">', '</div>'),
                      css_zona=".zone{justify-content:center}",
                      # A caixa branca come 30px de cada lado e 34px em cima e em
                      # baixo. Com o corpo de texto normal o conteudo transbordava
                      # (8px na capa, 14px no slide de conteudo) -- ate 17/9/2026
                      # isso passava despercebido porque a etiqueta e o numero se
                      # sobrepunham e ocupavam uma linha em vez de duas.
                      escala="compacta"),
    # A barra dourada empurra a zona, mas o rodape e o cabecalho vivem fora dela.
    # Sem os empurrar tambem, o logotipo ficava encostado a barra e desalinhado
    # do texto -- notou-se logo na primeira capa.
    "lateral":   dict(fundo=GREY_FUNDO, escuro=True, cartao_cor="rgba(255,255,255,.10)",
                      deco="lateral",
                      css_zona=".zone{left:92px}",
                      css_slide=".zone{left:92px}.foot{left:92px}.head{left:92px}"
                                ".bar{left:92px}"),
    # ── 17/9/2026 ───────────────────────────────────────────────────────────
    # Sairam a 'centrada' e a 'desfocada'. A 'centrada' por decisao do Ricardo.
    # A 'desfocada' porque nao cumpria o que prometia: o veu claro apagava a
    # fotografia por completo e, das 29 do catalogo, so as escuras deixavam ver
    # alguma coisa -- pagava o custo de uma imagem para nao se ver nenhuma.
    #
    # A 'filme' e a resposta ao que ela devia ter sido: a fotografia em TODOS os
    # slides, e mesmo. Ver a decoracao "filme" para o modo como se evita que o
    # carrossel pareca parado.
    "filme":     dict(fundo=GREY_FUNDO, escuro=True, cartao_cor="rgba(0,0,0,.34)",
                      deco="filme"),
    # Fotografia na metade de cima, texto num bloco de cor por baixo. Passou a
    # clara a 16/9/2026 e voltou a escura a 17/9, pela mesma razao que a 'cinza'.
    "meia":      dict(fundo=GREY_FUNDO, escuro=True, cartao_cor="rgba(255,255,255,.10)",
                      deco="meia", escala="compacta"),
}

# Familias que nao se desenham sem fotografia. Sai da propria decoracao para
# nao haver duas listas a dizer a mesma coisa e a discordarem com o tempo.
PRECISA_FOTO = {n for n, f in FAMILIAS.items()
                if f["deco"] in ("foto", "filme", "meia")}

# Nos PNG as fontes vao EMBUTIDAS no CSS, em base64 (no carrossel.html vao por
# endereco -- ver FONTES_CSS_WEB). Sem isto o HTML so desenha bem em
# maquinas com a Poppins instalada -- o sandbox do Cowork tem-na, um conversor
# externo (Cloudflare Browser Run, html2img, etc.) NAO tem, e os slides sairiam
# com uma fonte de recurso sem ninguem dar por isso. Os ficheiros em
# assets/fontes/ sao WOFF2 ja reduzidos aos caracteres do portugues: 5 KB cada
# em vez dos 158 KB do TTF original.
FONTES_CSS = "".join(
    f"@font-face{{font-family:'{fam}';font-style:normal;font-weight:400;"
    f"src:url(data:font/woff2;base64,"
    f"{base64.b64encode((FONTES / f'{f}.woff2').read_bytes()).decode()})"
    f" format('woff2')}}"
    for fam, f in (("Poppins", "regular"), ("Poppins Light", "light"),
                   ("Poppins Medium", "medium")))

# ── marca alojada, para o HTML exportado ────────────────────────────────────
# O carrossel.html vai para o Make atraves de um conector, e o conteudo do campo
# passa pelo modelo: ha um teto de ~25.000 tokens na leitura. Com a marca e as
# fontes embutidas em base64 o ficheiro dava 133.174 caracteres, ~118.000
# tokens, e a publicacao NUNCA chegava a sair (4/9/2026). Sem base64 nenhum sao
# 13.166 caracteres e passa com folga.
#
# Reduzir as imagens nao resolvia: mesmo a zero, as fontes deixavam o ficheiro
# acima do teto. E uma fotografia media da biblioteca da 175.000 tokens sozinha.
#
# Os PNG locais continuam a ser gerados com tudo embutido -- o container nao tem
# rede e o Playwright nao conseguiria ir buscar nada. Sao dois destinos
# diferentes a partir do mesmo motor, e so o exportado usa esta tabela.
MARCA_URL = "https://raw.githubusercontent.com/Planipax/marca/main/"

# As 29 fotografias sairam do pacote da skill a 14/9/2026. Eram 4,3 MB dos
# 4,4 MB do pacote, e o download da skill comecou a falhar ("download failed",
# seis tentativas seguidas) -- sem a skill, nao se gera nada. Recomprimi-las nao
# dava: ja estao otimizadas, e a qualidade 85 ficavam maiores.
# Passaram para o mesmo repositorio da marca. Sao buscadas em tempo de execucao
# so quando a familia as usa -- 'filme', 'foto' e 'meia' (PRECISA_FOTO). As
# outras seis familias nao tocam na rede.
# Na raiz do repositorio, ao lado dos logotipos. Nao ha pasta: o GitHub nao tem
# pastas vazias e criar uma obriga a escrever o caminho no ecra de upload, que e
# onde o Ricardo se perdeu. Na raiz, arrastam-se os ficheiros e acabou.
FOTOS_URL = MARCA_URL

def carrega_foto(nome):
    """Devolve a foto em base64, do disco se la estiver, senao do GitHub."""
    local = FOTOS / nome
    if local.exists():                      # pacote antigo, ou copia manual
        return b64(local, "image/jpeg")
    import urllib.request, base64 as _b64
    url = FOTOS_URL + nome
    try:
        with urllib.request.urlopen(url, timeout=30) as r:
            dados = r.read()
    except Exception as e:
        raise SystemExit(
            f"\nNao consegui obter a fotografia '{nome}'.\n"
            f"  Tentei: {url}\n"
            f"  Erro: {e}\n\n"
            "As fotografias deixaram de vir dentro da skill (o pacote ficou\n"
            "grande de mais e falhava a descarregar). Vem agora do GitHub, e\n"
            "isso exige que este ambiente alcance o raw.githubusercontent.com.\n\n"
            "Se nao alcancar, as familias 'filme', 'foto' e 'meia' nao podem ser\n"
            "usadas aqui. Escolhe outra familia -- ha seis que nao precisam de\n"
            "rede --\n"
            "e avisa o Ricardo de que isto aconteceu.\n")
    return "data:image/jpeg;base64," + _b64.b64encode(dados).decode()


def _mapa_marca():
    m = {ICONE: "icone.png", ICONE_B: "icone_branco.png",
         WORD: "wordmark.png", WORD_B: "wordmark_branco.png"}
    for cor, redes in REDES.items():
        for rede, uri in redes.items():
            m[uri] = f"{rede}_{cor}.png"
    return {uri: MARCA_URL + nome for uri, nome in m.items()}

# As fontes tambem vao para o GitHub, em vez do Google Fonts. Parece um rodeio
# -- a Poppins esta la -- mas a do Google nao e a mesma: estas WOFF2 estao
# reduzidas aos caracteres do portugues e sao exatamente as que desenharam os
# PNG. Metricas iguais garantem que o exportado sai igual ao aprovado; a versao
# do Google podia mudar a largura de uma linha e desfazer a verificacao de
# transbordo sem ninguem dar por isso.
FONTES_CSS_WEB = "".join(
    f"@font-face{{font-family:'{fam}';font-style:normal;font-weight:400;"
    f"src:url({MARCA_URL}{f}.woff2) format('woff2')}}"
    for fam, f in (("Poppins", "regular"), ("Poppins Light", "light"),
                   ("Poppins Medium", "medium")))

CSS = f"""
{FONTES_CSS}
*{{margin:0;padding:0;box-sizing:border-box}}
.slide{{width:{W}px;height:{H}px;position:relative;overflow:hidden;
  font-family:'Poppins';-webkit-font-smoothing:antialiased}}
.lt{{font-family:'Poppins Light';font-weight:400}}
.md{{font-family:'Poppins Medium';font-weight:400}}
.tag{{font-size:14px;letter-spacing:2.6px;text-transform:uppercase}}
.t-xl{{font-size:54px;line-height:1.09;letter-spacing:-1.3px}}
.t-l{{font-size:44px;line-height:1.13;letter-spacing:-1px}}
.t-m{{font-size:36px;line-height:1.18;letter-spacing:-.6px}}
.t-s{{font-size:31px;line-height:1.2;letter-spacing:-.4px}}
.body{{font-size:23px;line-height:1.5}}
.cap{{font-size:20px;line-height:1.55}}
.head{{position:absolute;top:44px;left:{M}px;right:{M}px;display:flex;
  align-items:center;justify-content:space-between;z-index:15}}
.zone{{position:absolute;left:{M}px;right:{M}px;top:{CT}px;bottom:{CB}px;
  display:flex;flex-direction:column;z-index:12}}
.foot{{position:absolute;bottom:{FB}px;left:{M}px;right:{M}px;display:flex;
  align-items:center;justify-content:space-between;z-index:15}}
.bar{{position:absolute;bottom:{BB}px;left:{M}px;right:{M}px;display:flex;
  align-items:center;gap:14px;z-index:20}}
.track{{flex:1;height:3px;border-radius:3px;overflow:hidden}}
"""

# ─────────────────────────────── componentes ────────────────────────────────
def barra(i, n, escuro):
    tr = "rgba(255,255,255,.22)" if escuro else "rgba(0,0,0,.10)"
    fl = "#fff" if escuro else GOLD
    lb = "rgba(255,255,255,.6)" if escuro else "rgba(0,0,0,.35)"
    return (f'<div class="bar"><div class="track" style="background:{tr}">'
            f'<div style="height:100%;width:{(i+1)/n*100}%;background:{fl};'
            f'border-radius:3px"></div></div>'
            f'<span class="lt" style="font-size:15px;color:{lb}">{i+1}/{n}</span></div>')

def cabecalho(escuro, direita=""):
    """So o X no topo. O wordmark aparece uma unica vez, no rodape."""
    return (f'<div class="head" style="justify-content:flex-end">'
            f'<img class="marca" src="{ICONE_B if escuro else ICONE}" style="width:38px">'
            f'{direita}</div>')

def rodape(escuro):
    # So o logotipo. O "planipax.pt" saiu de todos os slides a 16/9/2026: repetia-se
    # oito vezes, nao acrescentava nada e ja esta no slide de contactos. O slide de
    # contactos continua a leva-lo -- e la que faz falta.
    return (f'<div class="foot"><img class="marca" src="{WORD_B if escuro else WORD}" '
            f'style="height:25px"></div>')

def icone(escuro, w=40):
    return f'<img src="{ICONE_B if escuro else ICONE}" style="width:{w}px">'

def etiqueta(txt, cor=None, mb=20):
    cor = cor or GOLD_TXT
    return f'<span class="tag md" style="color:{cor};margin-bottom:{mb}px">{txt}</span>' if txt else ""

def filete(cor=None, larg=74, alt=4, m="28px 0 22px"):
    cor = cor or GOLD
    return f'<div style="width:{larg}px;height:{alt}px;background:{cor};margin:{m}"></div>'

def fundo_familia(fam, foto_uri=None, tipo=None, i=0, n=1):
    """Camadas decorativas de fundo, por família."""
    d, esc = fam["deco"], fam["escuro"]
    if d == "filete":
        return (f'<div style="position:absolute;top:0;left:0;width:8px;height:100%;'
                f'background:{GOLD}"></div>'
                f'<img class="deco" src="{ICONE}" style="position:absolute;right:-100px;'
                f'top:-70px;width:340px;opacity:.07">')
    if d == "marca":
        # Esta marca de agua era identica a que as familias com fotografia usam
        # nos slides de conteudo -- mesmo ficheiro, mesmo tamanho, mesma posicao
        # ao centro. Com a 'cinza' a passar a escura a 17/9/2026, ficou com o
        # mesmo fundo da 'foto' E a mesma marca: os slides do meio das duas
        # colaram-se (3,7 de diferenca). Aqui a marca e maior e sai pela
        # esquerda, o que lhe da uma silhueta propria em vez de um tom proprio.
        return (f'<img class="deco" src="{ICONE_B}" style="position:absolute;'
                f'left:-150px;top:52%;transform:translateY(-50%);width:620px;'
                f'opacity:.09">')
    if d == "cartao":
        return (f'<img class="deco" src="{ICONE_B}" style="position:absolute;right:-90px;'
                f'top:-60px;width:330px;opacity:.10">')
    if d == "dividido":
        if tipo == "final":      # os contactos usam o slide inteiro, sem faixa
            return ""
        return (f'<div style="position:absolute;top:0;left:0;right:0;height:124px;'
                f'background:{GREY}"></div>')
    # a fotografia so aparece na capa e no slide final: nos conteudos seria
    # sempre a mesma imagem e o carrossel deixaria de parecer avancar
    if d in ("foto", "meia") and tipo not in ("capa", "final"):
        marca = ICONE_B if fam.get("escuro") else ICONE
        return (f'<img class="deco" src="{marca}" style="position:absolute;left:50%;'
                f'top:50%;transform:translate(-50%,-50%);width:450px;opacity:.08">')
    if d == "meia" and foto_uri:
        if tipo == "final":
            # Sem fotografia nenhuma. A faixa no topo entrava por baixo do cartao
            # de contactos -- a zona comeca aos 78px nesse slide -- e o "Fale
            # connosco" a dourado ficava sobre a imagem, a 2,4:1. O slide de
            # contactos tem de se ler acima de tudo o resto.
            return ""
        return (f'<img class="foto-fundo" src="{foto_uri}" style="position:absolute;top:0;left:0;width:100%;'
                f'height:42%;object-fit:cover">'
                f'<div style="position:absolute;top:0;left:0;width:100%;height:42%;'
                f'background:linear-gradient(to bottom,rgba(0,0,0,.34) 0%,'
                f'rgba(0,0,0,0) 38%)"></div>')
    if d == "lateral":
        return (f'<div class="deco" style="position:absolute;left:0;top:0;bottom:0;'
                f'width:26px;background:{GOLD}"></div>')
    if d == "filme" and foto_uri:
        # A fotografia fica em TODOS os slides, que e o que a 'foto' nao faz.
        # O motivo de a 'foto' a largar nos slides de conteudo continua de pe:
        # a mesma imagem repetida cinco vezes faz o carrossel parecer parado.
        # Aqui resolve-se de outra maneira -- a imagem e sempre a mesma, o
        # enquadramento e o foco e que mudam:
        #   capa e slide final .... nitida, veu leve, a fotografia manda
        #   slides de conteudo .... desfocada e mais escura, passa a ser cenario
        # e ao mesmo tempo a imagem desliza na horizontal de slide para slide,
        # por isso nunca se ve duas vezes o mesmo pedaco. Continua a ser a mesma
        # fotografia, mas nao a mesma imagem.
        aberto = tipo in ("capa", "final")
        # 0% no primeiro slide, 100% no ultimo: percorre a largura da foto.
        pan = 50 if n <= 1 else round(i * 100 / (n - 1))
        if aberto:
            filtro, escala = "none", "1.02"
            # O topo estava a .46 e a etiqueta da capa, que assenta aos ~15%,
            # ficava abaixo dos 4,5 em tres fotografias claras do catalogo.
            veu = ("linear-gradient(to bottom,rgba(48,46,43,.58) 0%,"
                   "rgba(48,46,43,.74) 32%,rgba(48,46,43,.82) 62%,"
                   "rgba(48,46,43,.86) 100%)")
        else:
            # Desfocar aumenta a area por onde o texto passa, por isso o veu tem
            # de ser mais cheio do que na capa -- e a verificacao de contraste
            # mede isto slide a slide, porque a classe e .foto-fundo.
            filtro, escala = "blur(16px) saturate(.85)", "1.12"
            veu = ("linear-gradient(to bottom,rgba(48,46,43,.74) 0%,"
                   "rgba(48,46,43,.82) 40%,rgba(48,46,43,.86) 100%)")
        return (f'<img class="foto-fundo" src="{foto_uri}" style="position:absolute;'
                f'inset:0;width:100%;height:100%;object-fit:cover;'
                f'object-position:{pan}% 50%;filter:{filtro};'
                f'transform:scale({escala})">'
                f'<div style="position:absolute;inset:0;background:{veu}"></div>')
    if d == "foto" and foto_uri:
        # O veu era liso a 55% ate 17/9/2026, e com ele NENHUMA das 29
        # fotografias do catalogo passava a verificacao de contraste na capa: a
        # etiqueta dourada falhava nas 29, o destaque em 7 de cada 10 e o corpo
        # em 4 de cada 10. Um veu liso trata por igual o ceu claro do topo e a
        # sombra onde o texto assenta, por isso ou apagava a fotografia ou
        # deixava o texto a boiar. Agora escurece de cima para baixo: leve onde
        # so ha imagem, cheio na metade de baixo, que e onde o texto vive.
        return (f'<img class="foto-fundo" src="{foto_uri}" style="position:absolute;inset:0;width:100%;'
                f'height:100%;object-fit:cover">'
                f'<div style="position:absolute;inset:0;background:'
                f'linear-gradient(to bottom,rgba(48,46,43,.58) 0%,'
                f'rgba(48,46,43,.74) 32%,rgba(48,46,43,.82) 62%,'
                f'rgba(48,46,43,.86) 100%)"></div>')
    return ""

# ─────────────────────────────── tipos de slide ─────────────────────────────
_ABRE_TAG = __import__("re").compile(r"<[^>]*>")
# palavra com hifen ENTRE letras (nao apanha '10-20' nem ' - ')
HIFEN = __import__("re").compile(r"(?<![\w-])[A-Za-zÀ-ÿ]+(?:-[A-Za-zÀ-ÿ]+)+(?![\w-])")

def costurar(html):
    """Impede que palavras curtas e simbolos fiquem pendurados no fim da linha.

    Em portugues nao se deixa um artigo ou uma preposicao sozinha no fim de uma
    linha -- 'uma prestacao a / pagar' le-se aos solavancos. O mesmo vale para o
    simbolo do euro, que nunca se separa do valor ('1.950 / EUR'), e para o
    ponto medio das listas de contactos.

    Cose tambem as palavras com hifen (cliticos como 'conta-se'), que nunca
    partem no hifen -- ficam numa caixa com white-space:nowrap.

    Isto era escrito a mao em cada especificacao, o que significa que so era
    apanhado quando alguem reparava. Passa a ser automatico: o motor cose o
    espaco a seguir a qualquer palavra de uma ou duas letras, e o espaco antes
    de EUR, % e do ponto medio.

    Nao mexe no que esta dentro de tags, nem dentro de <style> ou <script> --
    so no texto que o leitor ve. Um espaco inquebravel dentro de CSS parte a
    regra: '282px !important' virava '282px\\xa0!important', o !important
    deixava de valer, e o texto subia para cima da fotografia.
    """
    import re
    NB = "\u00a0"

    def coser(t):
        # palavra de 1 ou 2 letras seguida de espaco: prende-a a seguinte
        t = re.sub(r"(?<![\w\u00a0])([A-Za-zÀ-ÿ]{1,2}) (?=[\wÀ-ÿ«“(])",
                   lambda m: m.group(1) + NB, t)
        # valor e simbolo andam juntos
        t = re.sub(r" (€|%|·|—)", NB + r"\1", t)
        # separador de milhares: '1 950 €' nao pode partir entre o 1 e o 950.
        # O simbolo ja estava protegido pela regra de cima, mas o valor podia
        # partir-se a si proprio um digito mais a esquerda.
        t = re.sub(r"(?<=\d) (?=\d{3}(?!\d))", NB, t)
        # viuva: a ultima palavra de um bloco nao fica sozinha na linha.
        # Era o caso de "Avenida do Carmo / 26" no slide de contactos.
        if len(t.strip()) > 24:
            t = re.sub(r" (\S+\s*)$", NB + r"\1", t)
        # clitico e palavra composta: 'conta-se', 'pagar-se-a', 'e-fatura'
        # nunca partem no hifen. O Chromium parte a seguir a um hifen, e
        # 'conta- / se' no fim da linha le-se como palavra cortada. Embrulha-se
        # numa caixa sem quebra -- e isto sai tambem no carrossel.html, porque
        # o exportado e montado pela mesma monta_slide (22/10/2026).
        t = HIFEN.sub(lambda m: f'<span style="white-space:nowrap">{m.group(0)}</span>', t)
        return t

    # os blocos de codigo saem inteiros da costura
    blocos = list(re.finditer(r"<(style|script)\b.*?</\1>", html, re.S | re.I))
    saida, pos = [], 0
    for bl in blocos + [None]:
        fim = bl.start() if bl else len(html)
        trecho, p = html[pos:fim], 0
        for m in _ABRE_TAG.finditer(trecho):
            saida.append(coser(trecho[p:m.start()]))
            saida.append(m.group(0))       # a tag passa intacta
            p = m.end()
        saida.append(coser(trecho[p:]))
        if bl:
            saida.append(bl.group(0))      # o bloco de codigo passa intacto
            pos = bl.end()
    return "".join(saida)

def corpo_capa(s, fam):
    esc = fam["escuro"]
    ct = "#fff" if esc else GREY
    cc = "rgba(255,255,255,.88)" if esc else "#7E7A74"
    # O ramo da familia 'risco' (titulo com barra dourada por tras do destaque)
    # desapareceu a 17/9/2026 com a propria familia.
    destaque = f'<span style="color:{GOLD}">{s["destaque"]}</span>' if s.get("destaque") else ""
    cls = escala(fam, "t-xl", "t-l")
    if fam.get("escala") == "compacta":
        fil = filete(m="18px 0 16px")
    else:
        fil = filete()
    # A etiqueta da capa e dourada em todo o lado menos onde assenta DIRETAMENTE
    # sobre fotografia. Ai o dourado nao se le: e um texto pequeno, em maiusculas
    # e espacado, e das 29 fotografias do catalogo NENHUMA lhe dava os 4.5
    # minimos -- nem com o veu mais escuro que ainda deixava ver a imagem. A
    # branco passam as 29. O dourado continua no filete e no destaque.
    #
    # A regra vale por DECORACAO e nao por nome de familia: quando a 'filme'
    # nasceu, a 17/9/2026, herdou o mesmo problema no primeiro render porque a
    # condicao dizia == "foto". A 'meia' fica de fora porque ai a etiqueta
    # assenta no bloco de cor por baixo da fotografia, nao na fotografia.
    return (f'<div class="zone" style="justify-content:center">'
            f'{etiqueta(s.get("etiqueta"))}'
            f'<h1 class="{cls} md" style="color:{ct}">{s["titulo"]}{destaque}</h1>'
            f'{fil}'
            f'<p class="body lt" style="color:{cc}">{s.get("corpo","")}</p></div>')

def corpo_conteudo(s, fam):
    esc = fam["escuro"]
    ct = "#fff" if esc else GREY
    cc = "rgba(255,255,255,.85)" if esc else "#7E7A74"
    num = (f'<span class="md" style="font-size:104px;line-height:.88;color:{GOLD};'
           f'opacity:{".35" if esc else ".26"};margin-bottom:14px">{s["numero"]}</span>'
           ) if s.get("numero") else ""
    nota = ""
    if s.get("nota"):
        nota = (f'<div style="border-left:5px solid {GOLD};padding:18px 0 18px 22px;'
                f'background:{fam["cartao_cor"]};margin-top:26px">'
                f'<p class="cap lt" style="color:{ct}">{s["nota"]}</p></div>')
    return (f'<div class="zone" style="justify-content:center">{num}'
            f'{etiqueta(s.get("etiqueta"), mb=16)}'
            f'<h2 class="{escala(fam,"t-m","t-s")} md" style="color:{ct};'
            f'margin-bottom:22px">{s["titulo"]}</h2>'
            f'<p class="body lt" style="color:{cc}">{s.get("corpo","")}</p>{nota}</div>')

def corpo_lista(s, fam):
    esc = fam["escuro"]
    ct = "#fff" if esc else GREY
    ci = "rgba(255,255,255,.85)" if esc else GREY
    linha = "rgba(255,255,255,.14)" if esc else "#E4DFD5"
    itens = ""
    for k, it in enumerate(s["itens"]):
        borda = "" if k == len(s["itens"]) - 1 else f"border-bottom:1px solid {linha}"
        itens += (f'<div style="display:flex;gap:16px;padding:16px 0;{borda}">'
                  f'<span style="color:{GOLD};font-size:22px">—</span>'
                  f'<p class="body lt" style="color:{ci}">{it}</p></div>')
    return (f'<div class="zone" style="justify-content:center">'
            f'{etiqueta(s.get("etiqueta"), mb=16)}'
            f'<h2 class="t-m md" style="color:{ct};margin-bottom:24px">{s["titulo"]}</h2>'
            f'{itens}</div>')

def corpo_numero(s, fam):
    ct = "#fff" if fam["escuro"] else GREY
    return (f'<div class="zone" style="justify-content:center">'
            f'{etiqueta(s.get("etiqueta"), mb=6)}'
            f'<span class="md" style="font-size:150px;line-height:.92;color:{GOLD};'
            f'letter-spacing:-5px">{s["valor"]}</span>'
            f'<h1 class="t-m md" style="color:{ct};margin-top:14px">{s["titulo"]}</h1>'
            f'{filete(m="24px 0 0")}</div>')

def corpo_final(s, fam):
    esc = fam["escuro"]
    txt = "rgba(255,255,255,.85)" if esc else "#7E7A74"
    forte = "#fff" if esc else GREY
    cartao = fam.get("cartao_cor", "rgba(0,0,0,.06)")
    cx = ""
    for k in ("beja", "moura"):
        nome, morada, tel = CONTACTOS[k]
        cx += (f'<div style="flex:1;background:{cartao};padding:12px 10px">'
               f'<p class="tag md" style="color:{GOLD};margin-bottom:8px">{nome}</p>'
               f'<p class="cap lt" style="color:{txt}">{morada}<br>'
               f'<span class="md" style="color:{forte}">{tel}</span></p></div>')
    return (f'<div class="zone" style="justify-content:center;align-items:center;'
            f'text-align:center">'
            f'<img class="marca" src="{WORD_B if esc else WORD}" '
            f'style="width:195px;margin-bottom:14px">'
            f'<h2 class="t-m md" style="color:{GOLD_TXT};margin-bottom:8px">Fale connosco</h2>'
            f'<p class="body lt" style="color:{txt};margin-bottom:14px">'
            f'{CONTACTOS["assinatura"]}</p>'
            f'<div style="display:flex;gap:16px;width:100%;margin-bottom:12px">{cx}</div>'
            # .sangra: a linha dos dois e-mails e mais larga do que a zona e
            # usa 23px da margem de cada lado. E o desenho aprovado do slide
            # final; a verificacao horizontal deixa-a usar a margem, mas
            # continua a acusar se chegar a borda do slide.
            f'<p class="cap lt sangra" style="color:{txt}">{CONTACTOS["email"]}<br>'
            f'<span class="md" style="color:{forte}">{CONTACTOS["site"]}</span> '
            f'· {CONTACTOS["social"]}</p>{redes(esc)}</div>')

def redes(escuro):
    ics = REDES["branco" if escuro else "cinza"]
    imgs = "".join(f'<img src="{u}" style="width:23px;height:23px;opacity:.85">'
                   for u in ics.values())
    return (f'<div style="display:flex;gap:18px;justify-content:center;'
            f'margin-top:14px">{imgs}</div>')


CORPOS = {"capa": corpo_capa, "conteudo": corpo_conteudo, "lista": corpo_lista,
          "numero": corpo_numero, "final": corpo_final}

def escala(fam, normal, compacta):
    return compacta if fam.get("escala") == "compacta" else normal


def monta_slide(s, fam, i, n, foto_uri=None):
    esc = fam["escuro"]
    if s["tipo"] == "final":            # os contactos assentam no fundo, nao no bloco
        extra_final = "<style>.zone{top:78px !important}</style>"
    corpo = CORPOS[s["tipo"]](s, fam)
    if fam.get("envolve") and s["tipo"] != "final":
        abre, fecha = fam["envolve"]
        corpo = corpo.replace('<div class="zone" style="justify-content:center">',
            f'<div class="zone" style="justify-content:center">{abre}', 1) + fecha
    tipo = s["tipo"]
    mc = fam["escuro"]   # cor do X, do rodape e da barra
    if fam["deco"] == "dividido" and s["tipo"] != "final":
        mc = False          # rodape e barra em cinza, sobre o creme
    dividido = fam["deco"] == "dividido"
    topo = "" if s["tipo"] == "final" else cabecalho(True if dividido else mc)
    base = "" if s["tipo"] == "final" else rodape(mc)
    extra = "<style>.zone{top:150px !important}</style>" if dividido else ""
    # Gancho generico acrescentado a 16/9/2026 para as familias que mudam a
    # arquitetura do slide e nao so a cor. Sem isto, cada variacao de estrutura
    # obrigava a um ramo novo aqui dentro -- e esta funcao ja tinha ramos a mais.
    if fam.get("css_zona") and s["tipo"] != "final":
        extra += f'<style>{fam["css_zona"]}</style>'
    # css_slide vale em todos os slides, o final incluido: e para o que tem de
    # alinhar de ponta a ponta, como as margens da familia 'lateral'.
    if fam.get("css_slide"):
        extra += f'<style>{fam["css_slide"]}</style>'
    if dividido and s["tipo"] == "final":
        extra = extra_final
    if s["tipo"] == "final" and not dividido:
        extra = extra_final
    if fam["deco"] == "meia" and s["tipo"] == "capa":
        extra = "<style>.zone{top:282px !important}</style>"
    return costurar(
        f'{extra}<div class="slide" style="background:{fam["fundo"]}">'
        f'{fundo_familia(fam, foto_uri, tipo, i, n)}{topo}{corpo}{base}'
        f'{"" if tipo == "capa" else barra(i, n, mc)}</div>')

# ─────────────────────────────── verificações ───────────────────────────────
# Teto pratico do campo html no conector do Make (ver historia-tecnica.md).
LIMITE_HTML = 25_000
# Ficheiro deixado na pasta de saida quando o render acaba com problemas. O
# preparar_envio.py recusa enviar uma pasta que o tenha.
MARCADOR_PROBLEMAS = "NAO_ENVIAR.txt"
# Ficheiro deixado na pasta quando se renderiza com --exemplo (regras
# editoriais relaxadas). Tambem bloqueia o envio.
MARCADOR_EXEMPLO = "MODO_EXEMPLO.txt"
BANNER_NAO_ENVIAR = (
    "\n" + "#" * 64 + "\n"
    "###  NAO ENVIAR: ha problemas -- ver a lista no fim da saida  ###\n"
    + "#" * 64 + "\n")

FAMILIAS_FONTE = ("Poppins", "Poppins Light", "Poppins Medium")
# Forca o carregamento de cada familia e confirma com document.fonts.check.
# Devolve as que falharam. Uma fonte declarada mas nao carregada desenha com a
# fonte de recurso -- e com outra largura de linha -- sem erro nenhum.
FONTES_JS = """async () => { const falta=[];
  await document.fonts.ready;
  for (const f of %s) {
    let faces=[];
    try { faces = await document.fonts.load("16px '"+f+"'", "Aa"); } catch(e) {}
    if (!faces.length || !document.fonts.check("16px '"+f+"'", "Aa")) falta.push(f);
  }
  return falta; }""" % json.dumps(list(FAMILIAS_FONTE))

VERIFICA_JS = """() => { const out=[];
  document.querySelectorAll('.zone').forEach(z=>{
    if(z.scrollHeight>z.clientHeight+1)
      out.push('conteudo transborda '+(z.scrollHeight-z.clientHeight)+'px'); });
  // Transbordo HORIZONTAL (22/10/2026). O vertical nao apanhava um valor
  // longo no slide 'numero' -- '12.995 EUR' a 150px sai pela direita, e como o
  // .slide tem overflow:hidden o algarismo era simplesmente cortado, sem aviso.
  // Mede-se de tres maneiras, porque cada uma falha num caso:
  //   scrollWidth > clientWidth .... caixa cujo conteudo e mais largo do que ela
  //   caixa fora do slide .......... elemento posicionado ou esticado para fora
  //   linhas de texto (Range) ...... o texto que sai de uma caixa que nao cresce
  const cortar=t=>t.trim().replace(/\\s+/g,' ').slice(0,24);
  // o que e .sangra pode ocupar a margem: sai da medida do scrollWidth (fica
  // escondido so durante a medida) mas nao da verificacao da borda do slide.
  const sangra=[...document.querySelectorAll('.sangra')];
  sangra.forEach(e=>{e.dataset.v=e.style.visibility; e.style.display='none';});
  document.querySelectorAll('.zone, .zone *, .head, .head *, .foot, .foot *, .bar, .bar *').forEach(e=>{
    if(e.clientWidth>0 && e.scrollWidth>e.clientWidth+1)
      out.push('conteudo transborda na horizontal '+(e.scrollWidth-e.clientWidth)+
               'px ("'+cortar(e.textContent)+'")'); });
  sangra.forEach(e=>{e.style.display='';});
  const ver=document.createTreeWalker(document.querySelector('.slide'),NodeFilter.SHOW_TEXT);
  let no; while((no=ver.nextNode())){
    if(!no.textContent.trim()) continue;
    const pai=no.parentElement; if(pai.closest('.deco,.foto-fundo,style')) continue;
    const rg=document.createRange(); rg.selectNodeContents(no);
    for(const r of rg.getClientRects()){
      if(r.width>0 && (r.right>%d+1 || r.left<-1)){
        out.push('texto sai do slide na horizontal ('+Math.round(Math.max(r.right-%d,-r.left))+
                 'px, "'+cortar(no.textContent)+'")'); break; } } }
  // .foto-fundo esta isenta desta medida desde 17/9/2026: e uma camada de
  // fundo, propositadamente MAIOR do que o slide (a 'filme' amplia-a para o
  // desfoque nao mostrar bordas moles e para a imagem poder deslizar), e o
  // .slide tem overflow:hidden, por isso o que sai e cortado e nunca se ve.
  // Continua a ser medida na verificacao de CONTRASTE, que e para o que serve.
  // (.foto-veu saiu do selector com a familia 'desfocada': ja nada a usa.)
  document.querySelectorAll('.slide *:not(.deco):not(.foto-fundo)').forEach(e=>{
    const r=e.getBoundingClientRect();
    if(r.height>0 && (r.bottom>%d+1||r.top<-1)) out.push('elemento fora do slide');
    if(r.width>0 && (r.right>%d+1||r.left<-1))
      out.push('elemento fora do slide na horizontal'); });
  return [...new Set(out)]; }""" % (W, W, H, W)

# Cada elemento de texto, com a sua caixa e a cor que o CSS lhe deu. Serve para
# medir o contraste contra o que estiver por tras -- fotografia incluida.
# So o texto que assenta SOBRE FOTOGRAFIA e verificado. Nas familias de fundo
# liso as cores sao as da marca, fixas e ja aprovadas -- verifica-las so gerava
# ruido (o dourado #C79A59 sobre creme da 2.4:1 e e uma escolha deliberada).
# Sobre uma fotografia o fundo e imprevisivel, muda a cada foto escolhida, e
# ninguem consegue prever se um titulo vai ou nao desaparecer. E ai que a
# maquina tem de olhar.
TEXTO_JS = """() => {
  const foto=document.querySelector(".slide img.foto-fundo");
  if(!foto) return [];
  const f=foto.getBoundingClientRect();
  if(f.width<40||f.height<40) return [];
  const out=[];
  document.querySelectorAll('.slide *').forEach(e=>{
    if(![...e.childNodes].some(k=>k.nodeType===3 && k.textContent.trim())) return;
    const r=e.getBoundingClientRect();
    if(r.width<4||r.height<4) return;
    // so conta se estiver mesmo por cima da fotografia
    const sobre = r.left < f.right && r.right > f.left &&
                  r.top  < f.bottom && r.bottom > f.top;
    if(!sobre) return;
    const cs=getComputedStyle(e);
    out.push({x:r.x, y:r.y, w:r.width, h:r.height,
              cor:cs.color, px:parseFloat(cs.fontSize),
              peso:parseInt(cs.fontWeight)||400,
              txt:e.textContent.trim().slice(0,28)});
  });
  return out; }"""

def _lum(c):
    import numpy as np
    c = np.asarray(c, float) / 255.0
    c = np.where(c <= .03928, c / 12.92, ((c + .055) / 1.055) ** 2.4)
    return .2126*c[...,0] + .7152*c[...,1] + .0722*c[...,2]

def contraste_texto(png, itens):
    """Confirma que cada texto se le sobre o que tem por tras.

    Existe porque a verificacao antiga so olhava para os logotipos. Um titulo
    dourado sobre uma fotografia clara passava sem aviso -- foi o caso da tag
    'NOVO ESCRITORIO . BEJA' sobre a parede de madeira, a 1.37:1.

    Metodo: dentro da caixa do texto, os pixeis proximos da cor declarada sao o
    texto; o resto e o fundo. Compara-se a cor declarada com o fundo mais
    desfavoravel (percentil 75 da luminancia se o texto for claro, percentil 25
    se for escuro), para apanhar o pior sitio e nao a media.
    """
    from PIL import Image
    import numpy as np
    im = np.asarray(Image.open(png).convert("RGB"), float)
    avisos = []
    for it in itens:
        rec = im[int(it["y"]*2):int((it["y"]+it["h"])*2),
                 int(it["x"]*2):int((it["x"]+it["w"])*2)]
        if rec.size == 0:
            continue
        m = [int(v) for v in it["cor"].replace("rgba(", "").replace("rgb(", "")
             .rstrip(")").split(",")[:3]]
        cor = np.array(m, float)
        l_txt = float(_lum(cor))
        dist = np.linalg.norm(rec - cor, axis=-1)
        fundo = rec[dist >= 46]          # tudo o que nao e o traco do texto
        if fundo.size < 40:
            continue
        L = _lum(fundo)
        # o pior fundo: se o texto e claro, o fundo claro e que o mata
        pior = float(np.percentile(L, 75 if l_txt > .3 else 25))
        r = (max(l_txt, pior) + .05) / (min(l_txt, pior) + .05)
        # WCAG: texto grande (>=24px, ou >=19px a negrito) chega-lhe 3:1
        grande = it["px"] >= 24 or (it["px"] >= 19 and it["peso"] >= 700)
        minimo = 3.0 if grande else 4.5
        if r < minimo:
            avisos.append(f'texto camuflado: "{it["txt"]}" '
                          f'(contraste {r:.1f}:1, minimo {minimo})')
    return avisos

def contraste_marca(png, caixas):
    """Confirma nos pixels exportados que o logotipo nao fica camuflado."""
    from PIL import Image
    import numpy as np
    lum = _lum
    avisos = []
    im = np.asarray(Image.open(png).convert("RGB"), float)
    for (x, y, w_, h_) in caixas:
        rec = im[int(y*2):int((y+h_)*2), int(x*2):int((x+w_)*2)]
        if rec.size == 0:
            continue
        L = lum(rec)
        r = (np.percentile(L, 96) + .05) / (np.percentile(L, 4) + .05)
        if r < 3.0:
            avisos.append(f"logotipo camuflado (contraste {r:.1f}:1, minimo 3.0)")
    return avisos

# ─────────────────────────────── validação ──────────────────────────────────
# Campos que cada tipo de slide le, deduzidos das funcoes corpo_*. Um campo
# fora desta lista nunca chega ao slide: e quase sempre uma gralha ('titlo',
# 'nota' num slide de lista) que faz desaparecer texto sem aviso.
CAMPOS = {
    "capa":     {"tipo", "etiqueta", "titulo", "destaque", "corpo"},
    "conteudo": {"tipo", "numero", "etiqueta", "titulo", "corpo", "nota"},
    "lista":    {"tipo", "etiqueta", "titulo", "itens"},
    "numero":   {"tipo", "etiqueta", "valor", "titulo"},
    "final":    {"tipo"},
}
OBRIGATORIOS = {"capa": {"titulo"}, "conteudo": {"titulo"},
                "lista": {"titulo", "itens"}, "numero": {"valor", "titulo"},
                "final": set()}
CAMPOS_TOPO = {"familia", "slides", "foto"}
MIN_SLIDES, MAX_SLIDES, MAX_PALAVRAS_TITULO = 5, 8, 6


def _texto(html):
    import re
    return re.sub(r"\s+", " ", re.sub(r"<[^>]*>", " ", html or "")).strip()


def validar(spec, exemplo=False):
    """Devolve (erros, avisos). Com erros, o render nao avanca.

    exemplo=True e so para os ficheiros de exemplos/, que sao amostras de
    familia com 3 ou 4 slides e numeracao solta: o numero de slides e a
    numeracao passam a aviso. Nunca para uma publicacao real.
    """
    import re
    erros, avisos = [], []
    editorial = avisos if exemplo else erros
    if not isinstance(spec, dict):
        return ["a especificacao tem de ser um objeto JSON"], []
    fam = spec.get("familia")
    if fam not in FAMILIAS:
        erros.append(f'familia "{fam}" nao existe. Aceites: {", ".join(FAMILIAS)}')
    for k in spec:
        if k not in CAMPOS_TOPO:
            erros.append(f'campo de topo desconhecido "{k}". '
                         f'Aceites: {", ".join(sorted(CAMPOS_TOPO))}')
    if fam in PRECISA_FOTO and not spec.get("foto"):
        erros.append(f'a familia "{fam}" e construida a volta de uma fotografia '
                     'e a especificacao nao traz "foto". Acrescenta '
                     '"foto": "<ficheiro do catalogo>" ou escolhe outra familia.')
    if spec.get("foto"):
        try:
            cat = {f["ficheiro"] for f in json.loads(
                (FOTOS / "catalogo.json").read_text(encoding="utf-8"))}
            if spec["foto"] not in cat:
                avisos.append(f'a fotografia "{spec["foto"]}" nao esta em '
                              'assets/fotos/catalogo.json')
        except Exception:
            pass
    slides = spec.get("slides")
    if not isinstance(slides, list) or not slides:
        erros.append('falta a lista "slides"')
        return erros, avisos
    n = len(slides)
    if not MIN_SLIDES <= n <= MAX_SLIDES:
        editorial.append(f"o carrossel tem {n} slides; tem de ter entre "
                         f"{MIN_SLIDES} e {MAX_SLIDES}")
    tipos = [s.get("tipo") if isinstance(s, dict) else None for s in slides]
    if tipos[0] != "capa":
        erros.append(f'o primeiro slide tem de ser "capa" (e "{tipos[0]}")')
    if tipos[-1] != "final":
        erros.append(f'o ultimo slide tem de ser "final" (e "{tipos[-1]}")')
    for k, t in enumerate(tipos[1:-1], start=2):
        if t in ("capa", "final"):
            erros.append(f'slide {k}: "{t}" so pode ser o '
                         f'{"primeiro" if t == "capa" else "ultimo"} slide')
    numeros = []
    for k, sl in enumerate(slides, start=1):
        if not isinstance(sl, dict):
            erros.append(f"slide {k}: tem de ser um objeto"); continue
        t = sl.get("tipo")
        if t not in CAMPOS:
            erros.append(f'slide {k}: tipo "{t}" nao existe. '
                         f'Aceites: {", ".join(CAMPOS)}'); continue
        for c in sl:
            if c not in CAMPOS[t]:
                erros.append(f'slide {k} ({t}): campo desconhecido "{c}". '
                             f'Aceites: {", ".join(sorted(CAMPOS[t]))}')
        for c in OBRIGATORIOS[t]:
            if not sl.get(c):
                erros.append(f'slide {k} ({t}): falta o campo "{c}"')
        if t == "lista" and "itens" in sl and not isinstance(sl["itens"], list):
            erros.append(f'slide {k} (lista): "itens" tem de ser uma lista')
        if "<br" in str(sl.get("destaque", "")).lower():
            erros.append(f'slide {k}: o "destaque" nao pode levar <br> -- e '
                         'uma expressao curta, numa so linha')
        if sl.get("destaque") and sl.get("titulo") and not re.search(
                r"(\s|<br\s*/?>)$", str(sl["titulo"]), re.I):
            avisos.append(f'slide {k}: o titulo nao acaba em espaco nem <br>, e o '
                          'destaque cola-se a ultima palavra (ex.: "mesmocontratar?")')
        if sl.get("titulo"):
            tit = _texto(f'{sl["titulo"]} {sl.get("destaque", "")}')
            np_ = len(tit.split())
            if np_ > MAX_PALAVRAS_TITULO:
                avisos.append(f'slide {k}: o titulo tem {np_} palavras (limite '
                              f'{MAX_PALAVRAS_TITULO}): "{tit}"')
        if t == "numero" and sl.get("valor"):
            v = _texto(str(sl["valor"]))
            if re.fullmatch(r"[\d.,\s]{1,4}", v):
                avisos.append(f'slide {k}: o valor "{v}" e so um numero curto, '
                              'sem unidade nem mes. Uma data escreve-se completa '
                              '(31/08) e um valor leva o simbolo (2.500 €, 23%).')
        if t == "conteudo" and sl.get("numero") not in (None, ""):
            numeros.append((k, str(sl["numero"])))
    for pos, (k, num) in enumerate(numeros, start=1):
        esperado = f"{pos:02d}"
        if num != esperado:
            editorial.append(f'slide {k}: numero "{num}", esperado "{esperado}" '
                             '-- a numeracao comeca em 01 e segue sem saltos')
            break
    return erros, avisos


# ─────────────────────────────── execução ───────────────────────────────────
async def gerar(spec, saida, avisos=()):
    from playwright.async_api import async_playwright
    global GOLD, GOLD_TXT
    fam = FAMILIAS[spec["familia"]]
    # um carrossel tem uma so familia, por isso o dourado resolve-se aqui:
    # sobre fundo escuro usa-se o tom claro, senao o dourado nao se le.
    GOLD = GOLD_ESC if fam["escuro"] else _GOLD_BASE
    # e quando o texto assenta DIRETAMENTE na fotografia, o dourado pequeno
    # deixa de servir seja qual for o tom: passa a branco. Ver GOLD_TXT.
    GOLD_TXT = "#fff" if fam["deco"] in ("foto", "filme") else GOLD
    foto_uri = None
    if spec.get("foto"):
        foto_uri = carrega_foto(spec["foto"])
    elif spec["familia"] in PRECISA_FOTO:
        raise SystemExit(
            f'A familia "{spec["familia"]}" e construida a volta de uma '
            f'fotografia e a especificacao nao traz nenhuma. Acrescenta '
            f'"foto": "<ficheiro do catalogo>" ou escolhe outra familia.')
    slides, n = spec["slides"], len(spec["slides"])
    # .resolve() e obrigatorio: o Playwright abre cada slide com um endereco
    # file://, e um caminho relativo dava "file://saida/_slide1.html", que nao e
    # um endereco valido. Rebentava so quando a pasta de saida vinha relativa.
    saida = Path(saida).resolve(); saida.mkdir(parents=True, exist_ok=True)
    # Apagar o que ficou de uma ronda anterior. Um carrossel de 8 slides
    # corrigido para 6 deixava slide07.png e slide08.png na pasta, e quem
    # pegasse na pasta inteira levava dois slides que ja nao existem.
    for velho in list(saida.glob("slide*.png")) + [saida / "carrossel.html",
                                                   saida / MARCADOR_PROBLEMAS]:
        if velho.exists():
            velho.unlink()
    problemas, feitos, notas = [], [], []
    # Copia exata da especificacao usada, ao lado dos PNG. E dela que o
    # preparar_envio.py tira o numero de slides, e e ela que se guarda no .md
    # da publicacao para se poder regenerar exatamente o que foi aprovado.
    (saida / "especificacao.json").write_text(
        json.dumps(spec, ensure_ascii=False, indent=1), encoding="utf-8")

    async with async_playwright() as p:
        # Sem "hinting": o mesmo que a tarefa do GitHub usa. Com outro valor as
        # letras ficam com outra largura e as linhas partem noutro sitio.
        br = await p.chromium.launch(args=["--font-render-hinting=none"])
        pg = await br.new_page(viewport={"width": W, "height": H}, device_scale_factor=2)
        for i, s in enumerate(slides):
            html = monta_slide(s, fam, i, n, foto_uri)
            tmp = saida / f"_slide{i+1}.html"
            tmp.write_text(f"<html><head><meta charset='utf-8'><style>{CSS}</style>"
                           f"</head><body>{html}</body></html>", encoding="utf-8")
            await pg.goto(f"file://{tmp}")
            # Medir e fotografar so depois de as fontes estarem prontas. Com uma
            # fonte de recurso as linhas tem outra largura, e o transbordo
            # medido nao e o do slide que sai.
            await pg.evaluate("() => document.fonts.ready.then(() => true)")
            await pg.wait_for_timeout(300)
            em_falta = await pg.evaluate(FONTES_JS)
            for f in em_falta:
                problemas.append((i + 1, f"fonte nao carregou: {f}"))
            for a in await pg.evaluate(VERIFICA_JS):
                problemas.append((i + 1, a))
            caixas = await pg.evaluate(
                "() => [...document.querySelectorAll('.marca')].map(e=>{"
                "const r=e.getBoundingClientRect(); return [r.x,r.y,r.width,r.height];})")
            textos = await pg.evaluate(TEXTO_JS)
            png = saida / f"slide{i+1:02d}.png"
            await pg.locator(".slide").screenshot(path=str(png))
            for a in contraste_marca(png, caixas):
                problemas.append((i + 1, a))
            for a in contraste_texto(png, textos):
                problemas.append((i + 1, a))
            tmp.unlink()
            feitos.append(png.name)
        await br.close()

    # HTML para exportacao: um so ficheiro com os slides todos, para o Make
    # converter em imagem. Logotipos, fontes e fotografia vao por endereco
    # publico (GitHub), sem base64 e sem <script>.
    _, notas_html, probl_html = exportar_html(spec, fam, saida, foto_uri,
                                              spec.get("foto"))
    notas += notas_html
    problemas += [("html", a) for a in probl_html]

    # O aviso de problemas vai no TOPO da saida, e fica tambem escrito na
    # pasta (MARCADOR_PROBLEMAS) para o preparar_envio.py recusar o envio.
    if problemas:
        print(BANNER_NAO_ENVIAR)
        (saida / MARCADOR_PROBLEMAS).write_text(
            "NAO ENVIAR: o render deixou problemas por corrigir.\n" +
            "".join(f"slide {i}: {a}\n" for i, a in problemas), encoding="utf-8")
    for a in avisos:
        print(f"AVISO (especificacao): {a}")
    for nt in notas:
        print(nt)
    print(f"\n{len(feitos)} slides em {saida}")
    if problemas:
        print("\nPROBLEMAS — corrigir antes de aprovar:")
        for i, a in problemas:
            print(f"  {'carrossel.html' if i == 'html' else f'slide {i}'}: {a}")
    else:
        print("verificacoes: sem problemas (transbordo vertical e horizontal, "
              "fontes, contraste da marca e do texto, carrossel.html)")
    return not problemas

def exportar_html(spec, fam, saida, foto_uri, foto_nome=None):
    """Grava carrossel.html: os slides todos num ficheiro, com a marca por endereco.

    O Cowork nao consegue entregar PNGs a um conector -- sao megabytes em base64
    e nao cabem no contexto. Este HTML e texto, pesa dezenas de KB, e passa.
    """
    from pathlib import Path as _P
    slides, n = spec["slides"], len(spec["slides"])

    import re

    def isolar_estilos(html, nr):
        """Prende os <style> de um slide ao proprio slide.

        Alguns slides injetam '.zone{top:Xpx !important}' para acertar a altura
        do texto. Isolado num PNG isso funciona -- cada slide e um documento. No
        carrossel.html os oito partilham o mesmo documento, e o !important do
        ultimo slide passava a mandar em todos: o texto subia e ia parar em cima
        da fotografia. O HTML exportado ficava diferente dos PNG aprovados.
        """
        def scoped(m):
            regras = []
            for regra in m.group(1).split("}"):
                if "{" not in regra:
                    continue
                sel, corpo = regra.split("{", 1)
                sel = ",".join(f'section[data-slide="{nr}"] {s.strip()}'
                               for s in sel.split(",") if s.strip())
                regras.append(f"{sel}{{{corpo}}}")
            return "<style>" + "".join(regras) + "</style>"
        return re.sub(r"<style>(.*?)</style>", scoped, html, flags=re.S)

    mapa_marca = _mapa_marca()
    # A fotografia sai do ficheiro pelo mesmo caminho da marca. Sem isto, uma
    # familia com foto dava um HTML de 240.000 caracteres -- dez vezes o teto do
    # conector -- e nao chegava ao Make. Descoberto a 16/9/2026, no primeiro
    # carrossel com fotografia que chegou a gerar.
    if foto_uri and foto_nome:
        mapa_marca = {**mapa_marca, foto_uri: FOTOS_URL + foto_nome}
    corpos = []
    for i, sl in enumerate(slides):
        html = monta_slide(sl, fam, i, n, foto_uri)
        html = isolar_estilos(html, i + 1)
        # Tudo o que esta embutido (logotipos, icones, fotografia) passa a
        # endereco publico. Ate 7/9/2026 havia uma desduplicacao ligada por
        # <script>; esse script fazia a Cloudflare, que esta a frente do
        # make.com, recusar o pedido com 403 antes de chegar ao Make. Um
        # <script> num corpo de pedido tem o aspeto exato de uma tentativa de
        # injecao de codigo. Nunca mais se escreve JavaScript neste ficheiro.
        for uri, url in mapa_marca.items():
            html = html.replace(uri, url)
        corpos.append(f'<section class="pagina" data-slide="{i+1}">{html}</section>')

    espera = ("(2) Nao ha JavaScript neste ficheiro: as imagens vem todas por "
              "endereco. Basta esperar que a rede assente (networkidle). ")
    aviso = ("<!-- ATENCAO ao converter em imagem: (1) cada .slide mede 540x675 px; "
             "para 1080x1350, que e o formato das redes, pede escala 2 "
             "(deviceScaleFactor=2) ou largura=1080, senao as imagens saem com "
             f"metade da resolucao. {espera}(3) O conversor TEM de ter acesso a "
             "internet: os logotipos, as fotografias E as fontes vem de "
             "raw.githubusercontent.com/Planipax/marca. Sem rede, os slides saem "
             "sem marca e com uma fonte de recurso, e nao ha erro nenhum a "
             "avisar. -->")
    doc = (f"<html><head><meta charset='utf-8'>{aviso}<style>{CSS}"
           ".pagina{page-break-after:always}</style></head><body>"
           f"{''.join(corpos)}</body></html>")

    # trocar a marca embutida por enderecos publicos, e as fontes embutidas
    # pelas mesmas WOFF2 alojadas no GitHub (nao o Google Fonts -- ver
    # FONTES_CSS_WEB). Ver o comentario de MARCA_URL: sem isto o ficheiro nao
    # passa pelo conector e a publicacao nao sai.
    for uri, url in _mapa_marca().items():
        doc = doc.replace(uri, url)
    doc = doc.replace(FONTES_CSS, FONTES_CSS_WEB)

    fich = _P(saida) / "carrossel.html"
    fich.write_text(doc, encoding="utf-8")
    tam = len(doc)
    notas = [f"html para exportacao: {fich.name} ({tam} caracteres)"
             " -- converter com escala 2 para dar 1080x1350"]
    problemas = []
    # O que passa pelo modelo a caminho do Make tem um teto pratico de cerca de
    # 25.000 caracteres (ver referencias/historia-tecnica.md). Ate 22/10/2026 o
    # aviso so disparava acima de 60 KB -- mais do dobro do teto.
    if tam > LIMITE_HTML:
        problemas.append(f"{tam} caracteres, acima do teto de {LIMITE_HTML} do "
                         "conector do Make. Confirma que a marca e a fotografia "
                         "foram mesmo substituidas por enderecos.")
    # Ate 17/9/2026 este aviso disparava sempre que houvesse fotografia, mesmo
    # depois de as 29 do catalogo terem ido para o GitHub. Um aviso que esta
    # sempre errado ensina quem o le a ignorar os avisos todos. Agora so fala
    # quando ficou MESMO base64 no ficheiro.
    if "base64," in doc:
        problemas.append("ficou base64 no ficheiro (provavelmente a fotografia, "
                         "que nao esta no repositorio Planipax/marca). Nao passa "
                         "pelo conector do Make. Carrega a fotografia no "
                         "repositorio ou escolhe outra.")
    if "<script" in doc.lower():
        problemas.append("o ficheiro leva <script>: a Cloudflare a frente do "
                         "make.com recusa o pedido com 403.")
    return fich, notas, problemas


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    exemplo = "--exemplo" in sys.argv[1:]
    if not args:
        print(__doc__); sys.exit(1)
    try:
        spec = json.loads(Path(args[0]).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        print(f"ERRO: nao consegui ler a especificacao {args[0]}: {e}")
        sys.exit(3)
    erros, avisos = validar(spec, exemplo)
    if erros:
        print("ERRO: a especificacao nao e valida -- nada foi gerado.")
        for e in erros:
            print(f"  - {e}")
        for a in avisos:
            print(f"  (aviso) {a}")
        sys.exit(3)
    destino = args[1] if len(args) > 1 else "saida"
    ok = asyncio.run(gerar(spec, destino, avisos))
    marca_ex = Path(destino).resolve() / MARCADOR_EXEMPLO
    if exemplo:
        marca_ex.write_text("Gerado com --exemplo: regras editoriais relaxadas. "
                            "Nao enviar.\n", encoding="utf-8")
    elif marca_ex.exists():
        marca_ex.unlink()
    sys.exit(0 if ok else 2)
