#!/usr/bin/env python3
"""
Prepara o payload da chamada ao Make a partir do que o render.py deixou.

Uso:  python3 preparar_envio.py <pasta_de_saida> <legenda.txt> [--titulo "..."]

Le, nunca copia a mao:
  html     <- <pasta>/carrossel.html, inteiro
  slides   <- numero de slides de <pasta>/especificacao.json
  legenda  <- so o corpo do legenda.txt, o que vem DEPOIS da linha de traços
  titulo   <- --titulo, ou a primeira linha do cabecalho do legenda.txt

Grava <pasta>/payload.json e imprime o comprimento do html, o sha256 e o
numero de slides -- para conferir depois de colar o conteudo na chamada.

--teste-exemplo aceita uma pasta gerada com --exemplo, so para testar o script.

Recusa (codigo 2) se:
  - o render deixou NAO_ENVIAR.txt (houve problemas) ou MODO_EXEMPLO.txt;
  - o html tiver <script> ou base64;
  - o numero de <section data-slide> do html nao bater com a especificacao;
  - o legenda.txt nao tiver a linha de traços a separar o cabecalho.
"""
import hashlib, json, re, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from render import MARCADOR_PROBLEMAS, MARCADOR_EXEMPLO, LIMITE_HTML  # noqa: E402


def recusa(msg):
    print(f"RECUSADO: {msg}\nNada foi gravado. Nao chames o Make.", file=sys.stderr)
    sys.exit(2)


def ler_legenda(fich):
    txt = Path(fich).read_text(encoding="utf-8").replace("\r\n", "\n")
    linhas = txt.split("\n")
    sep = next((k for k, l in enumerate(linhas) if re.fullmatch(r"-{3,}\s*", l)), None)
    if sep is None:
        recusa(f"{fich} nao tem a linha de traços (---) que separa o cabecalho "
               "da legenda. Sem ela, o cabecalho iria publicado.")
    cabecalho = [l for l in linhas[:sep] if l.strip()]
    corpo = "\n".join(linhas[sep + 1:]).strip()
    if not corpo:
        recusa(f"{fich} nao tem legenda depois da linha de traços.")
    primeira = corpo.split("\n", 1)[0]
    if re.search(r"fam[ií]lia\s+\w+|\d{4}-\d{2}-\d{2}", primeira):
        recusa("a primeira linha da legenda parece o cabecalho do ficheiro "
               f"(data ou familia): «{primeira}»")
    return (cabecalho[0].strip() if cabecalho else ""), corpo


def nome_pasta(titulo, sha):
    import datetime, unicodedata
    base = unicodedata.normalize("NFKD", titulo).encode("ascii", "ignore").decode()
    base = re.sub(r"[^a-z0-9]+", "-", base.lower()).strip("-")[:48].strip("-")
    return f"{datetime.date.today():%Y-%m-%d}-{base}-{sha[:8]}"


def preparar_reel(pasta, fich_legenda, titulo):
    """Reel: o que segue para o Make e o GitHub e o roteiro.json, inteiro.

    O GitHub gera o video a partir dele com o mesmo motor (estado.json, depois
    scripts/conferir_github.py compara com o reel.mp4 aprovado). Nunca se envia
    o video: e binario e pesado de mais para o conector.
    """
    if (pasta / "NAO_ENVIAR.txt").exists():
        recusa(f"o reel.py deixou problemas por corrigir -- ver {pasta / 'NAO_ENVIAR.txt'}.")
    for nome in ("roteiro.json", "reel.mp4", "folha.png"):
        if not (pasta / nome).exists():
            recusa(f"falta {pasta / nome}. Corre o reel.py para esta pasta primeiro.")
    texto = (pasta / "roteiro.json").read_text(encoding="utf-8")
    r = json.loads(texto)
    titulo_leg, legenda = ler_legenda(fich_legenda)
    titulo = titulo or titulo_leg or r.get("titulo", "")
    if not titulo:
        recusa("sem titulo: passa --titulo ou poe-no na 1.ª linha do legenda.txt.")
    sha = hashlib.sha256(texto.encode("utf-8")).hexdigest()
    payload = {"titulo": titulo, "slides": len(r["cenas"]), "pasta": nome_pasta(titulo, sha),
               "ficheiro": "roteiro.json", "html": texto, "legenda": legenda}
    saida = pasta / "payload.json"
    saida.write_text(json.dumps(payload, ensure_ascii=True, indent=1), encoding="utf-8")
    print(f"payload: {saida}")
    print(f"tipo:    reel ({len(r['cenas'])} cenas)")
    print(f"pasta:   {payload['pasta']}")
    print(f"roteiro: {len(texto)} caracteres · sha256 {sha}")
    print(f"legenda: {len(legenda)} caracteres · 1.ª linha «{legenda.splitlines()[0]}»")
    print("\nNo Make (cenario 8120331) o campo html leva o roteiro e ficheiro = roteiro.json.")


def main(argv):
    args, titulo, teste = [], None, False
    it = iter(argv)
    for a in it:
        if a == "--titulo":
            titulo = next(it, None)
        elif a == "--teste-exemplo":
            teste = True
        else:
            args.append(a)
    if len(args) != 2:
        print(__doc__); sys.exit(1)
    pasta, fich_legenda = Path(args[0]), args[1]

    for marca, motivo in ((MARCADOR_PROBLEMAS, "o render deixou problemas por "
                           "corrigir"), (MARCADOR_EXEMPLO, "a pasta foi gerada "
                           "com --exemplo (regras editoriais relaxadas)")):
        if marca == MARCADOR_EXEMPLO and teste:
            print("TESTE: pasta de exemplo aceite so para testar este script. "
                  "Este payload NUNCA vai para o Make.")
            continue
        if (pasta / marca).exists():
            recusa(f"{motivo} -- ver {pasta / marca}. Corrige e volta a gerar.")
    if (pasta / "reel.mp4").exists() or (pasta / "roteiro.json").exists() and not (pasta / "carrossel.html").exists():
        return preparar_reel(pasta, fich_legenda, titulo)
    html_f, spec_f = pasta / "carrossel.html", pasta / "especificacao.json"
    for f in (html_f, spec_f):
        if not f.exists():
            recusa(f"falta {f}. Corre o render.py para esta pasta primeiro.")

    html = html_f.read_text(encoding="utf-8")
    spec = json.loads(spec_f.read_text(encoding="utf-8"))
    n = len(spec["slides"])
    if re.search(r"<script", html, re.I):
        recusa("o carrossel.html leva <script> -- a Cloudflare do make.com "
               "devolve 403.")
    if "base64" in html:
        recusa("o carrossel.html leva base64 -- nao passa pelo conector.")
    secoes = len(re.findall(r'<section class="pagina" data-slide="\d+"', html))
    if secoes != n:
        recusa(f"o carrossel.html tem {secoes} slides e a especificacao {n}: "
               "o html nao e o desta especificacao. Volta a gerar.")
    titulo_leg, legenda = ler_legenda(fich_legenda)
    titulo = titulo or titulo_leg
    if not titulo:
        recusa("sem titulo: passa --titulo ou poe-no na 1.ª linha do legenda.txt.")

    sha = hashlib.sha256(html.encode("utf-8")).hexdigest()
    # Pasta no repositorio Planipax/marca: data de hoje, titulo em minusculas e
    # o inicio do sha256, para que um carrossel corrigido nunca escreva por
    # cima do anterior (o GitHub recusa gravar sobre um ficheiro existente).
    import datetime, unicodedata
    base = unicodedata.normalize("NFKD", titulo).encode("ascii", "ignore").decode()
    base = re.sub(r"[^a-z0-9]+", "-", base.lower()).strip("-")[:48].strip("-")
    pasta_gh = f"{datetime.date.today():%Y-%m-%d}-{base}-{sha[:8]}"
    payload = {"titulo": titulo, "slides": n, "pasta": pasta_gh,
               "ficheiro": "carrossel.html", "html": html, "legenda": legenda}
    saida = pasta / "payload.json"
    # ensure_ascii=True: os espacos inquebraveis (\u00a0) e os acentos ficam
    # escritos como \uXXXX. Copiados a vista, os espacos inquebraveis passavam
    # a espacos normais sem ninguem dar por isso (aconteceu a 22/10/2026).
    saida.write_text(json.dumps(payload, ensure_ascii=True, indent=1),
                     encoding="utf-8")
    print(f"payload: {saida}")
    print(f"titulo:  {titulo}")
    print(f"slides:  {n}")
    print(f"pasta:   {pasta_gh}")
    print(f"html:    {len(html)} caracteres · sha256 {sha}")
    print(f"legenda: {len(legenda)} caracteres · 1.ª linha «{legenda.splitlines()[0]}»")
    if len(html) > LIMITE_HTML:
        print(f"AVISO: html acima de {LIMITE_HTML} caracteres -- pode nao passar "
              "pelo conector.")
    print("\nDepois de colar o html na chamada ao Make, confere que o campo tem "
          f"exatamente {len(html)} caracteres e este sha256.")


if __name__ == "__main__":
    main(sys.argv[1:])
