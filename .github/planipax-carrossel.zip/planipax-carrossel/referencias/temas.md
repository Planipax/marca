# Escolha do tema — regras completas

Lê este ficheiro **inteiro** no Passo 1, antes de escolher o tema, e outra vez
sempre que a pesquisa contradisser o `calendario.md` (secção «Manter o
calendário», no fim). As secções «Nunca pelo medo», «O que interessa a quem
lê», «Os números» e «Taxas e números de regime» estão em
`referencias/voz-e-escrita.md`.

---

## Passo 1 — Decidir o tema (texto completo)

### O objetivo é alcance

Estas publicações existem para **chegar a gente nova e ganhar clientes**, não só
para informar quem já cá está — esses recebem o que precisam por email e telefone.
Servem os dois: quem já é cliente vê que a casa acompanha, e quem não é descobre
que precisava de alguém que acompanhasse.

Escreve sempre para **quem talvez nem tenha contabilista**: o dono de uma loja,
alguém que abriu atividade há dois meses, quem está a pensar avançar com um
negócio e não sabe por onde começar. Isto vale para todos os temas, incluindo os
prazos — um prazo mal explicado só chega a quem já o conhecia.

**Nomear um setor é uma ferramenta, não um hábito.** Um dono de restaurante não
pára num carrossel sobre "obrigações declarativas"; pára num sobre restaurantes.
Em Beja e Moura, os setores que valem a pena nomear são a agricultura, a
restauração, o alojamento local, o comércio de rua, a construção e os serviços
por conta própria.

**Mas nomear um setor troca alcance por atenção, e nem sempre compensa.** A
pergunta que decide é simples: *este tema só se aplica a este setor, ou aplica-se
a qualquer negócio?*

- **Só àquele setor** — o IVA das refeições, o alojamento local, os apoios à
  agricultura. Nomeia-se, e ganha-se muito com isso.
- **A qualquer negócio** — a margem de cada venda, o custo de contratar, o saldo
  que não é lucro. Aqui nomear um setor **corta o alcance**: quem tem uma loja,
  uma oficina ou um consultório lê "restauração" na capa e passa à frente.

Um teste rápido: se o exemplo do carrossel funcionasse igual com outro produto e
outro preço, o tema é genérico e deve ser escrito assim. Usa exemplos de setores
diferentes ao longo do ano em vez de dirigir o carrossel a um só.

**O problema tem de ser real para quem lê.** Um tema pode estar correto,
bem escrito e não servir para nada, porque descreve uma dificuldade que os
clientes da Planipax não têm.

*"Quem assina quando o dono está de férias"* é um bom exemplo do erro:
procurações, segunda assinatura no banco, cheques em branco. Faz sentido numa
empresa com estrutura e vários responsáveis. Num café, numa oficina ou num
consultório de Beja, o dono não deixa de decidir por estar ausente — atende o
telemóvel. O problema não existe.

Antes de escolher, pergunta: **conheço alguém com um negócio pequeno a quem isto
já tenha acontecido?** Se for preciso imaginar uma empresa maior para o problema
fazer sentido, o tema não serve.

**Teste do tema, antes de escrever uma linha:** alguém que não percebe de
contabilidade *interessa-se* por isto? Não "consegue perceber" — *interessa-se*.
Se a resposta for não, muda de tema.

### O que resultou e o que falhou

Isto é observação, **não é um molde a repetir**. Houve uma versão desta skill que
transformou o padrão abaixo em regra obrigatória, e o resultado foi um carrossel
que cumpria a regra e não prestava. Serve para reconhecer um bom tema, não para
fabricar um.

**Resultaram:** quanto custa mesmo contratar · o subsídio de férias · as férias
fiscais de agosto · a ordem certa para contratar alguém.

O que têm em comum é serem **úteis a quem tem de decidir ou fazer alguma coisa**.
Umas corrigem uma conta que a pessoa faz mal de cabeça; outra é simplesmente a
ordem certa dos passos, sem correção nenhuma. Ambas as coisas servem.

**Falharam, e vale a pena saber porquê:**

- **Uma história do primeiro ano de atividade**, contada mês a mês até desaguar
  na conta grande de abril. Correta e assustadora. Ver "Nunca pelo medo"
  (em `voz-e-escrita.md`).
- **"Quatro contas que correm mal num restaurante".** O ângulo setorial é bom; o
  problema foi tratá-lo como lista de erros do leitor, e pressupor que é ele que
  faz a contabilidade. Um setor nomeia-se para dizer *isto é para si*, nunca para
  dizer *você anda a fazer isto mal*.
- **Um alerta de cinco slides sobre um prazo.** Um prazo sozinho não dá uma
  publicação. Dá uma frase. Se o tema é uma data e não há mais nada a dizer, ou
  se lhe encontra substância — o que é, quem paga, quanto, o que acontece a quem
  falha — ou se escolhe outro tema.
- **Uma comparação entre recibos verdes e empresa**, resolvida em três frases
  neutras. O tema é dos melhores que há. O erro foi não pesar nada: uma
  comparação existe para pôr vantagens e desvantagens à frente uma da outra, com
  peso, e não para dizer que depende.

### Os tipos de tema

São sete. É também a lista fechada de valores da coluna `tipo` do `historico.md`.

| Tipo | O que é | Quando |
|---|---|---|
| `pagamento` | Dinheiro que sai da conta de quem lê: IRS, IRC, IVA, IMI, contribuições, pagamentos por conta | Dentro da janela de quatro semanas |
| `prorrogacao` | Uma data conhecida que mudou por despacho, sem aviso | Assim que se confirma, enquanto for útil |
| `apoio` | Fundos europeus, incentivos, candidaturas abertas, apoios ao emprego e ao investimento | Enquanto a candidatura estiver aberta e houver tempo de a preparar |
| `novidade` | Uma regra nova ou alterada que muda o que as empresas têm de fazer | Quando entra em vigor, ou pouco antes |
| `educativo` | Um erro comum, um conceito mal percebido, uma prática de gestão | Sempre que não há urgência — é a maioria das semanas |
| `promocao` | Um serviço da Planipax, embrulhado em valor | No máximo uma por mês |
| `efemeride` | Aniversário da casa, datas com significado | Quando calham |

Três notas sobre o que **não** está na lista, e porquê.

**Não há tipo `noticia`.** Uma notícia que muda o que as empresas têm de fazer é
uma `novidade`; uma que não muda nada não é tema. Se a resposta a *"e agora, o
que faço com isto?"* for "nada", é comentário — e comentário não traz ninguém.
Um escritório publicou nove artigos sobre a mesma reforma fiscal em mês e meio;
seis meses depois já não interessavam a ninguém. Uma notícia serve uma semana;
um erro comum bem explicado serve anos.

**Não há tipo `setorial`.** Dirigir a um setor não é um tipo de tema, é um
**ângulo que se aplica a qualquer um deles** — e é o que mais traz clientes
novos. Ver a secção "O objetivo é alcance".

**Não há tipo `obrigacao`.** Era o que se usava no início e desapareceu de
propósito: uma obrigação declarativa sozinha não é tema. Quando o assunto é uma
entrega com data, o tipo é `pagamento` se houver dinheiro a sair, e `prorrogacao`
se o que mudou foi a data. As linhas antigas do histórico que ainda dizem
`obrigacao` ficam como estão — não se reescreve o passado.

**Apoios e fundos europeus** são dos temas que mais valem a pena e dos mais
esquecidos. Quem tem um negócio pequeno raramente sabe o que está aberto, e uma
candidatura perdida é dinheiro que não volta. Fontes a consultar: Portugal 2030,
Compete 2030, Alentejo 2030, IAPMEI, Turismo de Portugal, IEFP. Confirma sempre
por pesquisa que a candidatura está mesmo aberta e qual é a data de fecho —
**nunca publiques um apoio sem confirmar o prazo**, e nunca prometas
elegibilidade a ninguém: diz quem *pode* candidatar-se e remete o resto para
contacto.

### Ordem de prioridade

1. **Um pagamento a chegar** — dinheiro que sai da conta de quem lê. É a
   prioridade mais alta, mas só se estiver **mesmo perto**.
2. **Uma prorrogação confirmada** ou uma **candidatura a fechar**, se o prazo
   apertar.
3. **Uma obrigação declarativa a chegar** — mas sozinha **nunca é tema**. A
   comunicação de faturas, a DMR ou a declaração periódica de IVA são trabalho do
   contabilista: quem tem contabilista não as faz, e quem não tem também não as
   faz sozinho. Só entram como parte de um tema maior, e nunca em mais do que um
   slide. Ver a secção "O que interessa a quem lê" (em `voz-e-escrita.md`).
4. **Uma novidade** — regra nova ou alterada, com efeito real no que as empresas têm de fazer.
5. **Tema educativo, ancorado na época** — dirigido a um setor só quando o assunto
   for mesmo desse setor — a escolha sempre que não
   há urgência. Aberto no assunto, mas nunca solto no tempo.
6. **Promoção**: ocasional, no máximo uma por mês, sempre embrulhada em valor.
   Qualquer serviço serve; nenhum tem prioridade. Alterna ao longo do ano.

### O que é "mesmo perto"

Esta gestão é tua e ninguém a faz por ti. A regra é a proximidade, não a quota:

- Uma obrigação entra na janela quando faltam **quatro semanas ou menos** para a
  data-limite — ou o que disser a coluna `semanas_antes` do calendário, que manda
  sobre este valor por defeito.
- **Fora da janela, não é tema.** Um pagamento que vence a 30 de setembro não é
  assunto no início de agosto: não há pressa, ninguém age, e gasta-se um tema que
  fará falta em setembro.
- Se houver duas obrigações dentro da janela, escolhe a mais próxima — **exceto
  se for recorrente e já tiver saído há pouco tempo** (ver abaixo).
- **Passada a data, o assunto morre.** Nunca publiques sobre um prazo já vencido.
- **Sem nada dentro da janela, vai direto ao tema educativo.** Não é o último
  recurso nem um plano B — é o que ocupa a maioria das semanas do ano, porque a
  maioria das semanas não tem prazos a vencer.

**Obrigações recorrentes: a mais próxima não é sempre a certa.** As mensais e
trimestrais — comunicação de faturas, IVA, retenções, Segurança Social — repetem-se
o ano inteiro. Se escolheres sempre a mais próxima, o feed enche-se do mesmo
assunto doze vezes por ano e ninguém volta a parar nele.

Regra: uma obrigação recorrente só é tema **se não tiver saído nos últimos seis
meses** e se houver um ângulo que a torne diferente da última vez — a época, uma
mudança de regra, um erro comum que se está a repetir. Sem esse ângulo, salta-a e
procura a próxima obrigação anual dentro da janela, ou vai ao tema educativo.

As obrigações anuais — IMI, IRS, Modelo 22, IES, pagamentos por conta — não têm
este problema: acontecem uma vez e merecem a semana.

### O tema educativo também tem de fazer sentido HOJE

Um tema educativo não é um tema intemporal. **Vê sempre em que dia estás** e
escolhe algo que esteja a acontecer na vida das empresas nesta altura do ano.

**A data é sempre hoje.** Usa a data real do sistema. Nunca avances no calendário,
nunca assumas que a publicação anterior foi aprovada ou publicada, e nunca escrevas
"a publicação da próxima semana". Uma publicação que ficou por aprovar **não ocupa
uma semana** — se te pedirem outra hoje, é para hoje.

No `historico`, só conta como semana ocupada o que estiver marcado como
`publicado`. O que está `por aprovar`, `aprovado`, `enviado` ou `teste` serve
para não repetires o tema por engano, não para avançar o calendário.

**Teste obrigatório:** porque é que isto sai esta semana e não noutra qualquer?
Se a resposta for "sai igualmente bem em qualquer semana", o tema está vago —
procura o mesmo assunto por um ângulo que a época dê.

Não é preciso um prazo fiscal para haver âncora. Basta o que se está a passar:
férias, contratações, fecho de contas, orçamentos, arranque de ano.

| Mês | O que se está a passar nas empresas |
|---|---|
| Janeiro | arranque do ano, orçamentos, atualizações salariais, inventário feito a 31/12 |
| Fevereiro | preparação do IRS, aniversário da Planipax (19), organização do ano |
| Março | fecho de contas do exercício anterior |
| Abril | prestação de contas, época de IRS |
| Maio | IRS, primeira prestação do IMI, aprovação de contas |
| Junho | subsídio de férias, fecho do primeiro semestre |
| Julho | começam as férias, tesouraria de verão, equipas a rodar |
| Agosto | empresa a meio gás, quem responde na ausência do responsável, faturação de verão |
| Setembro | rentrée, retoma de atividade, orçamentos para o fim do ano |
| Outubro | preparação do fecho, decisões de investimento ainda a tempo |
| Novembro | planeamento do fecho do ano, subsídio de Natal a caminho |
| Dezembro | subsídio de Natal, inventário, decisões de última hora |

Esta tabela dá o contexto, não os factos. Qualquer data, prazo ou valor concreto
continua a exigir confirmação por pesquisa antes de ir para um slide.

**Exemplo da diferença.** Em agosto, "o saldo da conta não é o lucro" é verdadeiro
mas podia sair em qualquer mês. Com âncora, o mesmo território dá: *quem assina e
decide enquanto o responsável está de férias* · *o negócio não pára em agosto, mas
a faturação muda de ritmo* · *como se conta o subsídio de férias de quem entrou a
meio do ano*. Mesma utilidade, e uma razão para ser hoje.

Exemplos do que é um tema aberto: quanto guardar todos os meses para impostos ·
o que é dedutível e o que não é · abrir atividade, o que muda no primeiro ano ·
recibo verde ou empresa · porque é que o lucro não é o dinheiro que está na conta ·
o que fazer com faturas de despesas pessoais · quanto custa mesmo ter um empregado.

Exemplos do que **não** é um tema: a mecânica de um regime de tributação, os
escalões de um imposto, o articulado de um código. Isso é linguagem de gabinete.
Atenção que isto é sobre **temas**, não sobre números: uma taxa concreta com a
conta feita é bem-vinda dentro de um slide — ver "Taxas e números de regime"
(em `voz-e-escrita.md`).

### Como escrever mesmo os temas técnicos

Quando calhar uma obrigação, traduz. Em vez de *"80% da coleta do ano anterior,
95% acima de 500 mil euros de volume de negócios"*, escreve *"a conta parte do
imposto do ano passado — e é por isso que um ano fraco paga como se fosse bom"*.

Duas regras práticas: **se a frase só faz sentido para quem já sabe do assunto,
reescreve ou corta**; e se um assunto só se explica com percentagens e limiares,
provavelmente não é tema, ou precisa de outro ângulo. As regras de escrita dos
números estão todas na secção "Os números" (em `voz-e-escrita.md`).

### Datas a assinalar

Assinala sempre, quando se aproximam: o aniversário da Planipax (19 de fevereiro)
e as datas fiscais marcantes do ano.

### Três candidatos antes de escolher

**Nunca agarres no primeiro tema que serve.** Escreve três candidatos antes de
decidir, e para cada um uma linha só:

- **Qual é o tema.**
- **A quem tira uma dúvida, poupa dinheiro ou evita um susto** — e essa pessoa
  tem de ser alguém que talvez nem tenha contabilista. Se não souberes dizer a
  quem serve, o tema não serve.
- **Porque é hoje e não noutra semana qualquer.**

Depois escolhe, e escreve numa linha porque puseste os outros dois de lado.

Três chega. Com cinco, os dois últimos entram só para encher a lista, e comparar
enchimento não melhora decisão nenhuma. Os candidatos servem para pôr opções lado
a lado, não para justificar a que já tinhas escolhido — se os outros dois forem
obviamente fracos, é sinal de que não procuraste, procuraste desculpa.

**Isto não abre exceções às regras acima.** Um tema fora da janela de quatro
semanas, ou uma obrigação recorrente que saiu há menos de seis meses, não é
candidato — nem sequer entra na lista. As regras duras filtram; os candidatos
comparam-se dentro do que sobra.

Mostra os três ao Ricardo quando apresentares a publicação, na linha em que
explicas a escolha. Se ele discordar, é ali que o vê.

### Fontes

**Calendário** — `calendario.md` do projeto (colunas `data_limite`, `obrigacao`,
`a_quem_se_aplica`, `descricao_curta`, `semanas_antes`, `regra_ou_nota`).

**Histórico** — `historico.md` do projeto. Duas regras de repetição, ambas a
contar da `data_publicacao`: **oito semanas** para qualquer tema já publicado, e
**seis meses** para obrigações recorrentes (mensais e trimestrais).

Os dois vivem em markdown no projeto e **são a fonte a valer**. Houve um Excel
fora do Cowork de onde estes ficheiros se regeneravam; deixou de existir. Não o
procures, e sobretudo **não deixes de corrigir um destes ficheiros a pensar que
a correção se perde na próxima regeneração** — não há regeneração nenhuma. O que
não for corrigido aqui fica errado.

**Pesquisa web** — obrigatória em dois momentos:

1. **Antes de publicar qualquer prazo**, confirma que se mantém. Em Portugal os
   prazos fiscais são prorrogados com frequência, por despacho, às vezes poucos
   dias antes. O `calendario.md` pode estar desatualizado; a AT não.

   Se encontrares uma **prorrogação inesperada** — um despacho deste ano, uma
   data que mudou sem aviso —, é ela que vale e entra como candidato forte.
   Candidato, não tema automático: continua a passar pela lista dos três e pelo
   teste de a quem serve.

   **Cuidado com o que só parece novidade.** Um regime que se repete todos os
   anos — as férias fiscais de agosto, por exemplo — não é uma prorrogação nem é
   notícia, mesmo que o calendário do ano só saia em julho. Pode ser tema, mas
   pelo que faz ao dinheiro de quem lê, nunca por ser novo. E a capa não pode
   sugerir novidade onde há rotina.
2. **Ao procurar notícias do setor** — alterações legislativas, Orçamento do
   Estado, novos apoios e candidaturas, decisões com impacto nas empresas.

Se não houver calendário disponível, não bloqueies: escolhe pela época do ano
(em época de IRS, IRS; no fecho de contas, fecho de contas), por um assunto do
momento encontrado na pesquisa, ou propõe um tema educativo de raiz.

**Inventar o tema é permitido. Inventar factos não.** São coisas diferentes: podes
decidir sozinho falar de fluxos de caixa numa semana parada, mas o prazo, a taxa
ou a percentagem que usares têm de vir do calendário ou de fonte confirmada.


---

## Manter o calendário

**Se a pesquisa contradisser o `calendario.md`, corrige o ficheiro.** É a única
forma de a descoberta sobreviver à sessão — caso contrário, na semana seguinte
partes outra vez do ficheiro errado.

**Corrige no próprio ficheiro, sempre.** Nunca escrevas a correção num documento
à parte à espera que alguém a aplique: uma correção que depende de um passo
manual é uma correção que não vai acontecer. O `calendario.md` é a fonte, não uma
cópia de coisa nenhuma.

**Confirma a regra, não só a data.** Uma obrigação pode manter o dia e ter mudado
de natureza — ou ter deixado de existir. Aconteceu com o pagamento de
contribuições à Segurança Social, que o Decreto-Lei n.º 127/2025 passou do
período de 10 a 20 para até ao dia 25, e com a declaração de remunerações mensal,
que o mesmo diploma substitui por um pré-preenchimento que a empresa confirma.
Um calendário que só verifica datas não apanha nada disto.

Por isso, ao confirmar um prazo, pergunta também: **esta obrigação ainda existe
como está aqui descrita?** Se encontrares um diploma recente a alterá-la, para e
diz ao Ricardo antes de escrever seja o que for — uma alteração legal muda muitas
linhas de uma vez e é decisão dele, não tua.

**Atenção aos regimes transitórios.** Uma alteração pode estar em vigor com
aplicação faseada: obrigatória a partir de certa data, opcional até lá. Nesse
caso as linhas dos anos seguintes também mudam, e é o erro mais fácil de deixar
para trás.

**Um prazo que calha a um sábado, domingo ou feriado transita para o dia útil
seguinte.** É uma regra geral e é onde o calendário mais falha, porque as datas
foram escritas sem olhar ao dia da semana. Quando confirmares um prazo, confirma
também em que dia da semana cai — e se cair a um fim de semana, procura a data
efetiva antes de a publicar.

Como corrigir, sem estragar:

- Altera a `data_limite` para a nova data e escreve na coluna `regra_ou_nota`
  o que mudou, quando o descobriste e a fonte. Nunca apagues a data antiga sem
  a mencionar.
- Muda `confirmado` para `sim` **apenas** quando a fonte for oficial (Portal das
  Finanças, Diário da República, comunicado da AT). Notícias de imprensa não
  chegam para marcar como confirmado — servem para corrigir e sinalizar.
- **Diz sempre ao Ricardo o que alteraste**, com a data velha, a nova e a fonte.
  Uma alteração silenciosa num calendário fiscal é pior do que nenhuma.
- Uma prorrogação encontrada é quase sempre o melhor tema da semana: é a
  informação que os clientes precisam de saber naquele momento.

O calendário vai até dezembro de 2027. Quando faltarem menos de três meses para
o fim, avisa que está na altura de o prolongar.

**Só o estado `publicado` ocupa uma semana e gasta um tema.** As publicações
marcadas como `teste` foram feitas para afinar o sistema e os seus temas continuam
todos disponíveis para uso real.
