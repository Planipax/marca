# Voz e escrita — regras completas

Lê este ficheiro **inteiro** no Passo 3 (antes de escrever os slides) e volta
a ele no Passo 6 (legenda). O `SKILL.md` só tem o resumo executável; quando os
dois parecerem divergir, manda este ficheiro no que é escrita e o `SKILL.md`
no que é fluxo. As remissões para «Passo N» referem-se ao `SKILL.md`; o
Passo 1 (temas) está em `referencias/temas.md`.

---

## Voz

Português europeu. Tom formal mas não rígido: natural, humano e claro.

**Tratamento impessoal.** Evita "tu" e "você" — fala do assunto, não à pessoa.
"Quem trabalha por conta própria tem até…", não "o senhor tem até…".

**Linguagem acessível** a quem não percebe de contabilidade: explica sempre
qualquer termo técnico em palavras simples; se um conceito for avançado, traduz-o
antes de o usar.

Sem emojis nos slides. Na legenda, emojis formais (📌, ⚠️) permitidos quando
ajudam a ler (decisão do Ricardo, 27/10/2026). Sem regionalismos brasileiros e sem
presumir que o leitor é do Alentejo. Assina sempre como marca, nunca em nome de
uma pessoa.

### Vocabulário

**Português europeu profissional, mas claro e simples.** Profissional não quer
dizer solene: quer dizer correto, direto e sem gíria. O registo certo é o de
quem explica bem uma coisa ao balcão — não o de um ofício da repartição nem o de
um anúncio.

**O teste do balcão.** Lê a frase em voz alta. Se não a dissesses assim a um
cliente que entrou pela porta, reescreve-a. *"O costume volta a seguir"* não
passa no teste: ninguém fala assim. *"A partir de setembro, as datas voltam ao
normal"* passa.

**Frases direitas.** Sujeito, verbo, complemento. Uma ideia por frase. Sem
inversões literárias, sem orações encaixadas umas nas outras, sem começar pelo
fim.

**Nunca torças a frase para caber.** Se uma frase ficou estranha por causa do
limite de palavras, o problema é o limite, não a frase: tira um ponto ao
carrossel e escreve a frase direita.

Palavra simples em vez de palavra de gabinete:

| Escreve-se | Não |
|---|---|
| pagar | liquidar, proceder ao pagamento |
| entregar | submeter, remeter, dar entrada |
| fazer | efetuar, realizar, proceder a |
| para | de forma a, por forma a, no sentido de |
| até 31 de agosto | até ao dia 31 do corrente mês |
| empresa, negócio | entidade, agente económico |
| quem trabalha por conta própria | sujeito passivo, contribuinte singular |
| o imposto que já foi descontado | retenção na fonte (sem explicar) |
| prazo | termo, deadline |
| dinheiro em caixa | cash flow, liquidez |
| falta pouco | urge, importa acautelar |

Evita ainda: *"o mesmo"* como pronome (*"entregar o mesmo"*); a voz passiva
quando a ativa serve (*"a lei adia os prazos"*, não *"os prazos são adiados"*);
anglicismos com equivalente português; e chavões de marketing — *"num mundo cada
vez mais"*, *"a chave do sucesso"*, *"não é segredo que"*, *"venha connosco nesta
jornada"*.

Atenção ao gerúndio à brasileira: escreve-se *"está a preparar"*, nunca *"está
preparando"*.


---

## Regras fixas — desenvolvimento

A lista curta das regras fixas está no `SKILL.md`. Estas duas desenvolvem-na.

### Nunca pelo medo

Não basta evitar palavras assustadoras. **O medo entra pela estrutura**, e é aí
que passa despercebido a quem escreve.

Um carrossel que avança para uma consequência cada vez pior — a conta cresce, o
juro chega, o dinheiro acaba — está a assustar mesmo que cada frase seja calma.
E quem se sente assustado por uma marca não a procura: afasta-se dela.

Três testes, no fim de escrever:

1. **A última coisa que o leitor fica a saber é uma ameaça ou uma saída?** Tem de
   ser uma saída. Se o penúltimo slide é o pior cenário, a ordem está invertida.
2. **A publicação deixa a pessoa capaz de fazer alguma coisa?** Se o que ela pode
   fazer é preocupar-se, falhou.
3. **Um prazo é uma informação, não uma ameaça.** *"Paga-se até 31 de agosto"*
   basta. *"Quem falhar paga juros e arrisca execução fiscal"* é chantagem
   pequena, e não é precisa.

Uma consequência pode ser dita — faz parte de informar. Diz-se uma vez, com
calma, e nunca é o fim do carrossel.

### Não acuses ninguém, nem terceiros

O medo não é a única maneira de soar duro. **Uma capa que abre em queixa também
o é**, mesmo quando a queixa é justa e o alvo nem é o leitor.

*"O IVA não espera pelo pagamento"* e *"faturou 1.000 € e recebeu zero"* põem no
ar um cliente que não paga. É verdade e é um problema real, mas o carrossel abre
a reclamar em vez de explicar — e uma marca que abre a reclamar soa dura, mesmo
com razão.

O mesmo assunto sem dedo apontado: *"Quem fatura hoje entrega o IVA hoje"*, ou
melhor ainda, começar pela saída — *"Há um regime em que o IVA espera pelo
cliente"*. É a mesma informação, e o leitor fica com uma opção em vez de uma
queixa.

Regra prática: se a capa tem uma vítima e um culpado, reescreve-a até ter só um
facto.


---

## Passo 3 — Escrever os slides (texto completo)

Entre **5 e 8 slides**, conforme o tema.

**Oito não é o objetivo. É o teto.** Conta as ideias que tens antes de contar os
slides: se o tema tem três coisas para dizer, o carrossel tem cinco slides e está
bem assim. Esticar três ideias por sete slides obriga a inventar slides de
enchimento — um a repetir o que já se disse, outro a anunciar o que aí vem, outro
com uma data em letras grandes a fingir que é um dado. É isso que faz um carrossel
soar forçado, e nota-se sempre.

**Teste, slide a slide:** que ideia nova é que este slide traz? Se a resposta for
"prepara o seguinte" ou "resume os anteriores", o slide sai. A capa prepara, a
ponte fecha, e no meio só entra quem traz informação.

**Capa** — chama a atenção de forma natural: uma pergunta ou uma ideia que faz
parar. Sem clickbait, sem alarmismo, sem números inventados.

**Antes de escrever a capa, escolhe o gancho.** A maioria dos carrosséis de
contabilidade morre no primeiro slide, e morre por o primeiro slide anunciar o
assunto em vez de tocar em alguma coisa. Identifica primeiro um destes três, e
escreve a capa a partir dele:

1. **Um problema que a pessoa sente.** Uma dificuldade que ela já teve, mesmo
   sem lhe saber o nome.
2. **Um erro comum.** Uma coisa que muita gente faz mal e não sabe que faz.
3. **Uma consequência prática.** O que acontece, em dinheiro ou em tempo, a quem
   não souber isto.

Escreve qual dos três escolheste antes de escrever a capa. Se não conseguires
nomear nenhum, o problema não é a capa — é o ângulo do tema, e é aí que se
volta atrás.

- Anuncia o assunto e não prende: *"Pagamento por conta"* · *"Agosto tem outro
  calendário"* · *"Obrigações declarativas de julho"*.
- Nasce de um gancho: *"Porque é que se paga imposto antes de haver lucro?"*
  (problema) · *"Quase toda a gente marca os prazos de agosto no dia errado"*
  (erro) · *"Em agosto, três pagamentos caem quase todos na mesma semana"*
  (consequência).

O gancho não dá licença para exagerar. Continua a valer tudo o que está nas
regras fixas: sem medo, sem promessas, sem números inventados.

**Slides do meio** — explicam. Um ponto por slide, dito por inteiro: o que é, o
que muda e o que isso significa para quem lê. Enunciar o ponto não chega.

**Penúltimo slide** — é a **ponte para o contacto** e não pode faltar. Fecha o
raciocínio de forma que ter alguém a acompanhar o assunto apareça como a
consequência natural. Menciona sempre esse acompanhamento — não em nome da
Planipax, mas como ideia.

- Registo certo: *"Ter quem acompanhe estas datas poupa juros, sustos e tempo."*
  ou *"Vale mais uma pergunta a tempo do que um susto depois."*
- Registo errado, porque não faz ponte nenhuma: *"Contas feitas com antecedência."*
  É verdade, é bonito, e não aponta a lado nenhum.
- Evita neste slide: "fale connosco", "cá estamos para ajudar". O convite direto
  pertence à legenda e ao slide final.

**Slide final** — é fixo. Não leva texto: os contactos, a assinatura e os ícones
das redes já estão no motor.

### Formatos

**Não há uma forma única de carrossel, e não deve haver.** Se todos abrirem com o
assunto e seguirem com pontos numerados, ao fim de dois meses parecem todos o
mesmo. Escolhe o formato pelo tema, não por hábito.

| Formato | Quando serve | Cuidado |
|---|---|---|
| **Passo a passo** | Há uma sequência de ações com ordem certa | Cada passo é uma ação, não um conceito |
| **Comparação** | Duas hipóteses legítimas entre as quais alguém tem de escolher | Pesa os dois lados a sério; não termine em "depende" |
| **A conta** | O tema é um valor que as pessoas calculam mal | Um exemplo só, com a conta toda à vista |
| **Pontos numerados** | Vários aspetos independentes do mesmo assunto | É o formato por omissão; usa-o quando os outros não servem |
| **O que muda** | Uma regra ou uma data mudou | Ver a forma-tipo abaixo |

**Sobre a comparação**, que é dos formatos mais fortes e o mais fácil de
desperdiçar: existe para pôr vantagens e desvantagens frente a frente. Um slide
para cada lado não chega. Dá a cada hipótese o que ela tem de bom **e** o que ela
custa — em dinheiro, em tempo, em obrigações —, e no fim diz qual é a pergunta que
decide, não que a resposta depende. *"Depende"* é o que toda a gente já sabia.

**Formatos que não funcionam sozinhos:**

- **O alerta de prazo.** Cinco slides a dizer que há uma data não são uma
  publicação. Ou o tema tem substância — quem paga, quanto, o que mudou — ou não
  é tema.
- **A lista de erros do leitor.** *"Quatro contas que correm mal no seu negócio"*
  põe quem lê na defensiva, e pressupõe que é ele que faz a contabilidade. O
  mesmo conteúdo dito como *"quatro contas que num restaurante correm de outra
  maneira"* informa em vez de acusar.
- **A história com fim mau.** Ver "Nunca pelo medo".

**Forma-tipo para quando um prazo muda.** É o caso mais frequente e o mais fácil
de estragar. Esta estrutura foi aprovada pelo Ricardo e é o ponto de partida:

| Slide | Papel |
|---|---|
| 1 · capa | A mudança, pelo gancho escolhido |
| 2 · `01` | O que é a regra, em palavras simples |
| 3 · lista | **Um só slide** com a parte declarativa agrupada, com o antes de cada linha |
| 4 · `02` | O pagamento que mais se afasta da data habitual, com detalhe |
| 5 · `03` | O que **não** mudou, e porque parece que mudou |
| 6 · `04` | O efeito na conta: adiar não é dispensar, com exemplo em euros |
| 7 | Ponte |
| 8 | Final |

Repara no equilíbrio: **um slide para o que o contabilista trata, quatro para o
que sai do bolso de quem lê.** Se a proporção se inverter, o carrossel virou
calendário e é preciso voltar atrás.

Há duas referências aprovadas em `exemplos/`, e são de formatos diferentes de
propósito. **Lê a que se aproximar do teu tema antes de escreveres**, e compara o
teu texto com ela no fim:

- `referencia-prazo-alterado.md` — o que muda quando uma data se altera.
- `referencia-passo-a-passo.md` — uma sequência de ações por ordem. Traz também a
  lista dos formatos que foram rejeitados e a razão de cada um.

São para comparar, não para copiar. Se daqui a três meses saírem carrosséis com
esta cara e outras datas, a referência passou a ser um molde e deixou de servir.

---

## O que interessa a quem lê

Esta é a regra que decide o peso de cada slide, e é a que mais vezes se falha.

**Divide sempre o assunto em dois montes.**

**O que sai do bolso de quem lê** — pagamento do IRS, do IRC, do IVA, do IMI,
das contribuições, os pagamentos por conta, o custo de contratar. Dinheiro, datas
de pagamento, tesouraria. **É isto o carrossel.** A maioria dos slides trata
disto, e o exemplo numérico vive aqui.

**O que é trabalho do contabilista** — declarações periódicas, DMR, comunicação
de faturas à AT, Modelo 30, retenções enquanto obrigação declarativa, IES,
Modelo 22 enquanto entrega. Quem tem contabilista não faz nada disto, e quem não
tem também não o faz sozinho. **Cabe num slide, agrupado numa frase, e nunca em
mais do que um.** Diz-se que a parte declarativa também mudou e segue-se em
frente; não se percorre obrigação a obrigação.

**O teste, slide a slide:** isto muda alguma coisa para quem lê, ou é trabalho
que o contabilista faz na mesma? Se for a segunda, não ocupa um slide.

**Um carrossel não é um calendário.** Fora do slide da lista, no máximo duas
datas por slide. Sete datas espalhadas por cinco slides não se decoram a deslizar
no telemóvel — e ninguém tenta. A lista completa, obrigação a obrigação, vai para
a legenda, que é onde há quem a queira ler.

**Uma data solta não diz de que mês é.** *"Era a 5, passa a 31"* pode ser julho
ou agosto. Diz-se o mês pelo menos uma vez em cada slide onde houver datas.

**Não repitas a mesma ideia por três formas.** *"Já venciam a 31"*, *"não foram
adiados"* e *"continuam com o prazo de sempre"* são a mesma frase três vezes: o
leitor fica à espera da informação nova que nunca chega. Diz-se uma vez, bem, e
usa-se o espaço que sobra para outra coisa.

---

## Os números

Um número mal posto faz mais estragos do que uma frase mal escrita: quem não o
percebe não pergunta, fecha.

**Números pequenos e redondos.** 1 €, 10 €, 100 €, 1.000 €. Estes quatro chegam
para quase tudo, e um leitor a deslizar no telemóvel faz a conta de cabeça sem
parar. 2.460 € não. Se o exemplo precisar de escala maior, 10.000 € é o topo —
acima disso deixa de ser o negócio de quem está a ler.

Uma vantagem prática: com 100 € e 1.000 € as percentagens saem sozinhas. 23% de
1.000 € são 230 €, e vê-se logo. 23% de 2.460 € não se vê de todo.

**Um exemplo por carrossel, e é o mesmo do princípio ao fim.** Se abriste com uma
fatura de 1.000 €, é essa fatura que atravessa todos os slides. Três conjuntos de
números diferentes — uma fatura aqui, contribuições ali, IVA do trimestre mais
à frente — obrigam o leitor a tentar ligá-los, e ele não consegue porque não se
ligam.

**Cada número inventado entra como suposição, não como facto.** Dizer *"neste
exemplo são 40 €"* não chega: marca o número como exemplo mas continua a
apresentá-lo como um valor que o carrossel afirma, e quem lê fica sem perceber
de onde saiu. Escreve-se *"assumindo que se consumiu 40 € em matérias-primas"* ou
*"num negócio com 3.000 € de custos que não param"* — assim o número deixa de ser
uma afirmação e passa a ser **um espaço que o leitor preenche com o número dele**.
É a diferença entre ler uma conta alheia e fazer a própria.

Vale para todos os valores inventados, incluindo o primeiro. *"Uma venda de
100 €, para a conta ser fácil"* diz porque é 100 e não 87.

Não confundir com a regra das taxas: uma percentagem legal é um facto e escreve-se
como tal. A suposição é só para os valores que o carrossel inventou.

**A conta escreve-se por inteiro.** Nunca aparece um resultado sem as parcelas.
Quem lê tem de conseguir refazer a conta de cabeça, com os números à frente.

- Errado: *"numa fatura de 2.460 €, 460 € são IVA"* — de onde vêm os 460?
- Certo: *"Uma fatura de 1.000 € mais IVA a 23% dá 1.230 €. Os 230 € são do
  Estado; o negócio fica com 1.000 €."*

**Uma percentagem sozinha não é informação.** Diz sempre percentagem *de quê*, e
mostra o resultado em euros a seguir. *"21,4%"* não diz nada; *"21,4% sobre 1.000
€ de rendimento dá 214 € por mês"* diz.

**Um número por slide.** Se um slide tem três valores, tem três slides lá dentro.

**Nenhum número aparece sem o seu limiar.** *"80% ou 95% conforme o volume de
negócios"* está incompleto: falta dizer 500.000 €. Meia informação confunde mais
do que informação nenhuma. Se o limiar não cabe no slide, o número também não
deve lá estar.

**Uma ressalva nunca ocupa o lugar do requisito.** *"Aberto a negócios com
faturação até 2 milhões de euros, entre outras condições"* deixa o leitor sem
saber se pode ou não — e o "entre outras condições" não acrescenta nada, só
protege quem escreve. Ou as outras condições cabem e dizem-se, ou não cabem e
diz-se apenas o que se sabe. É a mesma doença do "depende", noutra roupa.

**Se o carrossel ensina a fazer alguma coisa, tem de dizer quanto.** Um carrossel
que manda separar a parte do Estado e depois responde *"depende de cada negócio"*
deixa o leitor exatamente onde estava — e lê-se como "contrate-nos para saber",
mesmo sem essa intenção. Dá-se um número de referência com a ressalva a seguir:
*"Guardar 25% do que entra cobre o IVA na maioria dos casos. Com empregados é
mais, e a conta certa faz-se uma vez."* A ressalva vem depois do número, nunca
no lugar dele.

### Taxas e números de regime

A regra antiga mandava todas as percentagens legais para a legenda. Estava
errada, e o Ricardo apanhou-a: uma taxa deixa de ser jargão no momento em que é
a base de uma conta que o leitor vê acontecer.

**Uma taxa entra no slide quando vem acompanhada da conta.** Diz-se a taxa, o
valor sobre que incide e o resultado, pela mesma ordem:

- *"A 1.000 € de ordenado a empresa soma 23,75% de Segurança Social — 237,50 €.
  Custa-lhe 1.237,50 € por mês."*
- *"O IVA à taxa normal é 23%. Sobre 1.000 €, são 230 € que não são do negócio."*

Repara na diferença face à versão anterior, que dizia *"cerca de 240 €"*. Quem lê
não consegue verificar um "cerca de", e quem sabe do assunto desconfia. A taxa
exata com a conta feita é mais clara **e** mais credível.

**Arredonda a entrada, nunca o resultado.** A base é 1.000 €, não 1.037 €. Mas se
23,75% de 1.000 € dão 237,50 €, escreve-se 237,50 € — não 240 €, não "cerca de
240". A conta tem de fechar: se as parcelas não somarem o total, o leitor que
tentar confirmar perde a confiança em tudo o resto.

**Fica fora dos slides a taxa sem conta.** Escalões, artigos de códigos,
percentagens citadas a seco — *"artigo 120.º do CIMI"* não explica nada a quem
não conhece o regime, só sinaliza que o assunto é para especialistas. Isso vai
para a legenda, onde quem quiser aprofundar o encontra.

**O que nunca se inventa é a taxa.** Confirma-a por pesquisa antes de a escrever,
como qualquer outro dado real. O exemplo em euros pode ser inventado; a
percentagem que lhe está por baixo, nunca.

**Exemplos que funcionam:** "Faturou 1.000 € mais IVA a 23%: o cliente pagou 1.230 €.
Desses, 230 € são do Estado e 1.000 € são seus." · "Comprou 1.000 € de stock e
vendeu metade. O custo deste mês é 500 €, não 1.000 €." · "Faturou 1.000 € e
recebeu 400 €. O lucro conta os 1.000; a conta só viu 400."

Em cada um a conta está toda à vista: as parcelas e o resultado. Um exemplo em
que o leitor não consegue refazer a conta de cabeça não é exemplo, é afirmação.

**E continua a valer a regra de ouro:** exemplos numéricos inventam-se à vontade,
desde que se perceba que são exemplos. Taxas, prazos e limiares reais, nunca.

---

## Clareza acima de tudo

**Decisão do Ricardo (30/10/2026), para carrosséis e Reels:** o texto escreve-se
para ser percebido à primeira, por quem não percebe nada de contabilidade — **mas
fala-se com empresários**: tom direto e profissional, de igual para igual, com o
dinheiro e as decisões da empresa no centro. Claro não é infantil nem
«tranquilo» de mais. Palavras do dia a dia; frases curtas, de preferência até 15 palavras; uma ideia
por frase; no máximo um termo técnico por publicação, explicado logo na primeira
vez. Teste antes de gerar: um empresário sem formação na área percebe
cada slide ou cada cena sem ter de reler? Se não, reescreve-se.

Um carrossel lido a deslizar no telemóvel não é um manual. Mas o erro mais
provável não é explicar demais — **é presumir que o leitor já sabe.** Quem
escreve conhece o assunto há anos e deixa de ver o que está a saltar. O resultado
são slides que parecem claros a quem os escreveu e são manchetes vazias para
quem os lê.

**Corta ideias, nunca palavras.** Um carrossel com três pontos bem explicados vale
mais do que seis reduzidos a títulos. O critério não é quantos pontos cabem, é se
cada um fica compreensível sozinho: se ao acrescentar um ponto os anteriores ficam
apertados, esse ponto sai — e é o último que sai, não o primeiro.

Fechar o tema numa publicação vale mais do que esticá-lo por semanas. Mas um tema
mal fechado não vale nada.

**Quem lê tem de perceber cedo se o assunto lhe diz respeito — mas não há um
slide obrigatório para isso.**

Durante algum tempo esta skill exigia que o slide 2 dissesse sempre a quem se
aplicava. O resultado foi que todos os carrosséis passaram a começar a
explicar-se antes de dizerem o que tinham para dizer, e ficaram todos com a mesma
cara.

Muitas vezes o assunto já diz a quem se aplica: *"Contratar alguém tem uma ordem
certa"* não precisa de um slide a informar que é para quem contrata. Quando o
público **não** for evidente — quando houver um limiar, uma exceção, ou risco de
alguém julgar que o assunto lhe diz respeito e não dizer — então sim, diz-se, e
diz-se cedo. Pode ser numa nota lateral, numa frase do corpo, ou num slide
próprio. A decisão é do carrossel.

**O que se explica sempre é o conceito central**, na primeira vez que aparece,
antes de qualquer consequência. Isso não é negociável: se a capa usa uma expressão
do meio, ela é traduzida antes de se falar do que provoca. Uma explicação enfiada
numa caixa lateral não conta — se o conceito precisa de explicação, é ele o
assunto do slide.

**Nada é referido antes de ser explicado.** Não perguntes "quanto saiu em julho"
se julho nunca foi mencionado. Cada slide só pode assentar no que já foi dito.
Isto vale também para datas: escrever *"o que sai do dia 10 e do dia 20"* só
funciona para quem já sabia que 10 e 20 eram as datas habituais.

**Quando uma data muda, a antiga aparece sempre ao lado da nova.** Sem o antes,
o depois não é notícia nenhuma — é só uma data. Escreve-se *"Retenções de IRS e
IRC — era a 20, passa a 31"*, nunca só *"31 de agosto"*. Numa lista, cada linha
leva o seu antes; num slide de conteúdo, a frase diz as duas.

**Uma exceção tem de se ver que é exceção.** Se algo parece igual ao resto mas
não é, diz-se porquê na mesma frase. *"O IMI mantém-se a 31 de agosto"* é
invisível para quem acabou de ler que tudo passou para 31 de agosto: escreve-se
*"O IMI já vencia a 31 de agosto — não foi adiado, apenas calha na mesma data."*

**As etiquetas descrevem, não avisam.** A etiqueta do topo diz de que trata o
slide: *O QUE MUDA*, *NA TESOURARIA*, *PRIMEIRO PASSO*. Nunca *CUIDADO*,
*ATENÇÃO* ou *IMPORTANTE* — é alarmismo barato e não acrescenta informação.

**Cada slide passa neste teste:** alguém que nada saiba do assunto percebe este
slide sozinho, sem voltar atrás nem ficar com uma pergunta por responder? Se não,
parte em dois — e se partir em dois não resolver, corta. Ter mais um slide é
barato; ter um slide confuso não é.

### Limites de escrita

**Numeração dos pontos.** O campo `numero` conta os **pontos de conteúdo**, não a
posição do slide. Começa sempre em `01` no primeiro ponto e segue sem saltos:
01, 02, 03. Slides sem número — listas, datas, exemplos — não interrompem a
contagem: se a lista fica entre o 02 e o seguinte, o seguinte é `03`, não `04`.
Um número que salta faz o leitor pensar que perdeu um slide.

- **Títulos até seis palavras.** É o limite da legibilidade no telemóvel. O
  título pode ser curto; o corpo não pode ser telegráfico.
- **Um título curto continua a ter de dizer alguma coisa.** *"Data a data"*,
  *"Ponto de situação"*, *"O essencial"* cabem em seis palavras e não informam
  ninguém. O título de uma lista nomeia o que está listado — *"As datas que
  mudaram"* — e o título de um slide de conteúdo diz o ponto, não anuncia que
  vem aí um ponto.
- **A etiqueta diz de que trata o slide, em palavras que já foram usadas.** Não
  pode separar o leitor de uma coisa que ainda não conhece: *"O que fica em
  agosto"* só faz sentido para quem já sabe que há qualquer coisa que sai de
  agosto. Se a distinção ainda não foi feita, a etiqueta não a pode usar.
- **O corpo é sempre uma ou duas frases completas, com sujeito e verbo.** Nunca
  frases nominais nem manchetes. *"O maior salto"*, *"Nem tudo mudou de data"*,
  *"Um calendário só para agosto"* soam bem e não dizem nada: obrigam o leitor a
  adivinhar o que falta. Escreve-se *"O IVA é a obrigação que mais se afasta da
  data habitual"*, e a seguir diz-se qual é a data.
- **Cada linha de uma lista tem um antes e um depois, e só um de cada.** Se uma
  obrigação vai para duas entidades em datas diferentes, são duas linhas. *"Salários
  de julho, antes a 10: à Segurança Social até 25, às Finanças até 31"* obriga a
  três leituras; separado, lê-se de uma vez.
- **Um exemplo numérico diz que valor sai em que dia.** Nunca um total dentro de
  um intervalo: *"os 5.500 € saem entre 31 de agosto e 25 de setembro"* não deixa
  ninguém preparar nada. Escreve-se *"2.000 € a 31 de agosto e 3.500 € a 25 de
  setembro"*.
- **Duas a três linhas de corpo é o normal.** Se não couber, o problema não é a
  frase — é o carrossel ter pontos a mais. Tira-se um ponto, não se cortam
  palavras à frase.
- Usa `<br>` para controlar as quebras de linha e o ritmo.
- As palavras com hífen (*conta-se*, *pagar-se-á*, *e-fatura*) nunca partem
  no hífen: o motor protege-as sozinho. Não ponhas nada à mão no JSON.
- As famílias `meia`, `dividido` e `cartao` gastam altura antes de o texto
  começar — a fotografia, a faixa e a caixa branca — por isso escrevem em corpo
  mais pequeno e só aguentam duas linhas de título. A verificação avisa, mas
  convém saber de antemão: a família é sorteada **antes** de o texto ser escrito
  (Passo 2), por isso escreve já a contar com a família que saiu — um texto que
  só assenta nas famílias largas obriga a reescrever.
- Em qualquer família, o campo `destaque` pinta a palavra de dourado por trás do
  texto. É para **uma expressão curta, numa só linha, sem `<br>`** — como
  *"sem perceber?"* no exemplo. Espalhado por duas linhas dá duas barras de
  comprimentos diferentes que, com o filete por baixo, parecem defeito de
  impressão.

---

## Prova de leitura — obrigatória antes de gerar (texto completo)

Escrito o texto todo, lê a sequência do princípio ao fim **como quem nunca ouviu
falar do assunto** e responde a estas perguntas, por escrito, para ti.

**Começa pela capa.** É a primeira coisa que se escreve e a última que se revê, e
por isso é onde as contradições sobrevivem. Lê a capa e o slide 2 lado a lado
antes de mais nada.

1. **A capa diz o mesmo que os slides do meio, e nasce mesmo do gancho?** É o
   erro mais provável de todos. Uma capa que diz *"este ano foram quase todos
   adiados"* contradiz um slide 2 que diz *"todos os anos, a lei adia"* — e faz
   parecer excecional o que é regra. Se o corpo do assunto é anual, a capa não
   pode sugerir novidade. E se a capa só anuncia o tema, o gancho perdeu-se pelo
   caminho: reescreve-a.
2. **Há alguma palavra do meio ainda por traduzir?** Percorre títulos, etiquetas
   e corpos à procura de termos técnicos. O sítio onde cada um aparece pela
   primeira vez tem de ser o sítio onde é explicado, ou vir depois dele.
3. **Algum slide assenta em informação que só está na minha cabeça?** Datas
   antigas, regras, valores de referência que nunca foram ditos nos slides
   anteriores. Vale para as etiquetas e os títulos tanto como para os corpos.
4. **Há duas afirmações que se contradizem?** Compara também o slide de resumo
   com os de detalhe. Se um diz que tudo foi para o mesmo dia e outro diz que
   cada coisa foi para um dia diferente, um dos dois está errado.
5. **Cada corpo tem verbo, e cada título diz alguma coisa?** Frases nominais no
   corpo, reescreve. Títulos que só anunciam — *"Data a data"*, *"O essencial"* —
   também.
6. **Quantos slides falam de dinheiro que sai da conta de quem lê, e quantos
   falam de trabalho do contabilista?** Os segundos não podem passar de um. Se
   passarem, o carrossel virou calendário.
7. **Cada número inventado diz de onde vem?** Percorre os valores um a um: os
   que o carrossel inventou têm de entrar como suposição — *assumindo que*, *num
   negócio com*, *para a conta ser fácil*. Se algum aparecer a seco, o leitor
   lê-o como aleatório e desliga.
8. **Os números passam no teste?** Um só exemplo a atravessar o carrossel,
   base arredondada, resultado exato, todas as contas escritas por inteiro, cada
   percentagem seguida do valor em euros, um número por slide. As contas fecham
   mesmo? Soma-as. E se o carrossel ensina a fazer alguma coisa, diz quanto — não
   responde "depende".
9. **O carrossel acaba numa saída ou numa ameaça?** Tem de acabar numa saída. Se
   a última coisa que o leitor fica a saber é o que lhe acontece se falhar, a
   ordem está invertida.
10. **Alguma coisa aqui acusa quem lê?** Fala-se do que há a fazer, nunca do que a
   pessoa faz mal.
11. **Tirando os títulos, o carrossel continua a fazer sentido?** Deve. Os títulos
   dão ritmo; a informação está no corpo.
12. **Há algum facto que o leitor vai conferir de cabeça e concluir que está
   errado?** É diferente de estar errado: está certo e *parece* uma gralha.
   *"A conta parte de 2024"*, numa publicação de 2026, faz o leitor subtrair um
   e concluir que devia ser 2025. As datas relativas são onde isto acontece
   sempre — o penúltimo ano, o mês seguinte, o segundo mês anterior. A regra:
   **o facto no título, a razão na primeira frase do corpo.** A razão tem de
   estar no mesmo slide, e tem de vir antes da conta.
13. **Lê a sequência em voz alta. Soa a fala ou a texto escrito?** O registo é
   profissional, mas a frase tem de poder ser dita ao balcão. O caso mais
   frequente em português europeu é a posição do clítico: *já*, *não*, *que*,
   *se* e *quem* puxam o pronome para antes do verbo. *"O IRS já se começou a
   pagar"* diz-se; *"o IRS começou a pagar-se"* escreve-se. As duas são
   gramaticais — escolhe a que se diz.

Se alguma resposta for má, corrige **antes** de gerar as imagens — e volta a
fazer a prova toda, do princípio, sobre o texto corrigido. Reescrever um slide
muda o que o seguinte pressupõe. Só se gera quando a prova passar de uma ponta à
outra sem apontar nada.

Gerar oito PNGs com o texto errado é trabalho deitado fora, e mostrar um carrossel
confuso ao Ricardo obriga-o a fazer a revisão que era tua.

### Ao corrigir, não troques um problema por outro

Uma correção é escrita nova, e escrita nova traz defeitos novos. O padrão que já
aconteceu: um slide dava o facto sem a razão, e a correção pôs a razão no título
em forma de pergunta — *"Porquê 2024 e não 2025"* — a interrogar o leitor sobre
uma data que ele ainda não tinha visto em lado nenhum. Trocou-se *facto sem
razão* por *razão sem facto*.

Uma pergunta no título só funciona se o leitor já a estiver a fazer. Se a
pergunta é sobre uma coisa que o slide ainda não disse, é cedo demais.

Por isso: depois de corrigir um slide, relê o anterior e o seguinte antes de
gerar. Um slide não se lê sozinho — lê-se depois do que vem antes.


---

## Passo 6 — Escrever a legenda (texto completo)

**Uma legenda só**, escrita à parte dos slides. Chama-se `legenda` e serve o
Instagram e o Facebook. **Nunca repete literalmente o texto dos slides.**

A primeira linha é um gancho autónomo, porque no Instagram o resto fica cortado
no feed. Depois **duas a quatro frases, e curtas**. As etiquetas vão sempre no
fim: no Instagram pesam, no Facebook são inofensivas, e no fim servem as duas
redes sem estorvar nenhuma.

**A legenda não refaz a conta dos slides.** É o erro mais fácil de cometer,
porque a conta está fresca e apetece resumi-la. Mas quem lê a legenda inteira já
não precisa de deslizar — e o carrossel passa a ser decoração de um texto.

A legenda leva **no máximo um número**, e só se ele funcionar como isco. Nunca a
sequência toda: nem o preço, mais o IVA, mais as matérias-primas, mais os custos
fixos, mais o ponto onde começa o lucro. Isso são os slides, e é para isso que
eles existem.

O que a legenda faz é dar uma razão para deslizar: nomeia o problema, diz a quem
serve, e para. Se depois de a ler alguém já souber a resposta, está errada.

Foram três até 2 de setembro de 2026, uma por rede. Passaram a uma nesse dia. O
Instagram e o Facebook são, em Beja e Moura, o mesmo público a ler o mesmo texto
em dois sítios, e duas legendas quase iguais eram duas coisas para manter e duas
para falhar em silêncio. A do LinkedIn deixou de se escrever porque o LinkedIn
saiu do âmbito: não se publica lá, nem pelo automatismo nem à mão.

**O LinkedIn continua no slide de contactos**, com o logótipo ao lado do
Facebook e do Instagram, e continua na assinatura da legenda. A página existe e
é um canal real — o que saiu foi a publicação, não o canal.

*Nota para quem reabrir esta decisão:* o LinkedIn não aceita carrosséis de
imagens orgânicos pela API, e é por isso que ficou de fora. Mas aceita
**documentos** de várias páginas, que mostra como slides deslizáveis. Gerar os
slides num PDF seria o caminho, e o serviço de conversão já sabe devolver PDF.
Não está feito; está possível.

A legenda convida ao contacto, sempre de forma discreta, e termina com:

```
Planipax · Contabilidade e Gestão · Beja e Moura
planipax.pt
```

**Só isto.** As moradas, os telefones e os endereços de correio já estão no
último slide, em grande e bem legíveis. Repeti-los na legenda alonga-a sem
acrescentar nada — a assinatura longa vinha de quando as legendas eram três e
cada rede levava a sua; deixou de fazer sentido a 4 de setembro de 2026.

### Etiquetas

Definidas a 22/10/2026, com o público-alvo alargado a todo o país. **São
escolhidas pelo agente em cada publicação** e ficam no fim do texto da legenda,
numa linha própria, imediatamente antes da assinatura.

- **No máximo cinco** (30/10/2026): desde dezembro de 2025 o Instagram só
  aceita cinco etiquetas por legenda, em publicações e Reels. Substitui o «sem
  limite fixo» de 27/10/2026. As duas fixas mais até três do tema.
- **Fixas, em todas:** `#Planipax` e `#Contabilidade`.
- **Do tema**, em português, da lista abaixo ou equivalentes:
  `#IRS` · `#IVA` · `#IRC` · `#SegurançaSocial` · `#Fiscalidade` ·
  `#Salários` · `#RecursosHumanos` · `#Empreendedorismo` · `#PequenasEmpresas` ·
  `#TrabalhoIndependente` · `#Portugal2030` · `#FundosEuropeus` · `#IPSS` ·
  `#GestãoDeEmpresas` · `#InteligênciaArtificial`.
- **`#Beja` e `#Moura` só** em publicações sobre a casa e a equipa, ou em
  temas que sejam mesmo locais. O público que se quer é nacional; uma etiqueta
  local num tema nacional estreita o alcance.
- Sem acentos partidos nem espaços (`#SegurançaSocial`, não `#Segurança Social`),
  e sem etiquetas em inglês.

**Listas na legenda** (27/10/2026): permitidas, com marcadores simples (•) ou
emojis formais (📌), **só** para informação que não esteja já nos slides ou no
vídeo. Se a lista repete os slides, sai.

**Nenhuma legenda leva markdown.** Nem asteriscos a fingir de negrito, nem
cardinais a fingir de título, nem travessões de lista. Nenhuma das redes
interpreta markdown: o que sai é o sinal à vista, `**assim**`, numa publicação
da empresa. Se um parágrafo precisa de destaque, dá-lho com a escrita — uma
frase curta isolada, uma quebra de linha — não com sintaxe.

