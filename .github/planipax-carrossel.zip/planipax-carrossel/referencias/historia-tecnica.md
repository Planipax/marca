# História técnica — incidentes e notas datadas

Lê este ficheiro quando fores **mexer no `render.py`**, acrescentar uma
família, um logótipo ou uma fonte, ou quando uma verificação der um
resultado que não percebes. Não é preciso para produzir um carrossel normal.
Cada nota diz o que aconteceu, o que se mudou e a regra que ficou.

---

## As famílias escuras e o logótipo branco (17 de setembro de 2026)

**O equilíbrio é deliberado e foi medido.** A 17/9/2026 comparou-se a
luminância média das famílias com a dos posts que a Planipax tem mesmo
publicados: o feed real anda entre 0,04 e 0,37, e o conjunto de famílias andava
entre 0,68 e 0,96 — cinco vezes mais claro. A maioria passou a escura para o
feed voltar ao registo sóbrio que a marca já tinha.

**Nas famílias escuras o logótipo do rodapé é a versão branca**, e isso não é
uma cedência: é o mesmo logótipo em negativo, e é o que a Planipax já publica —
vê-se no post «Inteligência Artificial», com o PLANIPAX a branco sobre
fotografia escurecida. A regra «o logótipo tem de ser o original» aplica-se às
famílias claras, onde o cinzento e o dourado se leem; sobre fundo escuro o
original desaparece e a versão branca é a correta.

## Nota técnica — fontes embutidas (31 de agosto de 2026)

Nos **PNG**, as fontes Poppins vão **embutidas em base64** no CSS, a partir de
`assets/fontes/` (WOFF2 reduzidos aos caracteres do português: 5 KB cada, em vez
dos 158 KB do TTF completo). No **`carrossel.html`** não: vão por endereço,
as mesmas WOFF2 alojadas no GitHub (ver a nota de 4 de setembro, abaixo).

**Porquê:** antes o CSS chamava a Poppins pelo nome. Funcionava no Cowork
por acaso — a Poppins está instalada no sandbox. Um conversor externo de
HTML para imagem (Cloudflare Browser Run, html2img, etc.) não a tem, e os
slides sairiam com uma fonte de recurso sem ninguém dar por isso.

**Regra:** se um dia se acrescentar um peso ou uma família nova, o ficheiro
WOFF2 correspondente tem de ir para `assets/fontes/` e ser declarado em
`FONTES_CSS` e `FONTES_CSS_WEB`, em `scripts/render.py` (e em `FAMILIAS_FONTE`,
que o render usa para confirmar com `document.fonts.check` que a fonte
carregou antes de medir). E o WOFF2 vai também para o repositório
`Planipax/marca`. Nunca chamar uma fonte só pelo nome.

## Nota técnica — a marca no HTML exportado (4 de setembro de 2026)

**Os PNG e o `carrossel.html` deixaram de levar a mesma coisa lá dentro.**

Os PNG continuam a ser gerados com os logótipos e as fontes embutidos em
base64, como sempre: o container não tem rede e o Playwright não conseguiria ir
buscar nada.

O `carrossel.html` exportado **não leva base64 nenhum**. Os dez logótipos e as
três fontes vêm de `https://raw.githubusercontent.com/Planipax/marca/main/`,
por endereço.

**Porquê:** o conteúdo do campo `html` passa pelo modelo a caminho do Make, e há
um teto de cerca de 25.000 tokens na leitura. Com tudo embutido o ficheiro dava
133.174 caracteres, uns 118.000 tokens, e a publicação **nunca chegou a sair**.
Sem base64 são cerca de 8.500 caracteres.

Reduzir as imagens não resolvia: mesmo a zero, as fontes deixavam o ficheiro
acima do teto. E uma fotografia média da biblioteca dá 175.000 tokens sozinha.

**As fontes estão no GitHub e não no Google Fonts**, de propósito. A Poppins do
Google não é a mesma: estas WOFF2 estão reduzidas ao português e são as que
desenharam os PNG aprovados. Métricas diferentes podiam alargar uma linha e
desfazer a verificação de transbordo sem ninguém dar por isso.

**Verificado a 4 de setembro:** o HTML exportado, a ir buscar tudo ao GitHub,
desenha 0,0000% diferente dos PNG em três slides e 0,0011% no quarto.

## Nota técnica — sem `<script>` no HTML exportado (7 de setembro de 2026)

O `carrossel.html` **não leva JavaScript**. Não é preferência de estilo: é o que
faz o pedido chegar ao Make.

O `make.com` está atrás da Cloudflare. Um pedido cujo corpo contenha `<script>`
tem o aspeto exato de uma tentativa de injeção de código, e o filtro devolve
**403 antes de o Make sequer ver o pedido** — sem mensagem que explique porquê.
Aconteceu a 7 de setembro, na segunda tentativa real de publicar.

O script existia para ligar os logótipos guardados uma única vez, quando eram
26 KB de base64 cada e valia a pena não os repetir. Com endereços de setenta
caracteres a poupança deixou de existir, e cada `<img>` passou a levar o endereço
escrito diretamente. A desduplicação foi retirada do código a 22/10/2026: já não
havia nada embutido para desduplicar, e era o único caminho que ainda podia
escrever um `<script>`.

**Regra:** nunca voltar a pôr JavaScript no `carrossel.html`. Se um dia fizer
falta um comportamento dinâmico, tem de ser resolvido no CSS ou na geração, não
no ficheiro exportado.

**Consequências a ter em conta:**

- O repositório `Planipax/marca` **tem de continuar público**. Privado, os
  endereços exigem autenticação, e os slides saem sem marca — sem erro nenhum a
  avisar.
- **O conversor tem de ter internet.** O htmlcsstoimage tem.
- **As fotografias estão alojadas no mesmo repositório** (desde 14/9/2026) e o
  `carrossel.html` usa-as por endereço (desde 16/9/2026). Se uma fotografia não
  estiver lá, fica base64 no ficheiro e o `render.py` dá problema.
- Se se acrescentar um logótipo novo, vai para `assets/marca/` **e** para o
  repositório, e entra em `_mapa_marca()`.


## Nota técnica — estilos isolados por slide no HTML exportado

Alguns slides injetam `<style>.zone{top:Xpx !important}</style>` para acertar a
altura do texto. Num PNG isso funciona: cada slide é um documento próprio. No
`carrossel.html` os oito partilham o mesmo documento, e **o `!important` do
último slide passava a mandar em todos** — o texto subia, e numa família com
fotografia a tag ia parar em cima da imagem, ilegível.

Consequência: o HTML entregue ao Make desenhava **diferente dos PNG aprovados**.
Até 7,3% dos píxeis de um slide. Ninguém dava por isso porque a revisão visual
é feita sobre os PNG, e o HTML só é olhado por uma máquina.

Corrigido a 31/08 em `exportar_html`, que agora prende cada regra ao seu slide
(`section[data-slide="N"] .zone{...}`).

**Medido de novo a 17/09/2026, nas nove famílias e no carrossel completo:** a
divergência entre o PNG e o HTML fica **abaixo de 0,005%** — cerca de 70 píxeis
em 1.458.000. Estão todos na mesma banda de 33px, na base do número gigante do
slide do tipo `numero`: é o serrilhado de um algarismo de 150px a ser desenhado
por dois caminhos diferentes, não uma diferença de composição. Nenhum outro tipo
de slide diverge.

Até esta medição a skill dizia «0,0000%». Não era verdade e vinha de uma
medição feita com oito famílias — a mesma armadilha de tomar um número antigo
por uma garantia permanente.

**Regra:** qualquer `<style>` novo dentro de um slide tem de passar pelo
`isolar_estilos`. Nunca assumir que um slide está sozinho no documento.

## Nota técnica — contraste do texto sobre fotografia

A verificação antiga só olhava para os logótipos. Um título sobre uma fotografia
clara passava sem aviso. Agora, nas famílias `filme`, `foto` e `meia`, cada texto que
assente sobre a imagem é medido contra o fundo real (percentil 75 da luminância,
para apanhar o pior sítio e não a média) e comparado com o mínimo WCAG: 4,5:1
para texto pequeno, 3,0:1 para texto grande.

**Só o texto sobre fotografia é verificado.** Nas famílias de fundo liso as
cores são as da marca, fixas e já aprovadas — o dourado `#C79A59` sobre creme dá
2,42:1 e é uma escolha deliberada. Verificá-las só geraria ruído. Sobre uma
fotografia o fundo muda a cada imagem escolhida e ninguém consegue prever se um
título desaparece; é aí que a máquina tem de olhar.

**O que a verificação apanhou a 17 de setembro de 2026.** Passou-se o catálogo
inteiro pela capa da família `foto`: das 29 fotografias, **nenhuma** passava. A
etiqueta dourada falhava nas 29, o destaque em 7 de cada 10, o corpo em 4 de
cada 10. A família estava a ser publicada com o aviso a disparar de todas as
vezes — e um aviso que dispara sempre deixa de se ler.

Duas coisas estavam erradas, e nenhuma era a fotografia:

1. **O véu era liso.** Tapava por igual o céu claro do topo e a sombra onde o
   texto assenta, por isso ou apagava a imagem ou deixava o texto a boiar. Passou
   a escurecer de cima para baixo: leve onde só há imagem, cheio na metade de
   baixo. Só com isto o destaque e o corpo deixaram de falhar.
2. **A etiqueta era dourada.** O dourado sobre fotografia não se lê: é texto
   pequeno, em maiúsculas e espaçado. Nem o véu mais escuro que ainda deixava ver
   a imagem lhe dava os 4,5 mínimos. Na família `foto` — **e só nela**, nesse
   dia; desde a nota seguinte também na `filme`, pelo token `GOLD_TXT` — a
   etiqueta da capa é branca. Passam as 29. O dourado continua no filete e no
   destaque.

Fica a regra: quando uma família falha a verificação com **todas** as imagens
possíveis, o problema não é a imagem que saiu no sorteio.

## Nota técnica — a família `filme`, e o dourado sobre fotografia (17/09/2026)

A `filme` nasceu de um pedido simples: a fotografia em **todos** os slides.
A `foto` larga-a nos slides de conteúdo, e a razão continua a valer — a mesma
imagem repetida cinco vezes faz o carrossel parecer parado.

A `filme` resolve isso sem largar a imagem: **a fotografia é sempre a mesma, o
enquadramento e o foco é que mudam.** Nítida na capa e no slide final, onde ela
manda; desfocada e mais escura no meio, onde passa a cenário. E desliza na
horizontal de slide para slide (`object-position` de 0% a 100%), por isso nunca
se vê duas vezes o mesmo pedaço. É a mesma fotografia, mas não a mesma imagem.

**O que ela ensinou sobre o dourado.** No primeiro carrossel completo, só **18
das 29** fotografias passavam. Não era a família: era o dourado a servir de
texto pequeno sobre imagem. A correção da etiqueta da capa, feita horas antes
para a `foto`, estava presa ao nome — dizia `deco == "foto"` — e a `filme`
herdou o defeito por não se chamar `foto`.

Criou-se o token **`GOLD_TXT`**: o dourado quando ele é **texto pequeno** e não
elemento gráfico. Nas famílias em que o texto assenta diretamente na
fotografia, é branco. O dourado continua no filete, na barra, no destaque e nos
números grandes, que têm corpo para aguentar. Com isso, 26 das 29; fechar um
pouco o topo do véu, onde a etiqueta da capa assenta, levou as duas famílias a
**29 em 29**.

**A lição que fica é maior do que o dourado.** Ao repetir o teste na `foto` com
um texto de capa diferente, ela caiu para 25/29 — depois de ter dado 29/29 com
outro texto. O contraste sobre fotografia não é uma propriedade da família: é
família × fotografia × texto. **Nenhum «29 em 29» é uma garantia permanente.**
O que protege de facto é a verificação correr em cada carrossel, antes de sair.

## Nota técnica — o que dá direito a uma família (17 de setembro de 2026)

Havia doze famílias. Hoje são nove. As que saíram não saíram por gosto: saíram
medidas.

O teste é simples e vale para qualquer família nova. Gera-se **a mesma
especificação** em todas as famílias e comparam-se as imagens resultantes,
slide a slide — não só a capa. A diferença conta-se como diferença média por
píxel. Abaixo de 3 é indistinguível a olho num telemóvel.

O que apareceu:

- `risco` contra `papel`: **0,00** no slide de conteúdo. Não parecido —
  **o mesmo ficheiro**, byte a byte. A família inteira vivia de um filete na capa.
- `numero` contra `cinza`: **2,9**, que é a distância entre o `STONE` (`#EEECE7`)
  e o `SAND` (`#F3EDE3`). Cinco unidades de cor. Ninguém vê isso num feed.

**Uma família justifica-se pela diferença que dura o carrossel todo, não pela
que se vê na capa.** Quem lê um carrossel vê a capa uma vez e os slides de
conteúdo três ou quatro vezes. Uma família que só muda na capa é a mesma família
com um enfeite. Hoje o par mais próximo das nove está nos **5,4**, e nenhuma
partilha slides de conteúdo com outra.

Cuidado ao medir: contar *quantos* píxeis diferem não serve, porque dois fundos
com cinco unidades de diferença dão «100% dos píxeis diferentes» e são a mesma
coisa aos olhos. O que conta é **quanto** diferem, não quantos.

## Nota técnica — costura tipográfica automática (31/08, 2.ª ronda)

O motor cose sozinho, em `costurar()`, três coisas que antes se escreviam à mão
em cada especificação — e que por isso só eram apanhadas quando alguém reparava:

1. **Palavras de uma ou duas letras** não ficam penduradas no fim da linha.
   Em português não se deixa um artigo ou uma preposição sozinha: «uma prestação
   a / pagar» lê-se aos solavancos. Apanhado na publicação do IRS, em seis dos
   oito slides.
2. **Valor e símbolo andam juntos** — `€`, `%`, `·`, `—` nunca se separam do que
   os precede.
3. **Viúvas**: a última palavra de um bloco não fica sozinha na linha. Era o caso
   de «Avenida do Carmo / 26» no slide de contactos.
4. **Palavras com hífen** (22/10/2026): *conta-se*, *pagar-se-á*, *e-fatura*
   ficam num `<span style="white-space:nowrap">`. O Chromium parte a seguir a
   um hífen, e «conta- / se» lê-se como palavra cortada. Como o `carrossel.html`
   é montado pela mesma `monta_slide`, a proteção sai também no exportado.

**A costura nunca entra em `<style>` nem em `<script>`.** Aprendeu-se à força: um
espaço inquebrável dentro da CSS parte a regra. `282px !important` virava
`282px\xa0!important`, o `!important` deixava de valer, o texto subia — e ia
parar em cima da fotografia. A verificação de contraste apanhou-o, o que é o
melhor argumento a favor de a ter.

## Nota técnica — o destaque da capa

O destaque da capa usa `box-shadow:inset` com `padding-bottom:12px`. Sem esse
padding a barra cortava as descidas do p, g, q e j — via-se na capa do IRS, onde
o dourado atravessava o «p» e o «g» de «a pagar». Em elementos inline o padding
não altera a altura da linha, por isso nada mais se desloca.


## Nota técnica — verificações acrescentadas a 22 de outubro de 2026

- **Validação da especificação antes de desenhar** (`validar()` no `render.py`):
  família existente; 5 a 8 slides; capa primeiro e final no fim; campos aceites
  por tipo (tabela `CAMPOS`, deduzida das funções `corpo_*`); numeração 01, 02,
  03… sem saltos nos slides de conteúdo; destaque sem `<br>`. Com erro, não se
  gera nada (código 3). Avisos, sem parar: título com mais de seis palavras,
  valor do slide `numero` só numérico e curto (sem unidade nem mês), destaque
  colado à última palavra do título. `--exemplo` passa o número de slides e a
  numeração a aviso — só para os ficheiros de `exemplos/`, que são amostras de
  família com três ou quatro slides.
- **Transbordo horizontal.** Um valor longo no slide `numero` («12.995 €» a
  150px) saía pela direita e era cortado pelo `overflow:hidden`, sem aviso.
  Mede-se agora `scrollWidth > clientWidth`, caixas fora do slide na horizontal
  e cada linha de texto (Range). A linha dos e-mails do slide final ocupa por
  desenho 23px da margem de cada lado; leva a classe `.sangra`, que a deixa usar
  a margem mas não a borda do slide.
- **Fontes.** Antes de medir e fotografar, `document.fonts.ready` e confirmação
  com `document.fonts.check` para Poppins, Poppins Light e Poppins Medium.
- **O X do canto** passou a ter a classe `.marca`, e entra na verificação de
  contraste da marca como o wordmark.
- **Pasta limpa.** Os `slide*.png`, o `carrossel.html` e o `NAO_ENVIAR.txt`
  antigos são apagados antes de gerar. Um carrossel de oito slides corrigido
  para seis deixava `slide07.png` e `slide08.png` na pasta.
- **Teto do `carrossel.html` em 25.000 caracteres** (`LIMITE_HTML`). O aviso
  antigo só disparava acima de 60 KB, mais do dobro do teto. Base64 ou
  `<script>` no ficheiro também são problema.
- **«NÃO ENVIAR».** Com qualquer problema, o render escreve na mesma os PNG e o
  HTML (para se poder ver), mas abre a saída com um aviso grande e deixa
  `NAO_ENVIAR.txt` na pasta; o `preparar_envio.py` recusa enviar essa pasta.
- **`especificacao.json`** fica na pasta de saída, cópia exata do que foi
  desenhado: é dela que o `preparar_envio.py` tira o número de slides, e é ela
  que se guarda no `.md` da publicação.

## Nota técnica — a secção da desduplicação por script (apagada a 22/10/2026)

Até esta data o `SKILL.md` tinha uma nota a dizer que o `carrossel.html`
guardava cada imagem uma vez e a ligava aos slides por script, e que o conversor
tinha de executar JavaScript. Contradizia a regra de nunca pôr `<script>` no
ficheiro (nota de 7 de setembro) e descrevia código que já não corria. Foi
apagada; o histórico dela está na nota de 7 de setembro.
