# Publicar — passo detalhado

Lê este ficheiro **só depois de o Ricardo ter escolhido «Publicar»**, e lê-o
inteiro antes de chamar o Make. Antes da aprovação não tem nada que fazer.

Estados no `historico.md`: `por aprovar` → `aprovado` → `enviado` →
`publicado` (e, fora da linha, `teste` e `rejeitado`).

---

## Passo 8 — Publicar

Só depois de aprovado. Se o Ricardo não disse que sim, este passo não existe.

### Como perguntar

Depois de apresentar, oferece duas escolhas — nunca uma pergunta aberta.

Se o ambiente tiver botões ou opções clicáveis, usa-os, com estas duas:

- **Publicar**
- **Ajustar alguma coisa**

Se não tiver, pergunta em texto, numerado, e não avances sem uma resposta clara:

> **1 — Publicar** · **2 — Ajustar alguma coisa**

**«Está bom» não é autorização.** Nem «gostei», nem silêncio, nem o facto de ele
ter pedido um ajuste e ter ficado calado a seguir. A publicação é irreversível
pela API — apaga-se na aplicação do telemóvel, mas nesse intervalo já foi vista e
já notificou seguidores. Na dúvida, pergunta outra vez.

Escolhido **Ajustar**, regressa ao Passo 4, corrige só o que foi pedido, e volta a
apresentar com as mesmas duas opções. Sem limite de voltas.

### Regenerar antes de enviar

**Regenera o `carrossel.html` imediatamente antes de publicar**, mesmo que aches
que está igual. Cada ronda de correções produz um HTML novo e o antigo continua
na pasta com o mesmo nome de sempre — enviar o de antes do ajuste publica a
versão errada, sem erro nenhum a avisar. É o erro mais caro deste passo porque
não se vê: os slides saem bonitos, só não são os que foram aprovados.

### Chamar o Make

O Make é alcançado pelo conector MCP. O sandbox não tem saída para a internet —
não tentes `curl` nem `requests`, não funciona.

**Ferramenta:** `Make:scenarios_run` com `scenarioId: 7202842`, e os campos
abaixo dentro de `data`. Existe também uma ferramenta dedicada do cenário,
`Make:s7202842_publicador_de_carrosseis_nas_redes_sociais_da_p`, que recebe os
mesmos quatro campos diretamente. **Qualquer das duas serve** — usa uma só por
publicação. A regra de não repetir sem ver `Make:executions_list` (mais abaixo)
vale para as duas: chamar uma e depois a outra é repetir.

**Prepara o envio com o script, nunca à mão:**

```bash
python3 scripts/preparar_envio.py saida/ legenda.txt
```

Ele lê o `carrossel.html` da pasta (nunca o copies à mão de outro sítio), tira o
número de slides da `especificacao.json` que o render deixou na pasta, corta o
cabeçalho do `legenda.txt` e grava `saida/payload.json`. Imprime o comprimento
do `html`, o sha256 e o número de slides. **Recusa** se o render deixou
problemas (`NAO_ENVIAR.txt`), se a pasta veio de `--exemplo`, se o `html` tiver
`<script>` ou base64, ou se a legenda não tiver a linha de traços.

O conteúdo continua a ter de ser colado na chamada pelo modelo. Cola os campos
do `payload.json` tal como estão e, **antes de chamar**, confere que o `html`
que vais enviar tem o comprimento que o script imprimiu e começa por `<html>` e
acaba em `</html>`. Se não bater, não chames: volta a ler o `payload.json`.

**Cenário `7202842`.** Campos a enviar:

| Campo | O que leva |
|---|---|
| `titulo` | o título da publicação, só para se reconhecer no histórico do Make |
| `slides` | o número de slides, tal como no carrossel |
| `html` | o conteúdo completo do `carrossel.html`, do `<html>` ao `</html>` |
| `legenda` | **só o corpo** do `legenda.txt` — o que vem depois da linha de traços |

**Relê o `legenda` antes de enviar.** Se a primeira linha tiver uma data ou o
nome de uma família de desenho, estás a mandar o cabeçalho do ficheiro para
dentro da publicação. Corta até à linha de traços e envia só o que vem abaixo.

O `html` anda pelos 7.000–10.000 caracteres. O teto prático do conector é de
cerca de 25.000 (ver `historia-tecnica.md`) — o `render.py` dá problema acima
disso. Não o cortes nem o resumas.

O cenário converte cada slide em imagem, junta os endereços num array e publica o
carrossel no Instagram e no Facebook.

### A mensagem de confirmação

Depois de o cenário correr, **manda sempre uma mensagem na mesma conversa** — a
mesma onde o carrossel foi gerado e aprovado. Nunca deixes o Ricardo sem saber
como acabou: uma execução silenciosa é indistinguível de uma que nunca arrancou.

Correu bem, diz:

- que o cenário correu até ao fim e o Make aceitou a publicação
- quantos slides foram enviados
- que o estado passou a **`enviado`** no `historico.md` — **ainda não
  `publicado`**
- que ele deve **confirmar nas duas redes, Instagram e Facebook**, que a
  publicação apareceu com as imagens; só com essa confirmação passa a
  `publicado`

Falhou, diz:

- **em que módulo** parou e com que erro, em português corrente
- que o estado **ficou em `aprovado`**, não em `publicado`
- o que fazer a seguir, se for dos erros conhecidos mais abaixo

**Nunca escrevas «não consegui» sem dizer onde.** Um erro sem localização obriga
a repetir a investigação toda numa sessão futura.

### O cenário correr não é a publicação existir

São coisas diferentes e é fácil confundi-las. `SUCCESS` quer dizer que os módulos
correram sem rebentar. Não quer dizer que o carrossel apareceu na conta.

A publicação pode falhar dentro do módulo do Instagram ou do Facebook — PPA em
falta, formato recusado, autorização caducada — e a execução ainda assim chegar
ao fim. Se anunciares sucesso e marcares `publicado` em cima de uma publicação
que não existe, o tema fica gasto e a semana ocupada por nada, e o assunto nunca
mais é proposto.

**São duas redes e podem falhar em separado.** O Instagram sai pelo módulo 7 e o
Facebook pelo 8, no fim da cadeia. Uma execução pode publicar numa e falhar na
outra. Se isso acontecer, diz **em qual** saiu e em qual não — e o estado fica
`enviado`, não `publicado`, enquanto faltar uma.

**O caso mais traiçoeiro é o Facebook publicar sem imagens.** Se os endereços
chegarem vazios ao módulo 8, a publicação sai só com a legenda e **sem erro
nenhum**. Nunca dês a publicação por boa sem o Ricardo confirmar nas duas contas.

Por isso a mensagem diz o que sabes de facto: **o cenário correu e o Make aceitou
a publicação**. A confirmação a sério é o Ricardo abrir a aplicação e ver. É por
isso que lhe pedes que confirme — não é formalidade.

### Se a chamada falhar, NÃO repitas

**Esta é a regra mais importante do passo 8.**

Se o `Make:scenarios_run` devolver um erro — 502, tempo esgotado, resposta vazia,
o que for — **não voltes a chamar**. Um erro na resposta não quer dizer que o
cenário não correu: quer dizer que a resposta não chegou. O cenário pode ter
publicado e a confirmação ter-se perdido no caminho de volta.

Aconteceu a 7 de setembro de 2026, na primeira publicação bem-sucedida: a
primeira chamada devolveu 502, foi repetida duas vezes, e **saíram três
publicações iguais** na conta. As três execuções correram com sucesso; só as
respostas é que se perderam.

**O que fazer em vez de repetir:**

1. Lista as execuções do cenário `7202842` com `Make:executions_list`.
2. Vê se existe uma execução recente com `status: 1`. Se existir, **o cenário
   correu** — segue para a mensagem de confirmação como se a chamada tivesse
   corrido bem: estado `enviado`, e pedes ao Ricardo que confirme nas duas
   redes. `status: 1` não é prova de publicação (ver acima).
3. Só se não houver execução nenhuma é que se pode tentar outra vez.
4. Na dúvida, **não repitas**: diz ao Ricardo o que aconteceu e pede-lhe que
   confirme na aplicação.

O custo de repetir sem verificar é publicar duas ou três vezes na conta de
clientes, e cada cópia tem de ser apagada à mão. O custo de não repetir quando
devias é o Ricardo escrever «1» outra vez. Não são comparáveis.

### Depois de enviar

**Com a chamada ao Make bem-sucedida, o estado passa a `enviado`** — não a
`publicado`. Se a execução falhar, o estado fica `aprovado`, e dizes ao Ricardo o
que correu mal.

**`publicado` só se escreve quando o Ricardo confirmar que viu o post nas DUAS
redes** — Instagram e Facebook, com as imagens. Nem o `SUCCESS` do cenário nem
o `status: 1` de uma execução chegam. Marcar como publicado o que não saiu é o
pior erro do sistema: a semana passa a contar como ocupada, o tema fica gasto, e
o assunto nunca mais é proposto.

Confirmado pelo Ricardo, vai ao `historico.md`, muda o estado para `publicado` e
preenche a `data_publicacao` com o dia em que saiu.

Uma linha em `enviado` não fica assim: na sessão seguinte, antes de escolher o
tema, pergunta-lhe se viu a publicação nas duas redes e fecha-a.

### Erros conhecidos

**A lista de Páginas vem vazia** — falta a Autorização de Publicação da Página
(PPA) do lado da Meta. Não é coisa que se resolva na skill; diz ao Ricardo.

**A autorização expirou** — as ligações da Meta caem ao fim de 60 dias sem uso,
ou antes disso se a palavra-passe ou a autenticação mudarem. Tem de ser
reautorizada no Make. Não é avaria.

**Erro de formato da imagem** — a API do Instagram só aceita JPEG. O cenário já
trata disso acrescentando `.jpg` ao endereço; se este erro aparecer, é sinal de
que essa parte da configuração se perdeu.

**O Facebook publica só a legenda, sem imagens** — os endereços chegaram vazios
ao módulo 8. O Facebook exige um formato diferente do Instagram (`type` e `url`,
em vez de `media_type` e `image_url`), e por isso a cadeia tem um Iterator e um
segundo aggregator só para ele. É aí que se procura.

**403 sem explicação, antes de o Make responder** — é a Cloudflare, que está à
frente do `make.com`, a recusar o pedido por conter `<script>`. O
`carrossel.html` não leva JavaScript desde 7 de setembro; se este erro voltar, é
sinal de que voltou a levar.
