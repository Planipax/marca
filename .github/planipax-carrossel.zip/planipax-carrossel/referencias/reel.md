# Reels — vídeo com narrador

Lê-se **inteiro** quando o Passo 1-A decidir que o tema sai em Reel. Substitui os
Passos 2 a 5 do carrossel e adapta o 7 e o 8. Tudo o resto do `SKILL.md` vale
igual: as regras fixas, a voz da casa, a revisão de marca, o histórico e a regra
de que **nada se publica sem o «sim» explícito do Ricardo**.

Criado a 28/10/2026. Decisões do Ricardo nesse dia:

- Reel com **narrador a falar**, em português de Portugal. Nada de avatar do
  Ricardo nem de ninguém (fica artificial).
- Estilo **fundo claro**, com **objetos ilustrados animados** (faturas,
  extratos, telemóvel, calendário, carimbos, moedas, mão a apontar), na linha
  das contas OSLO - AI Studio e empresariosdeportugal. Não só texto, não
  fotografias de fundo.
- **O texto no ecrã é exatamente o que o narrador diz**, palavra a palavra.
  Não se resume nem se encurta o texto do ecrã em relação à narração.
- Cada tema sai **ou** em carrossel **ou** em Reel, nunca nos dois.

---

## Estilo visual (decidido a 29/10/2026)

Referência: a contenção da Apple nas redes (instagram.com/apple, visto a
29/10/2026), com as cores, a letra e o fundo claro da Planipax:

- **Uma coisa de cada vez.** Um objeto principal por cena, grande, com ar à
  volta. Dois no máximo, se a frase os opõe (lucro ≠ saldo).
- **Sem logótipo nem barra de progresso em cada fotograma.** A marca aparece no
  cartão final (e na capa). Não voltar a pôr o wordmark no topo.
- **Texto grande e compacto** (34 px, espaçamento apertado), cinzento-escuro,
  uma ou duas expressões a dourado.
- **Movimento lento e suave**, sem ressaltos: os objetos entram a deslizar e a
  aparecer, nunca a «saltar». Sombras largas e suaves.
- **Fotografias em cartões de cantos redondos**, nunca polaroides. Arquitetura,
  luz, um só assunto. Fotografias de pessoas da equipa só com autorização.
- **Os escritórios mostram-se pelas montras** (`montra_beja.jpg`,
  `montra_moura.jpg`), lado a lado e do mesmo tamanho: são o par que diz «duas
  casas». A `montra_beja.jpg` já está enquadrada sem as pessoas, o carro e o
  letreiro do gabinete vizinho; não usar o original. Nas outras fotografias de
  interior, a `escritorio_image00040.jpg` e a `escritorio_DSC-0025.jpg` foram
  recusadas pelo Ricardo para este uso.

---

## 1. Escrever o roteiro

O roteiro é um JSON. Há dois exemplos: `exemplos/reel-lucro-tesouraria.json`
(educativo, objetos ilustrados) e `exemplos/reel-apresentacao-planipax.json`
(institucional, montras e objetos; o primeiro post da fase digital). Copia a
estrutura do que estiver mais perto do tema.

```json
{
 "titulo": "nome interno, não aparece",
 "capa": {"etiqueta": "Lucro vs. tesouraria",
          "titulo": ["Deu *lucro*.", "Então porque está", "a conta *vazia*?"],
          "figs": [ ... ]},
 "cta": "Siga a Planipax",
 "cenas": [
   {"texto": "A sua empresa deu *lucro* este ano.", "figs": [ ... ]},
   ...
 ]
}
```

### A narração

- **Entre 6 e 12 cenas**, uma frase por cena. O vídeo fica entre 25 e 45
  segundos; o motor recusa acima de 90 s (limite do Facebook) e avisa acima de 60.
- **Uma ideia só no Reel inteiro**, com um exemplo. Se precisar de duas ideias,
  é carrossel ou são dois Reels em semanas diferentes.
- A primeira cena **é o gancho e começa já**: o vídeo abre com o objeto em
  cena, sem segundo em branco nem logótipo. Os primeiros dois segundos decidem
  se a pessoa fica.
- Frases para o ouvido: curtas, sujeito-verbo-complemento, uma vírgula no
  máximo por respiração. Lê em voz alta antes de gerar.
- Escreve-se como se fala em Portugal: «faturada», «três meses», clíticos no
  sítio (ver `voz-e-escrita.md`). Números ditos por extenso quando soarem
  melhor («três meses», não «3 meses»).
- `*palavras entre asteriscos*` ficam a dourado. Uma ou duas expressões por
  cena, as que levam a ideia.
- **A penúltima cena dá a saída**, a última fecha com a Planipax («Na Planipax,
  ajudamos a…»), sem «fale connosco» e sem tom de venda. O cartão final com o
  logótipo e o `cta` é automático.
- O campo opcional `"voz"` serve **só** para corrigir a pronúncia (ex.: uma
  sigla). Tem de ter as mesmas palavras que o `texto`; o motor avisa se não tiver.

### Os objetos

Cada cena **mostra** o que a frase diz. O objeto não é decoração: se a frase
fala de uma fatura, aparece a fatura; se fala de tempo, o calendário avança.

| Tipo | O que é | Campos próprios |
|---|---|---|
| `dr` | demonstração de resultados | `empresa`, `ano`, `linhas` [[rótulo, valor]], `resultado` [rótulo, valor] |
| `fatura` | fatura | `num`, `linhas`, `total` |
| `extrato` | extrato bancário (valores negativos a vermelho) | `cab`, `linhas` |
| `documento` | papel genérico (recibo, guia, declaração) | `cab`, `titulo`, `linhas`, `total`, `ilus` |
| `tel` | telemóvel com um valor | `rotulo`, `saldo` |
| `cal` | calendário que avança durante a cena | `seq` [[mês, dia, ano], …] |
| `lista` | cartão com itens a entrar um a um | `titulo`, `itens` |
| `nota` | papel autocolante | `txt` |
| `fracao` | barras: parte de um todo | `titulo`, `n`, `cheias`, `nota` |
| `grafico` | barras a crescer | `titulo` |
| `tesouraria` | linha a desenhar-se | `titulo` |
| `edificio` | Estado / entidade pública | `rotulo` |
| `carrinha` | viatura | — |
| `carimbo` | carimbo a bater (vermelho; `cor: "dour"` dourado) | `txt` |
| `badge` | etiqueta dourada | `txt` |
| `sinal` | símbolo grande (≠ por defeito) | `txt` |
| `moeda` | moeda; com `voo: [dx, dy]` voa em arco | — |
| `ok` | visto dourado | — |
| `mao` | mão a apontar (entra de baixo; `sai` para sair) | — |
| `realce` | traço dourado à volta de um valor | `w`, `h` |
| `foto` | fotografia do catálogo em cartão de cantos redondos (sem moldura), legenda pequena opcional por baixo | `img` (ficheiro do catálogo), `w`, `h`, `txt`, `foco` (ex.: `center 40%`), `alinha` |
| `pasta` | pasta de arquivo digital (documentos `cai` + `sai` entram nela) | `txt` |
| `mapa` | cartão com pinos a aparecer um a um; os que têm nome ficam a dourado | `pinos` [[x, y, nome], …] |
| `mensagem` | conversa: balões a entrar um a um («cliente» à esquerda, Planipax à direita) | `msgs` [[quem, texto], …], `w`, `passo` (s entre balões) |

Campos comuns: `x`, `y` (canto superior esquerdo, em píxeis de 540x960),
`t` (segundos depois do início da cena), `anim` (`sobe`, `pop`, `cai`, `esq`,
`dir`, `carimbo`, `desenha`, `mao`), `dur`, `rot` (graus), `z` (camada),
`esc` (escala), `sai` (segundos até sair), `flutua: false`.

**Coordenadas.** Nas cenas, o desenho é ampliado 1,24 vezes à volta do ponto
(270, 600), como um plano aproximado: um objeto em `x: 88` aparece mais à
esquerda do que 88. Na capa não há ampliação: as coordenadas são diretas.
Não calcules à mão; gera, olha para a `folha.png` e acerta.

**Objetos persistentes (`id`).** O mesmo objeto em cenas seguidas leva o mesmo
`id`: em vez de desaparecer e voltar a aparecer, desliza para a posição nova.
É o que dá continuidade ao vídeo. Só se pode continuar na cena **seguinte**; o
motor recusa saltos. Na cena em que continua, põe-lhe `"dur": 0.01`.

**Zona segura.** Abaixo de 800 (de 960) ficam o nome da conta, a legenda e os
botões do Instagram; à direita, a coluna de botões. O motor mede cada cena no
fim e recusa objetos que desçam abaixo dos 800, que saiam pelos lados ou que
toquem no título.

### Números e regras da OCC

- **Todo o valor em euros num objeto é inventado e diz que é.** `dr`,
  `fatura`, `extrato` e `documento` levam «Valores ilustrativos» por baixo,
  automaticamente. Num `documento` com valores, nunca ponhas `ilus: false`.
- Um exemplo só, redondo, com a conta por inteiro e certa (4.000 € + 23 % =
  4.920 €). Taxas reais confirmadas por pesquisa, como no carrossel.
- **Sigilo (art. 72.º EOCC):** nenhum nome, NIF, fatura ou extrato que se possa
  ligar a um cliente real. «A sua empresa, Lda.» é o nome de serviço.
- **Lealdade (art. 74.º EOCC):** nada que desvalorize outros contabilistas.
- Sem preços nem honorários, sem «mais barato», sem promessas de poupança, sem
  superlativos («o melhor», «o único»).
- Sem medo: um carimbo vermelho mostra um facto («Ainda não recebido»), nunca
  uma ameaça («Multa!»). O vídeo acaba numa saída.

### A capa

O Instagram mostra a capa na grelha do perfil (cortada a 3:4) e no feed (4:5).
O motor desenha-a à parte (`capa.png`) a partir do campo `capa`:

- `titulo`: a pergunta ou o problema, em **duas a três linhas curtas**, com uma
  ou duas palavras a dourado. Não é a primeira frase do vídeo: é o cartaz.
- `figs`: dois ou três objetos parados, os do conflito do vídeo.
- `chamada`: opcional; por defeito «Explicamos em N segundos», com a duração real.
- Tudo o que importa fica entre os 240 e os 1680 de altura (de 1920): é o que
  sobrevive aos dois cortes.

---

## 2. Gerar

```bash
python3 scripts/reel/reel.py roteiro.json saida/                      # voz de trabalho
python3 scripts/reel/reel.py roteiro.json saida/ --voz-externa vozes/ # voz final
python3 scripts/reel/reel.py roteiro.json saida/ --so-capa            # só a capa, segundos
```

Demora cerca de 2 a 4 minutos (a primeira vez numa sessão descarrega 60 MB de
voz). Usa `--so-capa` para afinar a capa sem gerar o vídeo.

O motor faz tudo: a voz cena a cena, o título palavra a palavra sincronizado
com a voz, a música e os efeitos (próprios, sem direitos de terceiros; a
música baixa sozinha quando o narrador fala), o cartão final, a capa e a folha
de revisão.

## 3. Verificar

O motor valida o roteiro antes de gerar (código 3, nada gerado: campos
desconhecidos, tipos inexistentes, cenas sem objetos, `id` com saltos) e
verifica a composição no fim de cada cena (fontes e imagens carregadas,
objetos dentro da zona segura e sem tocar no título). **Se houver problemas, a
saída abre com «NÃO ENVIAR» e fica `NAO_ENVIAR.txt` na pasta.** Corrige e gera
outra vez.

### Revisão visual — obrigatória antes de mostrar

1. Abre a `folha.png` (a capa e o fim de cada cena). Procura o que a medição
   não vê: objetos sobrepostos de forma feia, um carimbo por cima de um valor,
   um número ilegível, a mão a tapar o que aponta.
2. **Vê o `reel.mp4` do princípio ao fim** com som. O que se procura: o objeto
   certo aparece *quando* a palavra é dita; nada pisca, salta ou fica parado
   demasiado tempo; a música não abafa a voz; a pronúncia de siglas e números.
   Para ver quadros soltos: `ffmpeg -ss 12.5 -i reel.mp4 -frames:v 1 q.png`.
3. Corrige, gera, revê **do princípio**. Três rondas sem resolver: mostra e diz
   qual é o problema, como no carrossel.

---

## 4. Apresentar

Entrega-se, sempre:

| O quê | Para quê |
|---|---|
| `reel.mp4` | o vídeo |
| `capa.png` | a capa, carregada à parte |
| `legenda.txt` | a legenda, com o mesmo cabeçalho e a linha de traços do carrossel; no cabeçalho, «formato reel» em vez da família |
| o `.md` da publicação, nos ficheiros do projeto | registo: candidatos, porquê Reel e não carrossel, o **roteiro JSON completo** (copiado da `roteiro.json` da pasta de saída) e a legenda |

A legenda segue o Passo 6 do `SKILL.md` e a revisão de marca faz-se igual,
sobre a narração inteira, a capa e a legenda. Na legenda de um Reel com
valores, uma linha diz que **os valores do vídeo são ilustrativos**.

No histórico, a coluna `familia` leva `reel`. Ao sortear a família de um
carrossel, as linhas `reel` não contam para as «duas últimas».

Diz com que voz foi gerado (de trabalho ou externa). Termina com as mesmas duas
escolhas: **Publicar** ou **Ajustar alguma coisa**.

---

## 5. A voz

| Voz | Quando |
|---|---|
| **Voz de trabalho** (Piper «tugão», pt-PT) | Sempre, para aprovar o vídeo. Gera-se aqui. |
| **Voz da Planipax** (ElevenLabs, voz criada com *Voice Design*) | Para publicar, quando estiver criada. |

A voz de trabalho é sintética e um pouco monótona; o motor parte as frases nas
vírgulas, abranda no fim e trata o som, mas não passa daí. **A sua licença não
é inequívoca para uso comercial** (as gravações são CC0, mas o modelo foi
afinado a partir de outro com licença de investigação). Por isso, antes de
publicar um Reel com a voz de trabalho, diz isto ao Ricardo numa linha e deixa
a decisão com ele.

As vozes «dii» e «miro» (pt-PT, melhores) são **CC BY-NC-SA: proibido uso
comercial.** Não se usam.

**Decisão de 29/10/2026 sobre a voz de publicação:** uma voz **criada de raiz**
no *Voice Design* do ElevenLabs — sintética, original, de ninguém. **Não se
clona a voz de nenhuma pessoa** (pedido expresso do Ricardo). A mesma voz será,
no futuro, a da mascote da Planipax (robô). Pontos fixos:

- **O plano gratuito do ElevenLabs não serve para publicar**: não tem licença
  comercial e obriga a pôr «elevenlabs.io» no título. Serve para criar e
  escolher a voz e para testes internos. Publicar exige plano pago (Starter ou
  superior) no mês em que se gera o áudio.
- Descrição usada para criar a voz (inglês, como a ferramenta pede; versão
  feminina ou masculina): «European Portuguese, native speaker from Lisbon (not
  Brazilian). A warm, friendly [female voice in her early thirties | male voice
  in his mid-thirties], clear and articulate, with a gentle smile in the
  delivery. Calm, confident and reassuring, like a helpful guide explaining
  something simple. Medium pitch, natural relaxed pacing, crisp studio-quality
  recording.»
- Ao ouvir qualquer áudio novo, confirmar o sotaque de Portugal: vogais
  reduzidas, «te» e não «tchi», sem ritmo cantado. Se escorregar para o
  brasileiro, não serve.

Para a voz externa: entrega ao Ricardo o texto de cada cena, numerado
(`cena01` … `cenaNN`), sem asteriscos. Ele gera ou grava um ficheiro por cena
com esses nomes (`.mp3`, `.wav` ou `.m4a`) e envia-os. O motor apara o silêncio
das pontas, normaliza o volume e volta a sincronizar tudo, com
`--voz-externa pasta/`. O vídeo é regenerado e revisto outra vez antes de ir.

---

## 6. Publicar

Só com o «sim» explícito do Ricardo, como no carrossel.

**Por agora o vídeo é carregado à mão no Metricool**, porque a rota automática
do carrossel (Make → GitHub → imagens) só transporta HTML e o Metricool precisa
do vídeo num endereço público. A rota automática para vídeo é a próxima obra
(cenário Make + tarefa do GitHub a gerar o vídeo a partir do roteiro).

- [ ] Entrega `reel.mp4`, `capa.png` e `legenda.txt` (só o corpo, depois dos
      traços, é o que se cola).
- [ ] Indica ao Ricardo, um passo de cada vez: no Metricool, novo post →
      Instagram e Facebook → carregar `reel.mp4` (sai como Reel) → em
      Instagram, «Mostrar no feed» ligado e capa carregada a partir de
      `capa.png` → colar a legenda → agendar para a próxima quarta às 9h00.
- [ ] Confirma com `Metricool:getScheduledPosts` (marca `7588662`) que o post
      está agendado nas duas redes, com a hora certa. Só então o estado passa a
      `enviado`, com a data e hora nas notas.
- [ ] `publicado` só com a confirmação do Ricardo, depois da hora, como sempre.

## 7. Medir, sete dias depois

Como no carrossel, mas o que se lê num Reel é diferente: **alcance a não
seguidores**, **tempo médio de visualização** (e a percentagem do vídeo vista),
**partilhas** e guardados. Escreve-os nas notas da linha do `historico.md`; sem
dados, «sem dados». É isto que o Passo 1-A usa, ao fim de oito semanas, para
afinar quantos Reels se fazem.

---

## Notas técnicas

- O motor está em `scripts/reel/`: `reel.py` (orquestra, valida e verifica),
  `voz.py` (narrador), `som.py` (música e efeitos sintetizados, deterministas),
  `modelo.html` (biblioteca de objetos e animação). A página é desenhada a
  540x960 com `device_scale_factor` 2, fotograma a fotograma com `render(t)`,
  e codificada em H.264 (CRF 20, `-preset veryfast`) + AAC 160k, 44,1 kHz.
- Requisitos do Metricool para Reels: MP4, H.264, 9:16, até 90 s no Facebook.
  Nada de HEVC nem HDR.
- A voz de trabalho vem do GitHub (`k2-fsa/sherpa-onnx`, releases
  `tts-models`) e fica em `~/.cache/planipax-voz` durante a sessão. O
  `piper-tts` instala-se sozinho se faltar.
- Novos objetos: acrescentam-se ao `FIG` do `modelo.html` e ao conjunto `TIPOS`
  do `reel.py`. Cores só da marca; papel com textura; sombra suave.
- As duas montras estão **dentro do pacote** (`assets/fotos/`, ~420 KB) e no
  catálogo. O `reel.py` usa a cópia local se existir; as outras fotografias vêm
  do GitHub, como no carrossel. Quando houver ocasião, carregar as montras
  também no repositório `Planipax/marca` e tirá-las do pacote (o pacote não
  pode voltar a crescer para os 4 MB que faziam falhar o download da skill).
- `--so-capa` usa silêncio no lugar da voz: a duração da chamada «Explicamos em
  N segundos» é aproximada. A capa final sai da geração completa.
