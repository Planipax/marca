# Referência — carrossel em passo a passo

Aprovado pelo Ricardo a 5 de agosto de 2026, entre cinco formatos propostos. Os
outros quatro foram rejeitados, e o que os separa deste está no fim.

Repara no que **não** tem: nenhum slide a dizer a quem se aplica, nenhuma
correção de um erro que o leitor cometa, nenhuma consequência má. O título já diz
para quem é, e o carrossel limita-se a pôr as coisas por ordem.

---

**Capa** — Contratar alguém tem uma ordem certa
Corpo: E a maior parte dos erros é fazer a coisa certa tarde de mais.

**1 · Primeiro — A comunicação à Segurança Social**
Corpo: Faz-se antes do primeiro dia de trabalho, não depois. É o passo que mais
vezes escapa.

**2 · Segundo — O seguro de acidentes de trabalho**
Corpo: Também antes de a pessoa começar. Sem ele, um acidente fica por conta da
empresa.

**3 · Terceiro — A conta real do ordenado**
Corpo: A 1.000 € de ordenado a empresa soma 23,75% de Segurança Social — 237,50 €.
São 1.237,50 € por mês, antes de férias e subsídios.

**4 · Quarto — O que se repete todos os meses**
Corpo: Recibo de vencimento, declaração, contribuição. Uma vez montado, corre
sozinho.

**Ponte** — A ordem certa poupa mais do que o dinheiro

**Final** — fixo, sem texto.

---

## Porque é que este funciona

**Cada slide é uma ação, não um conceito.** "Comunicar à Segurança Social" é uma
coisa que se faz. "O regime de comunicação de admissões" não é.

**A ordem é a informação.** O valor do carrossel não está em nenhum slide
isolado — está na sequência. É isso que o torna guardável.

**A taxa vem com a conta.** 23,75% sobre 1.000 € dá 237,50 €, e 1.000 + 237,50 dá
1.237,50. Tudo fecha e o leitor pode confirmar. Uma versão anterior dizia "cerca
de 240 €" e era pior nas duas coisas: menos clara e menos credível.

**Não assusta.** Diz-se uma vez que sem seguro o acidente fica por conta da
empresa, com calma, e passa-se à frente. Não é o fim do carrossel nem se repete.

**Não acusa.** Fala do que há a fazer, não do que o leitor faz mal.

## O que foi rejeitado, e porquê

| Formato | Razão |
|---|---|
| História do primeiro ano de atividade, mês a mês | Construída a desaguar na conta grande de abril. Assusta pela estrutura, mesmo com frases calmas |
| "Quatro contas que correm mal num restaurante" | Lista de erros do leitor, e pressupõe que é ele que faz a contabilidade |
| Alerta de cinco slides sobre um prazo | Um prazo sozinho não dá uma publicação |
| Comparação recibos verdes / empresa | Bom tema, mal explorado: três frases neutras em vez de prós e contras com peso |
