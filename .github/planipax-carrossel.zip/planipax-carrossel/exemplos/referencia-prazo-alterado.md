# Referência — carrossel de prazo alterado

Este texto foi **aprovado pelo Ricardo** a 5 de agosto de 2026, depois de três
versões rejeitadas por serem confusas. Serve de padrão para o tom, o
comprimento das frases e — sobretudo — para o **equilíbrio entre o que o
contabilista trata e o que sai do bolso de quem lê**.

Não é para copiar. É para comparar: escrito o texto novo, põe-se ao lado deste e
pergunta-se se está ao mesmo nível de clareza.

Tema: férias fiscais de agosto de 2026.

---

**1 · Capa**
Etiqueta: FÉRIAS FISCAIS
Título: Em agosto, os prazos fiscais mudam de dia
Corpo: Todos os anos a lei adia as obrigações de agosto. Chama-se férias fiscais.

**2 · `01` — O que são as férias fiscais**
Corpo: Uma regra que se repete todos os anos: o que vencia a meio de agosto passa
a poder ser cumprido no fim do mês. É automático — ninguém tem de pedir nada.
Caixa: Aplica-se a empresas, a quem trabalha por conta própria e a quem tem
empregados.

**3 · Lista — O que era a meio do mês e passa para 31 de agosto**
— Faturas de julho comunicadas à AT — era dia 5
— DMR, os rendimentos do trabalho — era dia 10
— Retenções de IRS e IRC — era dia 20
— Contribuições da Segurança Social — era dia 20

**4 · `02` — O IVA é o que salta mais**
Corpo: A declaração do 2.º trimestre entrega-se até 21 de setembro, e não a 20 de
agosto. O pagamento fica para 25 de setembro.
Caixa: Quem está no regime mensal tem exatamente as mesmas datas.

**5 · `03` — Duas coisas não foram adiadas**
Corpo: O IMI e o IRS a pagar já venciam a 31 de agosto. Continuam nesse dia — não
foram adiados, apenas calham na mesma data.
Caixa: E quem contrata alguém tem de comunicar a admissão antes de a pessoa
começar a trabalhar. Isso nunca é adiado.

**6 · `04` — Adiar não é dispensar**
Corpo: As datas mudaram, os valores não. Quem contava com esse dinheiro em agosto
tem de o guardar para setembro.
Caixa: Exemplo: 2.400 € de IVA do trimestre não saem da conta em agosto — saem a
25 de setembro.

**7 · Ponte — Um agosto com calendário próprio**
Corpo: Cada obrigação recebeu um prazo novo, e não são todos iguais. Ter quem siga
estas datas poupa juros e sustos.

**8 · Final** — fixo, sem texto.

---

## Porque é que este funciona

**A parte declarativa ocupa um slide, o terceiro, e mais nenhum.** Faturas, DMR,
retenções e contribuições estão todas agrupadas ali, com o antes de cada uma.
Não voltam a aparecer.

**Quatro slides falam de dinheiro que sai da conta de quem lê:** o IVA, o IMI e o
IRS, o efeito na tesouraria, e a ponte. É esta a proporção certa.

**Cada slide diz uma coisa e diz-a uma vez.** O slide 5 explica a exceção numa
frase e passa à frente; não a repete por três formas diferentes.

**O exemplo em euros está no slide do efeito**, não espalhado. Um número
concreto, um dia concreto: 2.400 € a 25 de setembro.

**As datas dizem o mês.** *"21 de setembro"*, *"31 de agosto"* — nunca um dia
solto que possa ser de qualquer mês.
